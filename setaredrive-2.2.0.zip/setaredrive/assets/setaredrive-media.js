(function () {
  'use strict';

  function init(gallery) {
    var slides = Array.prototype.slice.call(gallery.querySelectorAll('[data-slide]'));
    var thumbs = Array.prototype.slice.call(gallery.querySelectorAll('[data-thumb]'));
    var rail = gallery.querySelector('[data-rail]');
    var prev = gallery.querySelector('[data-prev]');
    var next = gallery.querySelector('[data-next]');
    var current = 0;
    if (!slides.length) { return; }
    gallery.classList.add('is-ready');

    function preload(index) {
      var slide = slides[(index + slides.length) % slides.length];
      var img = slide && slide.querySelector('img');
      if (img && img.getAttribute('loading') === 'lazy') {
        img.setAttribute('loading', 'eager');
      }
    }

    function show(index) {
      current = (index + slides.length) % slides.length;
      slides.forEach(function (slide, i) {
        var active = i === current;
        slide.hidden = !active;
        var url = slide.getAttribute('data-video');
        if (!url) { return; }
        var frame = slide.querySelector('iframe');
        if (active && !frame) {
          frame = document.createElement('iframe');
          frame.src = url;
          frame.allow = 'autoplay; fullscreen';
          frame.setAttribute('allowfullscreen', '');
          frame.setAttribute('title', 'Videoclip');
          slide.appendChild(frame);
        } else if (!active && frame) {
          frame.remove();
        }
      });
      thumbs.forEach(function (thumb) {
        var active = Number(thumb.getAttribute('data-thumb')) === current;
        thumb.setAttribute('aria-pressed', active ? 'true' : 'false');
        if (active && rail) {
          var box = rail.getBoundingClientRect();
          var rect = thumb.getBoundingClientRect();
          if (rect.left < box.left) { rail.scrollLeft -= box.left - rect.left + 8; }
          else if (rect.right > box.right) { rail.scrollLeft += rect.right - box.right + 8; }
        }
      });
      preload(current + 1);
      preload(current - 1);
    }

    show(0);
    if (slides.length < 2) { return; }
    [prev, next, rail].forEach(function (el) { if (el) { el.hidden = false; } });
    if (prev) { prev.addEventListener('click', function () { show(current - 1); }); }
    if (next) { next.addEventListener('click', function () { show(current + 1); }); }
    thumbs.forEach(function (thumb) {
      thumb.addEventListener('click', function () { show(Number(thumb.getAttribute('data-thumb')) || 0); });
    });

    gallery.addEventListener('keydown', function (event) {
      if (event.target && event.target.closest && event.target.closest('iframe, input, textarea, select')) { return; }
      if (event.key === 'ArrowLeft') { event.preventDefault(); show(current - 1); }
      else if (event.key === 'ArrowRight') { event.preventDefault(); show(current + 1); }
    });

    var startX = null;
    var stage = gallery.querySelector('.sdrv-stage');
    if (stage) {
      stage.addEventListener('touchstart', function (event) { startX = event.touches[0].clientX; }, { passive: true });
      stage.addEventListener('touchend', function (event) {
        if (startX === null) { return; }
        var dx = event.changedTouches[0].clientX - startX;
        startX = null;
        if (Math.abs(dx) > 45) { show(current + (dx < 0 ? 1 : -1)); }
      }, { passive: true });
    }
  }

  document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('[data-sdrv-gallery]').forEach(init);
  });
}());
