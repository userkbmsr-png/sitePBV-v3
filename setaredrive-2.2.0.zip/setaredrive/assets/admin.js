(function () {
  'use strict';
  var cfg = window.SetareDriveAdmin || {};

  document.querySelectorAll('[data-sdrv-test]').forEach(function (button) {
    button.addEventListener('click', function () {
      var cell = button.closest('td');
      var input = cell.querySelector('[data-sdrv-folder]');
      var out = cell.querySelector('.sdrv-test-result');
      var body = new URLSearchParams({ action: 'setaredrive_test', nonce: cfg.nonce, kind: input.getAttribute('data-kind') || 'drive', id: input.value });
      out.style.color = '';
      out.textContent = 'Se verifică…';
      button.disabled = true;
      fetch(cfg.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body })
        .then(function (response) { return response.json(); })
        .then(function (json) {
          out.style.color = json.success ? '#007017' : '#b32d2e';
          out.textContent = json.data && json.data.message ? json.data.message : 'Răspuns neașteptat.';
        })
        .catch(function () {
          out.style.color = '#b32d2e';
          out.textContent = 'Verificarea nu a putut fi efectuată.';
        })
        .then(function () { button.disabled = false; });
    });
  });
}());
