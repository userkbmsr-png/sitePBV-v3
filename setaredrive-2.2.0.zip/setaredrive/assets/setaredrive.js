(function () {
  'use strict';

  var cfg = window.SetareDrive || { rest: '', strings: {} };
  var S = cfg.strings || {};

  function esc(value) {
    return window.CSS && CSS.escape ? CSS.escape(value) : String(value).replace(/["\\]/g, '\\$&');
  }

  function api(path, params) {
    var query = Object.keys(params).map(function (key) {
      return encodeURIComponent(key) + '=' + encodeURIComponent(params[key]);
    }).join('&');
    return fetch(cfg.rest + path + '?' + query, { credentials: 'omit' }).then(function (response) {
      if (!response.ok) { throw new Error('HTTP ' + response.status); }
      return response.json();
    });
  }

  function init(root) {
    var frame = root.querySelector('[data-frame]');
    var openLink = root.querySelector('[data-open-link]');
    var label = root.querySelector('[data-selected]');
    var searchForm = root.querySelector('[data-search-form]');
    var searchInput = root.querySelector('[data-search-input]');
    var searchNote = root.querySelector('[data-search-note]');
    var results = root.querySelector('[data-search-results]');
    var localList = root.querySelector('[data-local-list]');
    var isLocal = root.getAttribute('data-source') === 'local';
    var section = root.getAttribute('data-section') || '';
    var current = { id: '', token: '', name: '' };

    function countLabel(n) {
      return n + ' ' + (n === 1 ? (S.docOne || 'document') : (S.docMany || 'documente'));
    }

    /* Lista de documente a unui folder de pe server (aceeași structură ca în HTML-ul din PHP) */
    function renderLocal(data) {
      if (!localList) { return; }
      localList.replaceChildren();
      var head = document.createElement('div');
      head.className = 'sdrv-folder-head';
      var icon = document.createElement('span');
      icon.className = 'sdrv-folder-icon';
      icon.setAttribute('aria-hidden', 'true');
      icon.textContent = '📁';
      var box = document.createElement('div');
      var title = document.createElement('h3');
      title.textContent = data.name || current.name || '';
      var count = document.createElement('p');
      count.textContent = countLabel(data.count || 0);
      box.appendChild(title);
      box.appendChild(count);
      head.appendChild(icon);
      head.appendChild(box);
      localList.appendChild(head);
      var files = data.files || [];
      if (!files.length) {
        var empty = document.createElement('p');
        empty.className = 'sdrv-empty';
        empty.textContent = (data.subfolders > 0)
          ? (S.onlySubfolders || 'Acest folder conține doar subfoldere. Alegeți un subfolder din listă pentru a vedea documentele.')
          : (S.emptyFolder || 'Acest folder nu conține documente.');
        localList.appendChild(empty);
        return;
      }
      var list = document.createElement('ul');
      list.className = 'sdrv-doclist';
      files.forEach(function (file) {
        var li = document.createElement('li');
        var a = document.createElement('a');
        a.className = 'sdrv-doc';
        a.href = file.url;
        a.target = '_blank';
        a.rel = 'noopener noreferrer';
        var ext = document.createElement('span');
        ext.className = 'sdrv-doc-ext';
        ext.setAttribute('data-ext', file.ext);
        ext.textContent = String(file.ext).toUpperCase();
        var name = document.createElement('span');
        name.className = 'sdrv-doc-name';
        name.textContent = file.name;
        var size = document.createElement('span');
        size.className = 'sdrv-doc-size';
        size.textContent = file.size;
        a.appendChild(ext);
        a.appendChild(name);
        a.appendChild(size);
        li.appendChild(a);
        list.appendChild(li);
      });
      localList.appendChild(list);
    }

    function loadLocal(id, token) {
      if (!localList) { return; }
      localList.setAttribute('aria-busy', 'true');
      api('local/files', { sec: section, id: id, t: token }).then(function (data) {
        renderLocal(data);
      }).catch(function () {
        localList.replaceChildren();
        var error = document.createElement('p');
        error.className = 'sdrv-empty';
        error.textContent = S.listFailed || 'Lista de documente nu poate fi încărcată momentan.';
        localList.appendChild(error);
      }).then(function () {
        localList.removeAttribute('aria-busy');
      });
    }

    function tokenFor(id, button) {
      if (button && button.getAttribute && button.getAttribute('data-token')) { return button.getAttribute('data-token'); }
      var node = button && button.closest ? button.closest('.sdrv-node') : null;
      if (node) { return node.getAttribute('data-token') || ''; }
      return id === root.getAttribute('data-initial') ? (root.getAttribute('data-token') || '') : '';
    }

    var initialSelect = false;

    function select(id, name, button) {
      if (!id) { return; }
      current = { id: id, token: tokenFor(id, button), name: name || '' };
      if (isLocal) {
        if (!initialSelect) { loadLocal(id, current.token); }
      } else {
        if (frame) { frame.src = 'https://drive.google.com/embeddedfolderview?id=' + encodeURIComponent(id) + '#list'; }
        if (openLink) { openLink.href = 'https://drive.google.com/drive/folders/' + encodeURIComponent(id); }
      }
      if (label) { label.textContent = current.name || '—'; }
      if (results) { results.replaceChildren(); }
      if (searchNote) { searchNote.textContent = (typeof scopeNote === 'function') ? scopeNote() : ''; }
      root.querySelectorAll('.sdrv-folder-btn').forEach(function (item) {
        var active = button ? item === button : item.getAttribute('data-folder') === id;
        item.classList.toggle('is-selected', active);
        item.setAttribute('aria-pressed', active ? 'true' : 'false');
      });
    }

    /* ---- arbore: subfolderele se încarcă la prima deschidere ---- */
    function setOpen(node, open) {
      var list = node.querySelector(':scope > .sdrv-tree-list');
      var toggle = node.querySelector(':scope > .sdrv-node-row > .sdrv-toggle');
      node.classList.toggle('is-open', open);
      if (list) { list.hidden = !open; }
      if (toggle) {
        toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
        toggle.setAttribute('aria-label', open ? (S.hideChildren || 'Ascunde subfolderele') : (S.showChildren || 'Arată subfolderele'));
      }
    }

    function buildNode(folder) {
      var li = document.createElement('li');
      li.className = 'sdrv-node';
      li.setAttribute('data-id', folder.id);
      li.setAttribute('data-token', folder.t);
      var row = document.createElement('div');
      row.className = 'sdrv-node-row';
      var toggle = document.createElement('button');
      toggle.type = 'button';
      toggle.className = 'sdrv-toggle';
      toggle.setAttribute('aria-expanded', 'false');
      toggle.setAttribute('aria-label', S.showChildren || 'Arată subfolderele');
      toggle.appendChild(document.createElement('span')).setAttribute('aria-hidden', 'true');
      var button = document.createElement('button');
      button.type = 'button';
      button.className = 'sdrv-folder-btn';
      button.setAttribute('data-folder', folder.id);
      button.setAttribute('aria-pressed', 'false');
      var icon = document.createElement('span');
      icon.setAttribute('aria-hidden', 'true');
      icon.textContent = '📁';
      button.appendChild(icon);
      button.appendChild(document.createTextNode(' ' + folder.name));
      row.appendChild(toggle);
      row.appendChild(button);
      var list = document.createElement('ul');
      list.className = 'sdrv-tree-list';
      list.setAttribute('role', 'group');
      list.hidden = true;
      li.appendChild(row);
      li.appendChild(list);
      return li;
    }

    /* Încarcă subfolderele unui nod (o singură dată). Returnează o promisiune rezolvată după încărcare. */
    function loadChildren(node) {
      if (node.getAttribute('data-loaded') === '1') { return Promise.resolve(node); }
      if (node._sdrvLoading) { return node._sdrvLoading; }
      node.classList.add('is-loading');
      var request = isLocal
        ? api('local/children', { sec: section, id: node.getAttribute('data-id'), t: node.getAttribute('data-token') })
        : api('children', { id: node.getAttribute('data-id'), t: node.getAttribute('data-token') });
      node._sdrvLoading = request.then(function (data) {
        var list = node.querySelector(':scope > .sdrv-tree-list');
        var folders = (data && data.folders) || [];
        folders.forEach(function (folder) { list.appendChild(buildNode(folder)); });
        node.setAttribute('data-loaded', '1');
        if (!folders.length) { node.classList.add('is-leaf'); }
      }).catch(function () {
        node.classList.add('is-leaf');
      }).then(function () {
        node.classList.remove('is-loading');
        node._sdrvLoading = null;
        return node;
      });
      return node._sdrvLoading;
    }

    function expand(node) {
      if (node.classList.contains('is-open')) { setOpen(node, false); return; }
      loadChildren(node).then(function () {
        if (!node.classList.contains('is-leaf')) { setOpen(node, true); }
      });
    }

    /* Monitorul Oficial Local: arborele se afișează extins – folderele și primul nivel de subfoldere.
       Subfolderele de nivel mai adânc rămân închise și se încarcă la deschidere. Cererile merg câte 4 odată. */
    function autoExpandFirstLevel() {
      var nodes = Array.prototype.slice.call(root.querySelectorAll('.sdrv-tree-root > .sdrv-node > .sdrv-tree-list > .sdrv-node'));
      var next = 0;
      var running = 0;
      function pump() {
        while (running < 4 && next < nodes.length) {
          running += 1;
          var node = nodes[next++];
          loadChildren(node).then(function (loaded) {
            if (!loaded.classList.contains('is-leaf') && !loaded.classList.contains('is-open')) { setOpen(loaded, true); }
            running -= 1;
            pump();
          });
        }
      }
      pump();
    }

    root.addEventListener('click', function (event) {
      var target = event.target.closest ? event.target.closest('.sdrv-folder-btn, .sdrv-toggle') : null;
      if (!target || !root.contains(target)) { return; }
      var node = target.closest('.sdrv-node');
      if (target.classList.contains('sdrv-toggle')) {
        if (node) { expand(node); }
        return;
      }
      var name = (target.textContent || '').replace(/^\s*📁\s*/, '').trim();
      select(target.getAttribute('data-folder'), name, target);
      if (node && !node.classList.contains('is-open') && !node.classList.contains('is-leaf')) { expand(node); }
    });

    /* ---- stare inițială ---- */
    var initial = root.getAttribute('data-initial');
    if (initial) {
      var first = root.querySelector('.sdrv-folder-btn[data-folder="' + esc(initial) + '"]');
      initialSelect = true;
      select(initial, first ? (first.textContent || '').replace(/^\s*📁\s*/, '').trim() : '', first);
      initialSelect = false;
    }
    if (root.hasAttribute('data-sdrv-mol')) { autoExpandFirstLevel(); }

    /* ---- căutare în numele fișierelor: folderul selectat sau tot arborele (bifa) ---- */
    var allBox = root.querySelector('[data-search-all]');

    function scopeNote() {
      if (allBox && allBox.checked) { return (S.searchAll || 'Căutare în tot Monitorul Oficial Local') + '.'; }
      return current.name ? (S.searchIn || 'Căutare în') + ' „' + current.name + '”.' : '';
    }
    if (allBox) {
      allBox.addEventListener('change', function () {
        if (searchNote) { searchNote.textContent = scopeNote(); }
        if (results) { results.replaceChildren(); }
      });
    }

    if (searchForm) {
      searchForm.addEventListener('submit', function (event) {
        event.preventDefault();
        if (results) { results.replaceChildren(); }
        var term = searchInput ? searchInput.value.trim() : '';
        var wholeTree = !!(allBox && allBox.checked);
        var scopeId = wholeTree ? root.getAttribute('data-initial') : current.id;
        var scopeToken = wholeTree ? root.getAttribute('data-token') : current.token;
        if (!scopeId || !scopeToken) {
          if (searchNote) { searchNote.textContent = S.selectFirst || 'Selectați mai întâi un folder din listă.'; }
          return;
        }
        if (!term) {
          if (searchNote) { searchNote.textContent = S.enterTerm || 'Introduceți un termen de căutare.'; }
          return;
        }
        if (searchNote) { searchNote.textContent = S.searching || 'Se caută…'; }
        var params = { id: scopeId, t: scopeToken, q: term };
        if (wholeTree) { params.all = 1; }
        if (isLocal) { params.sec = section; }
        var query = api(isLocal ? 'local/search' : 'search', params);
        query.then(function (data) {
          var files = (data && data.files) || [];
          if (searchNote) {
            searchNote.textContent = files.length + ' ' + (S.found || 'fișiere găsite') + (wholeTree ? ' în tot Monitorul Oficial Local.' : (current.name ? ' în „' + current.name + '”.' : '.'))
              + (data && data.partial ? ' ' + (S.partial || 'Rezultatele sunt parțiale.') : '');
          }
          if (!files.length) {
            if (results) { results.textContent = S.noResults || 'Nu au fost găsite fișiere.'; }
            return;
          }
          var list = document.createElement('ul');
          list.className = 'sdrv-results-list';
          files.forEach(function (file) {
            var item = document.createElement('li');
            var main = document.createElement('div');
            main.className = 'sdrv-result-main';
            var link = document.createElement('a');
            link.href = file.url;
            link.target = '_blank';
            link.rel = 'noopener noreferrer';
            link.textContent = file.name;
            main.appendChild(link);
            if (file.path) {
              var trail = document.createElement('span');
              trail.className = 'sdrv-result-path';
              trail.textContent = file.path;
              main.appendChild(trail);
            }
            item.appendChild(main);
            var date = file.date ? new Date(file.date) : null;
            if (date && !isNaN(date.getTime())) {
              var meta = document.createElement('span');
              meta.className = 'sdrv-result-date';
              meta.textContent = date.toLocaleDateString('ro-RO');
              item.appendChild(meta);
            }
            list.appendChild(item);
          });
          if (results) { results.appendChild(list); }
        }).catch(function () {
          if (searchNote) { searchNote.textContent = S.failed || 'Căutarea nu a putut fi efectuată momentan.'; }
        });
      });
    }
  }

  document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('[data-sdrv-browser]').forEach(init);
  });
}());
