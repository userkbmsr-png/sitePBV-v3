<?php
/**
 * Plugin Name: SetareDrive
 * Description: Formulare, galerie foto și Monitorul Oficial Local din foldere Google Drive sau din foldere de pe serverul site-ului. Locațiile se setează în Setări → SetareDrive.
 * Version: 2.2.0
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Text Domain: setaredrive
 */

if (!defined('ABSPATH')) {
    exit;
}

define('SETAREDRIVE_VERSION', '2.2.0');
define('SETAREDRIVE_FILE', __FILE__);
define('SETAREDRIVE_DIR', plugin_dir_path(__FILE__));
define('SETAREDRIVE_URL', plugin_dir_url(__FILE__));

require_once SETAREDRIVE_DIR . 'includes/class-setaredrive-api.php';
require_once SETAREDRIVE_DIR . 'includes/class-setaredrive-local.php';
require_once SETAREDRIVE_DIR . 'includes/class-setaredrive-frontend.php';
require_once SETAREDRIVE_DIR . 'includes/class-setaredrive-settings.php';

/** Completează paginile Formulare, Media și Monitorul Oficial Local create de SetareDate. */
function setaredrive_ensure_pages() {
    $pages = array(
        array('formulare', 'Formulare', '[setaredrive_formulare]'),
        array('media', 'Media', '[setaredrive_media]'),
        array('monitorul-oficial-local', 'Monitorul Oficial Local', '[setaredrive_mol]'),
    );
    foreach ($pages as $page) {
        $existing = get_page_by_path($page[0], OBJECT, 'page');
        if (!$existing) {
            // Dacă SetareDate este instalat, el creează paginile la „Aplică modificările”.
            if (!class_exists('SetareDate_Settings')) {
                wp_insert_post(array(
                    'post_type'    => 'page',
                    'post_status'  => 'publish',
                    'post_title'   => $page[1],
                    'post_name'    => $page[0],
                    'post_content' => $page[2],
                ));
            }
            continue;
        }
        if (trim((string) $existing->post_content) === '') {
            wp_update_post(array('ID' => $existing->ID, 'post_content' => $page[2]));
        }
    }
}

SetareDrive_Local::init();
SetareDrive_Frontend::init();
SetareDrive_Settings::init();

register_activation_hook(__FILE__, 'setaredrive_ensure_pages');
add_action('setaredate_applied', 'setaredrive_ensure_pages');
add_action('admin_init', function () {
    if (get_option('setaredrive_pages_v') !== SETAREDRIVE_VERSION && current_user_can('manage_options')) {
        setaredrive_ensure_pages();
        update_option('setaredrive_pages_v', SETAREDRIVE_VERSION, false);
    }
});
