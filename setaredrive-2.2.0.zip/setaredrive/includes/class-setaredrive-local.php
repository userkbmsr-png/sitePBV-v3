<?php
/**
 * Sursa „folder pe server”: documente și fotografii aflate pe serverul care găzduiește site-ul.
 *
 * Siguranță:
 * - calea setată se rezolvă cu realpath() și trebuie să fie un subfolder al instalării WordPress
 *   (sau al unui folder permis prin constanta SETAREDRIVE_BASE_DIR); folderele de cod sunt excluse;
 * - browserul nu primește niciodată căi: folderele și fișierele sunt identificate prin ID-uri
 *   codificate, semnate cu HMAC, iar fiecare cerere este verificată și re-rezolvată în rădăcina secțiunii;
 * - se afișează și se servesc doar tipurile de fișiere din lista de mai jos; fișierele ascunse sunt ignorate.
 */

if (!defined('ABSPATH')) {
    exit;
}

final class SetareDrive_Local {
    const SECTIONS = array('formulare', 'foto', 'mol');

    /** Extensii permise → tip MIME. */
    const TYPES = array(
        'pdf'  => 'application/pdf',
        'doc'  => 'application/msword',
        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'xls'  => 'application/vnd.ms-excel',
        'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'ppt'  => 'application/vnd.ms-powerpoint',
        'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'odt'  => 'application/vnd.oasis.opendocument.text',
        'ods'  => 'application/vnd.oasis.opendocument.spreadsheet',
        'odp'  => 'application/vnd.oasis.opendocument.presentation',
        'rtf'  => 'application/rtf',
        'txt'  => 'text/plain; charset=utf-8',
        'csv'  => 'text/csv; charset=utf-8',
        'xml'  => 'application/xml',
        'zip'  => 'application/zip',
        'jpg'  => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'png'  => 'image/png',
        'gif'  => 'image/gif',
        'webp' => 'image/webp',
    );
    const INLINE = array('pdf', 'txt', 'jpg', 'jpeg', 'png', 'gif', 'webp');
    const IMAGES = array('jpg', 'jpeg', 'png', 'gif', 'webp');
    const SIZES  = array('thumb' => 240, 'large' => 1600);

    /* ------------------------------------------------------------------ setări */

    public static function option($section) {
        return in_array($section, self::SECTIONS, true) ? trim((string) get_option('setaredrive_local_' . $section, '')) : '';
    }

    private static function norm($path) {
        return rtrim(wp_normalize_path((string) $path), '/');
    }

    /** Folderele de bază în care este permis să se afle o sursă. */
    private static function bases() {
        $bases = array();
        foreach (array(ABSPATH, WP_CONTENT_DIR) as $candidate) {
            $real = realpath($candidate);
            if ($real) {
                $bases[] = self::norm($real);
            }
        }
        if (defined('SETAREDRIVE_BASE_DIR') && SETAREDRIVE_BASE_DIR) {
            $real = realpath((string) SETAREDRIVE_BASE_DIR);
            if ($real) {
                $bases[] = self::norm($real);
            }
        }
        return array_values(array_unique($bases));
    }

    /** Folderele de cod ale WordPress nu pot fi folosite ca sursă. */
    private static function is_code_path($normalized) {
        $abspath = self::norm(realpath(ABSPATH));
        if (strpos($normalized . '/', $abspath . '/') !== 0) {
            return false;
        }
        $relative = ltrim(substr($normalized, strlen($abspath)), '/');
        return (bool) preg_match('~^(wp-admin|wp-includes)(/|$)|^wp-content/(plugins|themes|mu-plugins|upgrade|languages)(/|$)~', $relative);
    }

    /** Transformă o cale introdusă în setări într-o cale reală, validă. @return string|WP_Error */
    public static function resolve($input) {
        $input = trim(wp_normalize_path((string) $input));
        if ($input === '') {
            return new WP_Error('setaredrive_local_empty', 'Nu este setat folderul de pe server.');
        }
        if (strpos($input, "\0") !== false) {
            return new WP_Error('setaredrive_local_bad', 'Calea conține caractere nepermise.');
        }
        $absolute = ($input[0] === '/') || preg_match('~^[A-Za-z]:/~', $input);
        $path     = $absolute ? $input : self::norm(ABSPATH) . '/' . ltrim($input, '/');
        $real     = realpath($path);
        if ($real === false || !is_dir($real)) {
            return new WP_Error('setaredrive_local_missing', 'Folderul nu există pe server: ' . $path);
        }
        $real   = self::norm($real);
        $inside = false;
        foreach (self::bases() as $base) {
            if ($real === $base) {
                return new WP_Error('setaredrive_local_root', 'Alegeți un subfolder, nu rădăcina instalării WordPress.');
            }
            if (strpos($real . '/', $base . '/') === 0) {
                $inside = true;
            }
        }
        if (!$inside) {
            return new WP_Error('setaredrive_local_outside', 'Folderul trebuie să se afle în instalarea WordPress (sau în folderul permis prin SETAREDRIVE_BASE_DIR).');
        }
        if (self::is_code_path($real)) {
            return new WP_Error('setaredrive_local_code', 'Acest folder conține codul WordPress și nu poate fi folosit.');
        }
        if (!is_readable($real)) {
            return new WP_Error('setaredrive_local_unreadable', 'Folderul nu poate fi citit de serverul web.');
        }
        return $real;
    }

    /** Rădăcina reală a unei secțiuni. @return string|WP_Error */
    public static function root($section) {
        return self::resolve(self::option($section));
    }

    /**
     * La salvare: dacă folderul nu există, dar se află într-o locație permisă, îl creează.
     * @return array{status:string,message:string}
     */
    public static function ensure($input) {
        $input = trim((string) $input);
        if ($input === '') {
            return array('status' => 'empty', 'message' => '');
        }
        $resolved = self::resolve($input);
        if (!is_wp_error($resolved)) {
            return array('status' => 'ok', 'message' => $resolved);
        }
        if ($resolved->get_error_code() !== 'setaredrive_local_missing') {
            return array('status' => 'invalid', 'message' => $resolved->get_error_message());
        }
        $normalized = wp_normalize_path($input);
        $absolute   = ($normalized[0] === '/') || preg_match('~^[A-Za-z]:/~', $normalized);
        $target     = $absolute ? self::norm($normalized) : self::norm(ABSPATH) . '/' . ltrim($normalized, '/');
        if (strpos($target, '..') !== false) {
            return array('status' => 'invalid', 'message' => 'Calea nu poate conține „..”.');
        }
        // Se creează doar dacă cel mai apropiat folder existent se află într-o locație permisă.
        $ancestor = $target;
        while ($ancestor !== '' && !is_dir($ancestor) && dirname($ancestor) !== $ancestor) {
            $ancestor = self::norm(dirname($ancestor));
        }
        $ancestor_real = $ancestor !== '' ? realpath($ancestor) : false;
        $allowed       = false;
        if ($ancestor_real) {
            $ancestor_real = self::norm($ancestor_real);
            foreach (self::bases() as $base) {
                if (strpos($ancestor_real . '/', $base . '/') === 0) {
                    $allowed = true;
                }
            }
        }
        if (!$allowed || self::is_code_path($ancestor_real . substr($target, strlen($ancestor)))) {
            return array('status' => 'invalid', 'message' => 'Folderul nu există, iar locația nu permite crearea lui din SetareDrive.');
        }
        if (!wp_mkdir_p($target)) {
            return array('status' => 'invalid', 'message' => 'Folderul nu există și nu a putut fi creat (permisiuni insuficiente).');
        }
        $again = self::resolve($input);
        if (is_wp_error($again)) {
            return array('status' => 'invalid', 'message' => $again->get_error_message());
        }
        return array('status' => 'created', 'message' => $again);
    }

    /* ------------------------------------------------------------- ID-uri, jetoane */

    public static function encode_id($rel) {
        return 'r' . rtrim(strtr(base64_encode((string) $rel), '+/', '-_'), '=');
    }

    /** @return string|false Calea relativă (fără „..”), sau false dacă ID-ul e invalid. */
    public static function decode_id($id) {
        $id = (string) $id;
        if ($id === '' || $id[0] !== 'r') {
            return false;
        }
        $raw = base64_decode(strtr(substr($id, 1), '-_', '+/'), true);
        if ($raw === false || strpos($raw, "\0") !== false || strpos($raw, '\\') !== false) {
            return false;
        }
        $raw = trim($raw, '/');
        if ($raw === '') {
            return '';
        }
        foreach (explode('/', $raw) as $segment) {
            if ($segment === '' || $segment === '.' || $segment === '..') {
                return false;
            }
        }
        return $raw;
    }

    public static function token($section, $id) {
        return substr(hash_hmac('sha256', 'local|' . $section . '|' . $id, wp_salt('auth')), 0, 24);
    }

    public static function valid($section, $id, $token) {
        return in_array($section, self::SECTIONS, true) && is_string($token) && hash_equals(self::token($section, $id), $token);
    }

    /** Calea reală a unui folder/fișier din secțiune, strict în rădăcina ei. @return string|false */
    public static function path($section, $rel) {
        $root = self::root($section);
        if (is_wp_error($root)) {
            return false;
        }
        $full = $rel === '' ? $root : $root . '/' . $rel;
        $real = realpath($full);
        if ($real === false) {
            return false;
        }
        $real = self::norm($real);
        return (strpos($real . '/', $root . '/') === 0) ? $real : false;
    }

    /* ---------------------------------------------------------------- liste */

    private static function entries($abs, $root) {
        $names = @scandir($abs);
        if (!is_array($names)) {
            return array();
        }
        $out = array();
        foreach ($names as $name) {
            if ($name === '' || $name[0] === '.') {
                continue;
            }
            $real = realpath($abs . '/' . $name);
            if ($real === false) {
                continue;
            }
            $real = self::norm($real);
            if (strpos($real . '/', $root . '/') !== 0) {
                continue; // legătură simbolică în afara rădăcinii
            }
            $out[] = array('name' => $name, 'real' => $real);
        }
        return $out;
    }

    /** Subfolderele directe ale unui folder (cale relativă). @return array|WP_Error */
    public static function folders($section, $rel) {
        $root = self::root($section);
        $abs  = self::path($section, $rel);
        if (is_wp_error($root) || $abs === false || !is_dir($abs)) {
            return new WP_Error('setaredrive_local', 'Folderul nu este disponibil.');
        }
        $items = array();
        foreach (self::entries($abs, $root) as $entry) {
            if (!is_dir($entry['real'])) {
                continue;
            }
            $child   = ($rel === '' ? '' : $rel . '/') . $entry['name'];
            $id      = self::encode_id($child);
            $items[] = array('id' => $id, 'name' => $entry['name'], 't' => self::token($section, $id));
        }
        return SetareDrive_API::sort_folders($items);
    }

    public static function ext($name) {
        return strtolower((string) pathinfo((string) $name, PATHINFO_EXTENSION));
    }

    /** Fișierele permise dintr-un folder. @return array|WP_Error */
    public static function files($section, $rel) {
        $root = self::root($section);
        $abs  = self::path($section, $rel);
        if (is_wp_error($root) || $abs === false || !is_dir($abs)) {
            return new WP_Error('setaredrive_local', 'Folderul nu este disponibil.');
        }
        $items = array();
        foreach (self::entries($abs, $root) as $entry) {
            $ext = self::ext($entry['name']);
            if (!is_file($entry['real']) || !isset(self::TYPES[$ext])) {
                continue;
            }
            $child   = ($rel === '' ? '' : $rel . '/') . $entry['name'];
            $items[] = array(
                'name'  => pathinfo($entry['name'], PATHINFO_FILENAME),
                'file'  => $entry['name'],
                'ext'   => $ext,
                'size'  => (int) @filesize($entry['real']),
                'mtime' => (int) @filemtime($entry['real']),
                'url'   => self::url($section, $child),
            );
        }
        usort($items, function ($a, $b) {
            return strnatcasecmp($a['name'], $b['name']);
        });
        return $items;
    }

    /** Fotografii din folder și subfoldere (până la $depth niveluri), cele mai noi întâi. */
    public static function images($section, $depth = 2, $cap = 300) {
        $found = array();
        $queue = array(array('', 0));
        while ($queue && count($found) < $cap) {
            list($rel, $level) = array_shift($queue);
            $root = self::root($section);
            $abs  = self::path($section, $rel);
            if (is_wp_error($root) || $abs === false) {
                continue;
            }
            foreach (self::entries($abs, $root) as $entry) {
                $child = ($rel === '' ? '' : $rel . '/') . $entry['name'];
                if (is_dir($entry['real'])) {
                    if ($level < $depth) {
                        $queue[] = array($child, $level + 1);
                    }
                    continue;
                }
                if (is_file($entry['real']) && in_array(self::ext($entry['name']), self::IMAGES, true)) {
                    $found[] = array('rel' => $child, 'mtime' => (int) @filemtime($entry['real']));
                }
            }
        }
        usort($found, function ($a, $b) {
            return $b['mtime'] <=> $a['mtime'];
        });
        $found = array_slice($found, 0, $cap);
        foreach ($found as $i => $item) {
            $found[$i]['big']   = self::url($section, $item['rel'], 'large');
            $found[$i]['thumb'] = self::url($section, $item['rel'], 'thumb');
        }
        return $found;
    }

    /**
     * Caută după nume în folderul indicat și în toate subfolderele lui.
     *
     * @return array{files:array,partial:bool}|WP_Error
     */
    public static function search_tree($section, $rel, $term, $max_results = 200, $max_scanned = 20000) {
        $root = self::root($section);
        if (is_wp_error($root) || self::path($section, $rel) === false) {
            return new WP_Error('setaredrive_local', 'Folderul nu este disponibil.');
        }
        $queue   = array(array($rel, ''));
        $matches = array();
        $scanned = 0;
        $partial = false;
        while ($queue) {
            list($current, $trail) = array_shift($queue);
            $abs = self::path($section, $current);
            if ($abs === false) {
                continue;
            }
            foreach (self::entries($abs, $root) as $entry) {
                if (++$scanned > $max_scanned) {
                    $partial = true;
                    break 2;
                }
                $child = ($current === '' ? '' : $current . '/') . $entry['name'];
                if (is_dir($entry['real'])) {
                    $queue[] = array($child, $trail === '' ? $entry['name'] : $trail . ' › ' . $entry['name']);
                    continue;
                }
                $ext = self::ext($entry['name']);
                if (!is_file($entry['real']) || !isset(self::TYPES[$ext]) || mb_stripos($entry['name'], $term, 0, 'UTF-8') === false) {
                    continue;
                }
                $matches[] = array(
                    'name' => pathinfo($entry['name'], PATHINFO_FILENAME),
                    'ext'  => $ext,
                    'size' => self::format_size((int) @filesize($entry['real'])),
                    'date' => ($mtime = (int) @filemtime($entry['real'])) ? gmdate('c', $mtime) : '',
                    'url'  => self::url($section, $child),
                    'path' => $trail,
                );
                if (count($matches) >= $max_results) {
                    $partial = true;
                    break 2;
                }
            }
        }
        usort($matches, function ($a, $b) {
            $by_path = strnatcasecmp($a['path'], $b['path']);
            return $by_path !== 0 ? $by_path : strnatcasecmp($a['name'], $b['name']);
        });
        return array('files' => $matches, 'partial' => $partial);
    }

    public static function url($section, $rel, $size = '') {
        $id   = self::encode_id($rel);
        $args = array('setaredrive_file' => $section . ':' . $id, 't' => self::token($section, $id));
        if ($size !== '' && isset(self::SIZES[$size])) {
            $args['size'] = $size;
        }
        return add_query_arg($args, home_url('/'));
    }

    public static function format_size($bytes) {
        if ($bytes >= 1048576) {
            return number_format_i18n($bytes / 1048576, 1) . ' MB';
        }
        return number_format_i18n(max(1, round($bytes / 1024))) . ' KB';
    }

    /** Verificare pentru ecranul de setări. @return array|WP_Error */
    public static function test($input) {
        $resolved = self::resolve($input);
        if (is_wp_error($resolved)) {
            return $resolved;
        }
        $root    = $resolved;
        $folders = 0;
        $files   = 0;
        foreach (self::entries($root, $root) as $entry) {
            if (is_dir($entry['real'])) {
                $folders++;
            } elseif (is_file($entry['real']) && isset(self::TYPES[self::ext($entry['name'])])) {
                $files++;
            }
        }
        return array('path' => $resolved, 'folders' => $folders, 'files' => $files);
    }

    /* ----------------------------------------------------------- servire fișiere */

    public static function init() {
        add_action('init', array(__CLASS__, 'maybe_serve'), 1);
    }

    private static function stop($code, $message) {
        status_header($code);
        nocache_headers();
        header('Content-Type: text/plain; charset=utf-8');
        echo $message;
        exit;
    }

    public static function maybe_serve() {
        if (!isset($_GET['setaredrive_file'])) {
            return;
        }
        $param = sanitize_text_field(wp_unslash($_GET['setaredrive_file']));
        $token = isset($_GET['t']) ? sanitize_text_field(wp_unslash($_GET['t'])) : '';
        $size  = isset($_GET['size']) ? sanitize_key(wp_unslash($_GET['size'])) : '';
        $parts = explode(':', $param, 2);
        if (count($parts) !== 2 || !self::valid($parts[0], $parts[1], $token)) {
            self::stop(403, 'Acces interzis.');
        }
        $rel = self::decode_id($parts[1]);
        $abs = $rel === false ? false : self::path($parts[0], $rel);
        $ext = $abs ? self::ext($abs) : '';
        if ($abs === false || !is_file($abs) || !isset(self::TYPES[$ext])) {
            self::stop(404, 'Fișierul nu a fost găsit.');
        }
        $name = basename($abs);
        if ($name === '' || $name[0] === '.') {
            self::stop(404, 'Fișierul nu a fost găsit.');
        }

        $file = $abs;
        $mime = self::TYPES[$ext];
        if ($size !== '' && isset(self::SIZES[$size]) && in_array($ext, self::IMAGES, true)) {
            $resized = self::resized($abs, $size);
            if ($resized) {
                $file = $resized;
                $mime = 'image/jpeg';
            }
        }

        $mtime = (int) @filemtime($file);
        $etag  = '"' . md5($file . '|' . $mtime . '|' . @filesize($file)) . '"';
        header('ETag: ' . $etag);
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s', $mtime) . ' GMT');
        header('Cache-Control: public, max-age=3600');
        header('X-Content-Type-Options: nosniff');
        $match = isset($_SERVER['HTTP_IF_NONE_MATCH']) ? trim(wp_unslash($_SERVER['HTTP_IF_NONE_MATCH'])) : '';
        if ($match === $etag) {
            status_header(304);
            exit;
        }

        $inline   = in_array($ext, self::INLINE, true) && empty($_GET['dl']);
        $ascii    = preg_replace('/[^A-Za-z0-9._ -]/', '_', remove_accents($name));
        header('Content-Type: ' . $mime);
        header('Content-Length: ' . filesize($file));
        header('Content-Disposition: ' . ($inline ? 'inline' : 'attachment') . '; filename="' . $ascii . '"; filename*=UTF-8\'\'' . rawurlencode($name));
        while (ob_get_level()) {
            ob_end_clean();
        }
        readfile($file);
        exit;
    }

    /** Variantă redimensionată (JPEG), păstrată în uploads/setaredrive-cache. @return string|false */
    private static function resized($path, $size) {
        $uploads = wp_get_upload_dir();
        if (!empty($uploads['error'])) {
            return false;
        }
        $dir = trailingslashit($uploads['basedir']) . 'setaredrive-cache';
        if (!wp_mkdir_p($dir)) {
            return false;
        }
        if (!file_exists($dir . '/index.html')) {
            @file_put_contents($dir . '/index.html', '');
        }
        $target = $dir . '/' . md5($path . '|' . filemtime($path) . '|' . $size) . '.jpg';
        if (is_file($target)) {
            return $target;
        }
        $editor = wp_get_image_editor($path);
        if (is_wp_error($editor)) {
            return false;
        }
        if (method_exists($editor, 'maybe_exif_rotate')) {
            $editor->maybe_exif_rotate();
        }
        $dimensions = $editor->get_size();
        $limit      = self::SIZES[$size];
        if (!empty($dimensions['width']) && $dimensions['width'] > $limit) {
            $editor->resize($limit, null, false);
        }
        $editor->set_quality(82);
        $saved = $editor->save($target, 'image/jpeg');
        return (!is_wp_error($saved) && is_file($target)) ? $target : false;
    }
}
