<?php
/**
 * Pagini publice: Formulare, Media (carusel) și Monitorul Oficial Local (arbore de foldere).
 */

if (!defined('ABSPATH')) {
    exit;
}

final class SetareDrive_Frontend {
    const REST_NS = 'setaredrive/v1';

    public static function init() {
        $map = array(
            'setaredrive_formulare' => 'formulare',
            'setaredrive_media'     => 'media',
            'setaredrive_mol'       => 'mol',
            // Nume vechi, păstrate pentru paginile create de pluginul anterior.
            'pbv_formulare'         => 'formulare',
            'pbv_media_gallery'     => 'media',
            'pbv_mol_browser'       => 'mol',
        );
        foreach ($map as $tag => $method) {
            add_shortcode($tag, array(__CLASS__, $method));
        }
        add_action('wp_enqueue_scripts', array(__CLASS__, 'register_assets'));
        add_action('rest_api_init', array(__CLASS__, 'routes'));
    }

    /* ----------------------------------------------------------------- resurse */

    public static function register_assets() {
        wp_register_style('setaredrive', SETAREDRIVE_URL . 'assets/setaredrive.css', array(), SETAREDRIVE_VERSION);
        wp_register_script('setaredrive', SETAREDRIVE_URL . 'assets/setaredrive.js', array(), SETAREDRIVE_VERSION, true);
        wp_register_script('setaredrive-media', SETAREDRIVE_URL . 'assets/setaredrive-media.js', array(), SETAREDRIVE_VERSION, true);

        if (is_page(array('formulare', 'monitorul-oficial-local', 'media'))) {
            self::enqueue('browser');
            self::enqueue('media');
            return;
        }
        $post = get_post();
        if ($post instanceof WP_Post && is_singular()) {
            foreach (array('setaredrive_formulare', 'pbv_formulare', 'setaredrive_mol', 'pbv_mol_browser') as $tag) {
                if (has_shortcode($post->post_content, $tag)) {
                    self::enqueue('browser');
                }
            }
            foreach (array('setaredrive_media', 'pbv_media_gallery') as $tag) {
                if (has_shortcode($post->post_content, $tag)) {
                    self::enqueue('media');
                }
            }
        }
    }

    private static function enqueue($kind) {
        wp_enqueue_style('setaredrive');
        if ($kind === 'media') {
            wp_enqueue_script('setaredrive-media');
            return;
        }
        wp_enqueue_script('setaredrive');
        wp_localize_script('setaredrive', 'SetareDrive', array(
            'rest'    => esc_url_raw(rest_url(self::REST_NS . '/')),
            'strings' => array(
                'selectFirst' => 'Selectați mai întâi un folder din listă.',
                'enterTerm'   => 'Introduceți un termen de căutare.',
                'searching'   => 'Se caută fișiere în folderul selectat…',
                'noResults'   => 'Nu au fost găsite fișiere cu acest nume în folderul selectat.',
                'found'       => 'fișiere găsite',
                'failed'      => 'Căutarea nu a putut fi efectuată momentan.',
                'searchIn'    => 'Căutare în',
                'searchAll'   => 'Căutare în tot Monitorul Oficial Local',
                'partial'     => 'Rezultatele sunt parțiale (arhiva este foarte mare sau a durat prea mult). Restrângeți căutarea sau alegeți un folder.',
                'loading'     => 'Se încarcă…',
                'showChildren' => 'Arată subfolderele',
                'hideChildren' => 'Ascunde subfolderele',
                'docOne'      => 'document',
                'docMany'     => 'documente',
                'emptyFolder' => 'Acest folder nu conține documente.',
                'onlySubfolders' => 'Acest folder conține doar subfoldere. Alegeți un subfolder din listă pentru a vedea documentele.',
                'listFailed'  => 'Lista de documente nu poate fi încărcată momentan.',
            ),
        ));
    }

    /* ------------------------------------------------------------------- utile */

    private static function notice($title, $message, $admin_detail = '') {
        $extra = ($admin_detail !== '' && current_user_can('manage_options')) ? '<p class="sdrv-admin-note">' . esc_html($admin_detail) . '</p>' : '';
        return '<div class="sdrv-notice"><strong>' . esc_html($title) . '</strong><p>' . esc_html($message) . '</p>' . $extra . '</div>';
    }

    private static function embed_url($id) {
        return 'https://drive.google.com/embeddedfolderview?id=' . rawurlencode($id) . '#list';
    }

    private static function open_url($id) {
        return 'https://drive.google.com/drive/folders/' . rawurlencode($id);
    }

    private static function viewer_frame() {
        return '<div class="sdrv-frame-wrap"><iframe class="sdrv-frame" data-frame title="Documentele din folderul selectat" loading="lazy" referrerpolicy="strict-origin-when-cross-origin"></iframe></div>'
            . '<p class="sdrv-open"><a data-open-link href="https://drive.google.com" target="_blank" rel="noopener noreferrer">Deschide folderul în Google Drive</a></p>';
    }

    /**
     * Sursa activă a unei secțiuni: folderul de pe server (dacă e setat și valid), altfel Google Drive.
     *
     * @return array{type:string,id?:string,detail:string}
     */
    private static function source($section) {
        $detail = '';
        $local  = SetareDrive_Local::root($section);
        if (!is_wp_error($local)) {
            return array('type' => 'local', 'detail' => '');
        }
        if (SetareDrive_Local::option($section) !== '') {
            $detail = $local->get_error_message();
        }
        $drive = SetareDrive_API::folder_option($section);
        if ($drive !== '') {
            return array('type' => 'drive', 'id' => $drive, 'detail' => $detail);
        }
        return array('type' => 'none', 'detail' => $detail);
    }

    private static function count_label($count) {
        return $count . ' ' . ($count === 1 ? 'document' : 'documente');
    }

    private static function local_name($section, $rel) {
        if ($rel !== '') {
            return basename($rel);
        }
        $root = SetareDrive_Local::root($section);
        return is_wp_error($root) ? '' : basename($root);
    }

    /** Lista de documente a unui folder de pe server (aceeași structură este refăcută în JavaScript). */
    private static function local_list($section, $rel, $name) {
        $files = SetareDrive_Local::files($section, $rel);
        $files = is_wp_error($files) ? array() : $files;
        $html  = '<div class="sdrv-folder-head"><span class="sdrv-folder-icon" aria-hidden="true">📁</span><div><h3>' . esc_html($name) . '</h3><p>' . esc_html(self::count_label(count($files))) . '</p></div></div>';
        if (!$files) {
            $sub = SetareDrive_Local::folders($section, $rel);
            $msg = (!is_wp_error($sub) && $sub) ? 'Acest folder conține doar subfoldere. Alegeți un subfolder din listă pentru a vedea documentele.' : 'Acest folder nu conține documente.';
            return $html . '<p class="sdrv-empty">' . esc_html($msg) . '</p>';
        }
        $html .= '<ul class="sdrv-doclist">';
        foreach ($files as $file) {
            $html .= '<li><a class="sdrv-doc" href="' . esc_url($file['url']) . '" target="_blank" rel="noopener noreferrer">'
                . '<span class="sdrv-doc-ext" data-ext="' . esc_attr($file['ext']) . '">' . esc_html(strtoupper($file['ext'])) . '</span>'
                . '<span class="sdrv-doc-name">' . esc_html($file['name']) . '</span>'
                . '<span class="sdrv-doc-size">' . esc_html(SetareDrive_Local::format_size($file['size'])) . '</span></a></li>';
        }
        return $html . '</ul>';
    }

    /* ---------------------------------------------------------------- formulare */

    public static function formulare() {
        self::enqueue('browser');
        $src = self::source('formulare');
        if ($src['type'] === 'none') {
            return self::notice('Formulare', 'Nu este setată locația formularelor (folder pe server sau ID Google Drive). Administratorul o poate adăuga în Setări → SetareDrive.', $src['detail']);
        }
        if ($src['type'] === 'local') {
            return self::formulare_local();
        }

        $root    = $src['id'];
        $buttons = array();
        $folders = SetareDrive_API::folders($root);
        $detail  = $src['detail'];
        if (is_wp_error($folders)) {
            $detail  = $folders->get_error_message();
            $folders = array();
        }
        $has_files = $folders ? SetareDrive_API::has_files($root) : true;
        if ($has_files === true || is_wp_error($has_files)) {
            $buttons[] = array('id' => $root, 'name' => $folders ? 'Toate formularele' : 'Formulare');
        }
        foreach ($folders as $folder) {
            $buttons[] = array('id' => $folder['id'], 'name' => $folder['name']);
        }
        $initial = $buttons ? $buttons[0]['id'] : $root;

        ob_start();
        echo '<div class="sdrv-forms" data-sdrv-browser data-initial="' . esc_attr($initial) . '">';
        if ($detail !== '') {
            echo self::notice('Formulare', 'Lista subfolderelor nu poate fi încărcată momentan.', $detail);
        }
        if (count($buttons) > 1) {
            echo '<div class="sdrv-buttons" role="group" aria-label="Categorii de formulare">';
            foreach ($buttons as $button) {
                echo '<button type="button" class="sdrv-folder-btn" data-folder="' . esc_attr($button['id']) . '" aria-pressed="false">' . esc_html($button['name']) . '</button>';
            }
            echo '</div>';
        }
        echo '<div class="sdrv-viewer">' . self::viewer_frame() . '</div></div>';
        return ob_get_clean();
    }

    private static function formulare_local() {
        $folders = SetareDrive_Local::folders('formulare', '');
        $folders = is_wp_error($folders) ? array() : $folders;
        $root_files = SetareDrive_Local::files('formulare', '');
        $has_files  = !is_wp_error($root_files) && !empty($root_files);

        $buttons = array();
        if ($has_files || !$folders) {
            $id        = SetareDrive_Local::encode_id('');
            $buttons[] = array('id' => $id, 'name' => $folders ? 'Toate formularele' : 'Formulare', 't' => SetareDrive_Local::token('formulare', $id), 'rel' => '');
        }
        foreach ($folders as $folder) {
            $buttons[] = array('id' => $folder['id'], 'name' => $folder['name'], 't' => $folder['t'], 'rel' => SetareDrive_Local::decode_id($folder['id']));
        }
        $first = $buttons[0];

        ob_start();
        echo '<div class="sdrv-forms" data-sdrv-browser data-source="local" data-section="formulare" data-initial="' . esc_attr($first['id']) . '" data-token="' . esc_attr($first['t']) . '">';
        if (count($buttons) > 1) {
            echo '<div class="sdrv-buttons" role="group" aria-label="Categorii de formulare">';
            foreach ($buttons as $button) {
                echo '<button type="button" class="sdrv-folder-btn" data-folder="' . esc_attr($button['id']) . '" data-token="' . esc_attr($button['t']) . '" aria-pressed="false">' . esc_html($button['name']) . '</button>';
            }
            echo '</div>';
        }
        $label = $first['rel'] === '' ? self::local_name('formulare', '') : $first['name'];
        echo '<div class="sdrv-viewer"><div class="sdrv-local" data-local-list aria-live="polite">' . self::local_list('formulare', (string) $first['rel'], $label) . '</div></div></div>';
        return ob_get_clean();
    }

    /* -------------------------------------------------------------------- media */

    public static function media() {
        self::enqueue('media');
        $src = self::source('foto');
        $items = array();
        if ($src['type'] === 'local') {
            foreach (SetareDrive_Local::images('foto') as $image) {
                $items[] = array('big' => $image['big'], 'thumb' => $image['thumb'], 'video' => '');
            }
        } elseif ($src['type'] === 'drive') {
            $found = SetareDrive_API::media($src['id']);
            foreach (is_wp_error($found) ? array() : $found as $item) {
                $id      = rawurlencode($item['id']);
                $items[] = array(
                    'big'   => 'https://drive.google.com/thumbnail?id=' . $id . '&sz=w1600',
                    'thumb' => 'https://drive.google.com/thumbnail?id=' . $id . '&sz=w240',
                    'video' => strpos((string) $item['mimeType'], 'video/') === 0 ? 'https://drive.google.com/file/d/' . $id . '/preview' : '',
                );
            }
        }
        if (!$items) {
            return '';
        }

        $count = count($items);
        ob_start();
        ?>
        <section class="sdrv-gallery" data-sdrv-gallery role="region" aria-roledescription="carusel" aria-label="Galerie foto">
            <div class="sdrv-stage">
                <ol class="sdrv-track" data-track>
                    <?php foreach ($items as $i => $item) : ?>
                        <li class="sdrv-slide<?php echo $item['video'] !== '' ? ' is-video' : ''; ?>" data-slide aria-label="<?php echo esc_attr(($i + 1) . ' din ' . $count); ?>"<?php echo $item['video'] !== '' ? ' data-video="' . esc_url($item['video']) . '"' : ''; ?>>
                            <img src="<?php echo esc_url($item['big']); ?>" alt="" loading="<?php echo $i === 0 ? 'eager' : 'lazy'; ?>" decoding="async" referrerpolicy="no-referrer">
                        </li>
                    <?php endforeach; ?>
                </ol>
                <?php if ($count > 1) : ?>
                    <button type="button" class="sdrv-arrow sdrv-prev" data-prev aria-label="Fotografia anterioară" hidden>&#8249;</button>
                    <button type="button" class="sdrv-arrow sdrv-next" data-next aria-label="Fotografia următoare" hidden>&#8250;</button>
                <?php endif; ?>
            </div>
            <?php if ($count > 1) : ?>
                <div class="sdrv-rail" data-rail role="group" aria-label="Alegeți o fotografie" hidden>
                    <?php foreach ($items as $i => $item) : ?>
                        <button type="button" class="sdrv-thumb" data-thumb="<?php echo (int) $i; ?>" aria-label="<?php echo esc_attr('Fotografia ' . ($i + 1) . ' din ' . $count); ?>" aria-pressed="false">
                            <img src="<?php echo esc_url($item['thumb']); ?>" alt="" loading="lazy" decoding="async" referrerpolicy="no-referrer">
                        </button>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
        <?php
        return ob_get_clean();
    }

    /* --------------------------------------------------------- Monitorul Oficial */

    private static function node($folder, $open_children = false) {
        $id = $folder['id'];
        $token = isset($folder['t']) ? $folder['t'] : SetareDrive_API::token($id);
        return '<li class="sdrv-node" data-id="' . esc_attr($id) . '" data-token="' . esc_attr($token) . '">'
            . '<div class="sdrv-node-row">'
            . '<button type="button" class="sdrv-toggle" aria-expanded="' . ($open_children ? 'true' : 'false') . '" aria-label="Arată subfolderele"><span aria-hidden="true"></span></button>'
            . '<button type="button" class="sdrv-folder-btn" data-folder="' . esc_attr($id) . '" aria-pressed="false"><span aria-hidden="true">📁</span> ' . esc_html($folder['name']) . '</button>'
            . '</div>'
            . '<ul class="sdrv-tree-list" role="group"' . ($open_children ? '' : ' hidden') . '></ul>'
            . '</li>';
    }

    private static function tree_root($root_id, $token, $label, $children) {
        $tree = '<ul class="sdrv-tree-list sdrv-tree-root" role="tree">'
            . '<li class="sdrv-node is-open" data-id="' . esc_attr($root_id) . '" data-token="' . esc_attr($token) . '" data-loaded="1">'
            . '<div class="sdrv-node-row"><button type="button" class="sdrv-folder-btn" data-folder="' . esc_attr($root_id) . '" aria-pressed="false"><span aria-hidden="true">📁</span> ' . esc_html($label) . '</button></div>'
            . '<ul class="sdrv-tree-list" role="group">';
        foreach ($children as $child) {
            $tree .= self::node($child);
        }
        return $tree . '</ul></li></ul>';
    }

    public static function mol() {
        self::enqueue('browser');
        $src     = self::source('mol');
        $type    = $src['type'];
        $message = 'Selectați un folder din listă pentru a vedea documentele.';
        $tree    = '';
        $detail  = $src['detail'];
        $initial = '';
        $token   = '';
        $viewer  = '';

        if ($type === 'none') {
            $message = 'Nu este setată locația documentelor (folder pe server sau ID Google Drive). Administratorul o poate adăuga în Setări → SetareDrive.';
        } elseif ($type === 'local') {
            $initial  = SetareDrive_Local::encode_id('');
            $token    = SetareDrive_Local::token('mol', $initial);
            $children = SetareDrive_Local::folders('mol', '');
            $label    = self::local_name('mol', '');
            $tree     = self::tree_root($initial, $token, $label !== '' ? $label : 'Monitorul Oficial Local', is_wp_error($children) ? array() : $children);
            $viewer   = '<div class="sdrv-local" data-local-list aria-live="polite">' . self::local_list('mol', '', $label) . '</div>';
        } else {
            $initial  = $src['id'];
            $token    = SetareDrive_API::token($initial);
            $children = SetareDrive_API::folders($initial);
            if (is_wp_error($children)) {
                $detail = $children->get_error_message();
                $tree   = '<p class="sdrv-tree-empty">Lista de foldere nu poate fi încărcată momentan. Conținutul principal rămâne disponibil în caseta din dreapta.</p>';
            } else {
                $name = SetareDrive_API::folder_name($initial);
                $tree = self::tree_root($initial, $token, $name !== '' ? $name : 'Monitorul Oficial Local', $children);
            }
            $viewer = self::viewer_frame();
        }

        ob_start();
        ?>
        <div class="sdrv-mol" data-sdrv-browser data-sdrv-mol<?php echo $type === 'local' ? ' data-source="local" data-section="mol"' : ''; ?> data-initial="<?php echo esc_attr($initial); ?>" data-token="<?php echo esc_attr($token); ?>">
            <?php echo self::notice('Arhiva oficială de documente', $message, $detail); ?>
            <div class="sdrv-layout">
                <nav class="sdrv-tree" aria-label="Foldere Monitorul Oficial Local">
                    <h2>Structura arhivei</h2>
                    <?php echo $tree; // phpcs:ignore WordPress.Security.EscapeOutput ?>
                </nav>
                <section class="sdrv-viewer" aria-label="Documentele din folderul selectat">
                    <div class="sdrv-selected"><strong>Folder selectat:</strong> <span data-selected>—</span></div>
                    <form class="sdrv-search" data-search-form>
                        <label for="sdrv-search-input">Caută în numele fișierelor din folderul selectat</label>
                        <div><input id="sdrv-search-input" type="search" data-search-input placeholder="Ex.: hotărâre, buget, dispoziție…"><button class="sdrv-btn" type="submit">Caută</button></div>
                        <label class="sdrv-check"><input type="checkbox" data-search-all> Caută în toate subfolderele (în tot Monitorul Oficial Local)</label>
                    </form>
                    <p class="sdrv-search-note" data-search-note></p>
                    <div class="sdrv-results" data-search-results aria-live="polite"></div>
                    <?php echo $viewer; // phpcs:ignore WordPress.Security.EscapeOutput ?>
                </section>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /* --------------------------------------------------------------------- REST */

    public static function routes() {
        register_rest_route(self::REST_NS, '/children', array(
            'methods'             => 'GET',
            'callback'            => array(__CLASS__, 'rest_children'),
            'permission_callback' => '__return_true',
            'args'                => array(
                'id' => array('required' => true, 'sanitize_callback' => 'sanitize_text_field'),
                't'  => array('required' => true, 'sanitize_callback' => 'sanitize_text_field'),
            ),
        ));
        foreach (array('children' => 'rest_local_children', 'files' => 'rest_local_files', 'search' => 'rest_local_search') as $route => $callback) {
            $args = array(
                'sec' => array('required' => true, 'sanitize_callback' => 'sanitize_key'),
                'id'  => array('required' => true, 'sanitize_callback' => 'sanitize_text_field'),
                't'   => array('required' => true, 'sanitize_callback' => 'sanitize_text_field'),
            );
            if ($route === 'search') {
                $args['q']   = array('required' => true, 'sanitize_callback' => 'sanitize_text_field');
                $args['all'] = array('required' => false, 'sanitize_callback' => 'absint');
            }
            register_rest_route(self::REST_NS, '/local/' . $route, array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, $callback),
                'permission_callback' => '__return_true',
                'args'                => $args,
            ));
        }
        register_rest_route(self::REST_NS, '/search', array(
            'methods'             => 'GET',
            'callback'            => array(__CLASS__, 'rest_search'),
            'permission_callback' => '__return_true',
            'args'                => array(
                'id' => array('required' => true, 'sanitize_callback' => 'sanitize_text_field'),
                't'  => array('required' => true, 'sanitize_callback' => 'sanitize_text_field'),
                'q'  => array('required' => true, 'sanitize_callback' => 'sanitize_text_field'),
                'all' => array('required' => false, 'sanitize_callback' => 'absint'),
            ),
        ));
    }

    public static function rest_children($request) {
        $id = SetareDrive_API::clean_id($request['id']);
        if (!SetareDrive_API::valid_token($id, $request['t'])) {
            return new WP_Error('setaredrive_forbidden', 'Folder nepermis.', array('status' => 403));
        }
        $folders = SetareDrive_API::folders($id);
        if (is_wp_error($folders)) {
            return new WP_Error('setaredrive_unavailable', 'Lista nu poate fi încărcată.', array('status' => 502));
        }
        $out = array();
        foreach ($folders as $folder) {
            $out[] = array('id' => $folder['id'], 'name' => $folder['name'], 't' => SetareDrive_API::token($folder['id']));
        }
        return rest_ensure_response(array('folders' => $out));
    }

    public static function rest_search($request) {
        $id = SetareDrive_API::clean_id($request['id']);
        if (!SetareDrive_API::valid_token($id, $request['t'])) {
            return new WP_Error('setaredrive_forbidden', 'Folder nepermis.', array('status' => 403));
        }
        $term = trim((string) $request['q']);
        if ($term === '') {
            return rest_ensure_response(array('files' => array()));
        }
        if (!empty($request['all'])) {
            @set_time_limit(60);
            $found = SetareDrive_API::search_tree($id, $term);
            if (is_wp_error($found)) {
                return new WP_Error('setaredrive_unavailable', 'Căutarea nu poate fi efectuată.', array('status' => 502));
            }
            return rest_ensure_response($found);
        }
        $files = SetareDrive_API::files($id);
        if (is_wp_error($files)) {
            return new WP_Error('setaredrive_unavailable', 'Căutarea nu poate fi efectuată.', array('status' => 502));
        }
        $out = array();
        foreach ($files as $file) {
            if (mb_stripos((string) $file['name'], $term, 0, 'UTF-8') === false) {
                continue;
            }
            $out[] = array(
                'name' => (string) $file['name'],
                'url'  => isset($file['webViewLink']) ? (string) $file['webViewLink'] : 'https://drive.google.com/open?id=' . rawurlencode($file['id']),
                'date' => isset($file['modifiedTime']) ? (string) $file['modifiedTime'] : '',
            );
            if (count($out) >= 200) {
                break;
            }
        }
        return rest_ensure_response(array('files' => $out));
    }

    /* ---- sursa „folder pe server” ---- */

    private static function local_rel($request) {
        $section = (string) $request['sec'];
        $id      = (string) $request['id'];
        if (!SetareDrive_Local::valid($section, $id, (string) $request['t'])) {
            return new WP_Error('setaredrive_forbidden', 'Folder nepermis.', array('status' => 403));
        }
        $rel = SetareDrive_Local::decode_id($id);
        if ($rel === false || SetareDrive_Local::path($section, $rel) === false) {
            return new WP_Error('setaredrive_missing', 'Folderul nu a fost găsit.', array('status' => 404));
        }
        return array($section, $rel);
    }

    public static function rest_local_children($request) {
        $target = self::local_rel($request);
        if (is_wp_error($target)) {
            return $target;
        }
        $folders = SetareDrive_Local::folders($target[0], $target[1]);
        if (is_wp_error($folders)) {
            return new WP_Error('setaredrive_unavailable', 'Lista nu poate fi încărcată.', array('status' => 502));
        }
        return rest_ensure_response(array('folders' => $folders));
    }

    private static function local_files_payload($files) {
        $out = array();
        foreach ($files as $file) {
            $out[] = array(
                'name' => $file['name'],
                'ext'  => $file['ext'],
                'size' => SetareDrive_Local::format_size($file['size']),
                'date' => $file['mtime'] ? gmdate('c', $file['mtime']) : '',
                'url'  => $file['url'],
            );
        }
        return $out;
    }

    public static function rest_local_files($request) {
        $target = self::local_rel($request);
        if (is_wp_error($target)) {
            return $target;
        }
        $files = SetareDrive_Local::files($target[0], $target[1]);
        if (is_wp_error($files)) {
            return new WP_Error('setaredrive_unavailable', 'Lista nu poate fi încărcată.', array('status' => 502));
        }
        return rest_ensure_response(array(
            'name'  => self::local_name($target[0], $target[1]),
            'count' => count($files),
            'subfolders' => ($sub = SetareDrive_Local::folders($target[0], $target[1])) && !is_wp_error($sub) ? count($sub) : 0,
            'files' => self::local_files_payload($files),
        ));
    }

    public static function rest_local_search($request) {
        $target = self::local_rel($request);
        if (is_wp_error($target)) {
            return $target;
        }
        $term = trim((string) $request['q']);
        if ($term !== '' && !empty($request['all'])) {
            $found = SetareDrive_Local::search_tree($target[0], $target[1], $term);
            if (is_wp_error($found)) {
                return new WP_Error('setaredrive_unavailable', 'Căutarea nu poate fi efectuată.', array('status' => 502));
            }
            return rest_ensure_response($found);
        }
        $files = SetareDrive_Local::files($target[0], $target[1]);
        if ($term === '' || is_wp_error($files)) {
            return rest_ensure_response(array('files' => array()));
        }
        $matches = array();
        foreach ($files as $file) {
            if (mb_stripos($file['file'], $term, 0, 'UTF-8') !== false) {
                $matches[] = $file;
            }
        }
        return rest_ensure_response(array('files' => array_slice(self::local_files_payload($matches), 0, 200)));
    }
}
