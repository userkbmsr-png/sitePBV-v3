<?php
/**
 * Acces la Google Drive API v3 (doar citire), din server.
 *
 * Cheia API nu ajunge în browser. Listele de foldere se păstrează în cache,
 * iar folderele trimise către browser primesc un jeton semnat (HMAC) pentru a
 * împiedica folosirea endpoint-urilor REST ca proxy către foldere arbitrare.
 */

if (!defined('ABSPATH')) {
    exit;
}

final class SetareDrive_API {
    const BASE        = 'https://www.googleapis.com/drive/v3/files';
    const FOLDER_MIME = 'application/vnd.google-apps.folder';
    const CACHE_TTL   = 900;

    /** Adresa de bază a API-ului (filtrabilă pentru teste sau proxy). */
    private static function base() {
        return (string) apply_filters('setaredrive_api_base', self::BASE);
    }

    /** Cheia API: constanta SETAREDRIVE_API_KEY (wp-config.php) sau setarea din administrare. */
    public static function key() {
        if (defined('SETAREDRIVE_API_KEY') && SETAREDRIVE_API_KEY) {
            return (string) SETAREDRIVE_API_KEY;
        }
        return trim((string) get_option('setaredrive_api_key', ''));
    }

    /** Acceptă un ID sau un link Google Drive și returnează ID-ul folderului. */
    public static function clean_id($input) {
        $input = trim((string) $input);
        if ($input === '') {
            return '';
        }
        if (preg_match('~/folders/([A-Za-z0-9_-]{10,})~', $input, $m)) {
            return $m[1];
        }
        if (preg_match('~[?&]id=([A-Za-z0-9_-]{10,})~', $input, $m)) {
            return $m[1];
        }
        return preg_match('/^[A-Za-z0-9_-]{10,}$/', $input) ? $input : '';
    }

    public static function folder_option($which) {
        $map = array(
            'formulare' => 'setaredrive_folder_formulare',
            'foto'      => 'setaredrive_folder_foto',
            'mol'       => 'setaredrive_folder_mol',
        );
        return isset($map[$which]) ? self::clean_id(get_option($map[$which], '')) : '';
    }

    public static function token($id) {
        return substr(hash_hmac('sha256', (string) $id, wp_salt('auth')), 0, 24);
    }

    public static function valid_token($id, $token) {
        return is_string($token) && $id !== '' && hash_equals(self::token($id), $token);
    }

    private static function cache_version() {
        return (int) get_option('setaredrive_cache_v', 1);
    }

    public static function flush_cache() {
        update_option('setaredrive_cache_v', self::cache_version() + 1, false);
    }

    /** Cerere către Drive cu cache. Erorile se păstrează 60 de secunde pentru a nu încărca API-ul. */
    private static function request($params, $cache_id, $ttl = self::CACHE_TTL) {
        $key = self::key();
        if ($key === '') {
            return new WP_Error('setaredrive_no_key', 'Nu este setată cheia API Google Drive.');
        }
        $cache_key = 'sdrv_' . md5(self::cache_version() . '|' . $cache_id);
        $cached    = get_transient($cache_key);
        if (is_array($cached)) {
            if (isset($cached['__error'])) {
                return new WP_Error('setaredrive_api', (string) $cached['__error']);
            }
            return $cached;
        }

        $params['key']                       = $key;
        $params['supportsAllDrives']         = 'true';
        $params['includeItemsFromAllDrives'] = 'true';
        $url      = self::base() . (isset($params['__path']) ? '/' . rawurlencode($params['__path']) : '');
        unset($params['__path']);
        $response = wp_remote_get($url . '?' . http_build_query($params, '', '&', PHP_QUERY_RFC3986), array('timeout' => 15));
        if (is_wp_error($response)) {
            $message = 'Conexiunea la Google Drive a eșuat: ' . $response->get_error_message();
            set_transient($cache_key, array('__error' => $message), 60);
            return new WP_Error('setaredrive_http', $message);
        }
        $code = (int) wp_remote_retrieve_response_code($response);
        $data = json_decode(wp_remote_retrieve_body($response), true);
        if ($code !== 200 || !is_array($data)) {
            $reason  = isset($data['error']['message']) ? (string) $data['error']['message'] : 'HTTP ' . $code;
            $message = self::explain($code, $reason);
            set_transient($cache_key, array('__error' => $message), 60);
            return new WP_Error('setaredrive_api', $message);
        }
        set_transient($cache_key, $data, $ttl);
        return $data;
    }

    private static function explain($code, $reason) {
        if ($code === 404) {
            return 'Folderul nu a fost găsit sau nu este partajat public (Oricine are linkul – Vizualizator). Verificați ID-ul.';
        }
        if ($code === 400 && stripos($reason, 'API key') !== false) {
            return 'Cheia API Google este invalidă.';
        }
        if ($code === 403) {
            return 'Google a refuzat cererea (cheie restricționată, Drive API neactivat sau cotă depășită): ' . $reason;
        }
        return 'Google Drive a răspuns cu eroare: ' . $reason;
    }

    /** Parcurge toate paginile unei liste de fișiere. */
    private static function listing($query, $fields, $order, $cache_id) {
        $items = array();
        $token = '';
        for ($page = 0; $page < 10; $page++) {
            $params = array(
                'q'        => $query,
                'fields'   => 'nextPageToken,files(' . $fields . ')',
                'pageSize' => 1000,
            );
            if ($order !== '') {
                $params['orderBy'] = $order;
            }
            if ($token !== '') {
                $params['pageToken'] = $token;
            }
            $data = self::request($params, $cache_id . '|' . $token);
            if (is_wp_error($data)) {
                return $data;
            }
            $items = array_merge($items, isset($data['files']) && is_array($data['files']) ? $data['files'] : array());
            $token = isset($data['nextPageToken']) ? (string) $data['nextPageToken'] : '';
            if ($token === '') {
                break;
            }
        }
        return $items;
    }

    private static function in_parent($id) {
        return "'" . str_replace("'", '', $id) . "' in parents and trashed = false";
    }

    /** Numele folderului. */
    public static function folder_name($id) {
        $data = self::request(array('__path' => $id, 'fields' => 'id,name,mimeType'), 'name|' . $id);
        if (is_wp_error($data) || empty($data['name'])) {
            return '';
        }
        return (string) $data['name'];
    }

    /** Ani descrescător dacă toate numele sunt ani, altfel alfabetic natural. Folosit și de sursa locală. */
    public static function sort_folders($items) {
        $all_years = !empty($items);
        foreach ($items as $item) {
            if (!preg_match('/^\d{4}$/', (string) $item['name'])) {
                $all_years = false;
                break;
            }
        }
        usort($items, function ($a, $b) use ($all_years) {
            return $all_years ? ((int) $b['name'] <=> (int) $a['name']) : strnatcasecmp($a['name'], $b['name']);
        });
        return $items;
    }

    /** Subfolderele directe. */
    public static function folders($id) {
        $items = self::listing(self::in_parent($id) . " and mimeType = '" . self::FOLDER_MIME . "'", 'id,name', 'name', 'folders|' . $id);
        if (is_wp_error($items)) {
            return $items;
        }
        return self::sort_folders($items);
    }

    /** Există fișiere (nu foldere) direct în acest folder? */
    public static function has_files($id) {
        $data = self::request(array(
            'q'        => self::in_parent($id) . " and mimeType != '" . self::FOLDER_MIME . "'",
            'fields'   => 'files(id)',
            'pageSize' => 1,
        ), 'hasfiles|' . $id);
        if (is_wp_error($data)) {
            return $data;
        }
        return !empty($data['files']);
    }

    /** Fișierele (nu folderele) dintr-un folder, pentru căutare. */
    public static function files($id) {
        return self::listing(self::in_parent($id) . " and mimeType != '" . self::FOLDER_MIME . "'", 'id,name,mimeType,webViewLink,modifiedTime', 'name', 'files|' . $id);
    }

    /** Imagini și videoclipuri din folder și din subfoldere (până la 2 niveluri), cel mult $cap elemente. */
    public static function media($root, $depth = 2, $cap = 300) {
        $found = array();
        $queue = array(array($root, 0));
        while ($queue && count($found) < $cap) {
            list($id, $level) = array_shift($queue);
            $items = self::listing(
                self::in_parent($id) . " and (mimeType contains 'image/' or mimeType contains 'video/')",
                'id,name,mimeType',
                'createdTime desc',
                'media|' . $id
            );
            if (is_wp_error($items)) {
                if ($level === 0) {
                    return $items;
                }
                continue;
            }
            foreach ($items as $item) {
                $found[] = $item;
                if (count($found) >= $cap) {
                    break 2;
                }
            }
            if ($level < $depth) {
                $folders = self::folders($id);
                if (!is_wp_error($folders)) {
                    foreach ($folders as $folder) {
                        $queue[] = array($folder['id'], $level + 1);
                    }
                }
            }
        }
        return $found;
    }

    /* ------------------------------------------------- căutare în tot subarborele */

    private static function children_fields() {
        return 'id,name,mimeType,webViewLink,modifiedTime';
    }

    private static function children_cache_key($id) {
        return 'sdrv_' . md5(self::cache_version() . '|children|' . $id . '|');
    }

    /** Descarcă în paralel prima pagină a listelor de conținut care nu sunt încă în cache. */
    private static function prefetch(array $ids) {
        $key = self::key();
        if ($key === '') {
            return;
        }
        $class = class_exists('\WpOrg\Requests\Requests') ? '\WpOrg\Requests\Requests' : (class_exists('Requests') ? 'Requests' : '');
        if ($class === '') {
            return;
        }
        $requests = array();
        foreach ($ids as $id) {
            if (get_transient(self::children_cache_key($id)) !== false) {
                continue;
            }
            $params = array(
                'q'                         => self::in_parent($id),
                'fields'                    => 'nextPageToken,files(' . self::children_fields() . ')',
                'pageSize'                  => 1000,
                'key'                       => $key,
                'supportsAllDrives'         => 'true',
                'includeItemsFromAllDrives' => 'true',
            );
            $requests[$id] = array(
                'url'     => self::base() . '?' . http_build_query($params, '', '&', PHP_QUERY_RFC3986),
                'headers' => array(),
                'data'    => array(),
                'type'    => 'GET',
            );
        }
        if (!$requests) {
            return;
        }
        try {
            $responses = $class::request_multiple($requests, array('timeout' => 15));
        } catch (\Throwable $e) {
            return;
        }
        foreach ($responses as $id => $response) {
            if (is_object($response) && isset($response->status_code, $response->body) && (int) $response->status_code === 200) {
                $data = json_decode($response->body, true);
                if (is_array($data)) {
                    set_transient(self::children_cache_key($id), $data, self::CACHE_TTL);
                }
            }
        }
    }

    /**
     * Caută după nume în folderul indicat și în toate subfolderele lui.
     * Listele de conținut se păstrează în cache pe folder, deci căutările următoare sunt rapide.
     *
     * @return array{files:array,partial:bool}|WP_Error
     */
    public static function search_tree($root, $term, $budget = 25, $max_folders = 600, $max_results = 200) {
        $deadline = microtime(true) + $budget;
        $queue    = array(array($root, ''));
        $folders  = 0;
        $matches  = array();
        $partial  = false;
        while ($queue) {
            if (microtime(true) > $deadline || $folders >= $max_folders) {
                $partial = true;
                break;
            }
            $batch = array_splice($queue, 0, 8);
            self::prefetch(array_column($batch, 0));
            foreach ($batch as $entry) {
                list($id, $path) = $entry;
                $folders++;
                $items = self::listing(self::in_parent($id), self::children_fields(), '', 'children|' . $id);
                if (is_wp_error($items)) {
                    if ($id === $root) {
                        return $items;
                    }
                    $partial = true;
                    continue;
                }
                foreach ($items as $item) {
                    if (isset($item['mimeType']) && $item['mimeType'] === self::FOLDER_MIME) {
                        $queue[] = array($item['id'], $path === '' ? $item['name'] : $path . ' › ' . $item['name']);
                    } elseif (mb_stripos((string) $item['name'], $term, 0, 'UTF-8') !== false) {
                        $matches[] = array(
                            'name' => (string) $item['name'],
                            'url'  => isset($item['webViewLink']) ? (string) $item['webViewLink'] : 'https://drive.google.com/open?id=' . rawurlencode($item['id']),
                            'date' => isset($item['modifiedTime']) ? (string) $item['modifiedTime'] : '',
                            'path' => $path,
                        );
                        if (count($matches) >= $max_results) {
                            $partial = true;
                            break 3;
                        }
                    }
                }
            }
        }
        usort($matches, function ($a, $b) {
            $by_path = strnatcasecmp($a['path'], $b['path']);
            return $by_path !== 0 ? $by_path : strnatcasecmp($a['name'], $b['name']);
        });
        return array('files' => $matches, 'partial' => $partial);
    }

    /** Verificare pentru ecranul de setări: numele folderului și numărul de subfoldere. */
    public static function test($id) {
        $name = self::request(array('__path' => $id, 'fields' => 'id,name,mimeType'), 'test|' . $id, 5);
        if (is_wp_error($name)) {
            return $name;
        }
        if (isset($name['mimeType']) && $name['mimeType'] !== self::FOLDER_MIME) {
            return new WP_Error('setaredrive_not_folder', 'ID-ul indicat nu este un folder.');
        }
        $folders = self::folders($id);
        if (is_wp_error($folders)) {
            return $folders;
        }
        return array('name' => (string) $name['name'], 'folders' => count($folders));
    }
}
