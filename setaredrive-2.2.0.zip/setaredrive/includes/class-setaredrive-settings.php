<?php
/**
 * Setări → SetareDrive: ID-urile folderelor Google Drive și cheia API.
 */

if (!defined('ABSPATH')) {
    exit;
}

final class SetareDrive_Settings {
    const SLUG = 'setaredrive';

    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'menu'));
        add_action('admin_post_setaredrive_save', array(__CLASS__, 'handle_save'));
        add_action('admin_post_setaredrive_flush', array(__CLASS__, 'handle_flush'));
        add_action('wp_ajax_setaredrive_test', array(__CLASS__, 'ajax_test'));
        add_action('admin_enqueue_scripts', array(__CLASS__, 'assets'));
    }

    public static function menu() {
        add_options_page('SetareDrive', 'SetareDrive', 'manage_options', self::SLUG, array(__CLASS__, 'render'));
    }

    public static function assets($hook) {
        if ($hook !== 'settings_page_' . self::SLUG) {
            return;
        }
        wp_enqueue_script('setaredrive-admin', SETAREDRIVE_URL . 'assets/admin.js', array(), SETAREDRIVE_VERSION, true);
        wp_localize_script('setaredrive-admin', 'SetareDriveAdmin', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('setaredrive_test'),
        ));
    }

    private static function back($code) {
        wp_safe_redirect(add_query_arg(array('page' => self::SLUG, 'sd' => $code), admin_url('options-general.php')));
        exit;
    }

    public static function handle_save() {
        if (!current_user_can('manage_options')) {
            wp_die('Nu aveți permisiunea de a modifica aceste setări.', 403);
        }
        check_admin_referer('setaredrive_save', 'setaredrive_nonce');

        $invalid  = false;
        $messages = array();
        $labels   = array('formulare' => 'Formulare', 'foto' => 'Fotografii', 'mol' => 'Monitorul Oficial Local');
        foreach (array('formulare', 'foto', 'mol') as $which) {
            $raw = isset($_POST['folder_' . $which]) ? sanitize_text_field(wp_unslash($_POST['folder_' . $which])) : '';
            $id  = SetareDrive_API::clean_id($raw);
            if ($raw !== '' && $id === '') {
                $invalid = true;
                $messages[] = $labels[$which] . ': ID-ul Google Drive nu a fost recunoscut.';
            }
            update_option('setaredrive_folder_' . $which, $id, false);

            $local = isset($_POST['local_' . $which]) ? trim(sanitize_text_field(wp_unslash($_POST['local_' . $which]))) : '';
            $local = str_replace('\\', '/', $local);
            update_option('setaredrive_local_' . $which, $local, false);
            $result = SetareDrive_Local::ensure($local);
            if ($result['status'] === 'invalid') {
                $invalid = true;
                $messages[] = $labels[$which] . ' (folder pe server): ' . $result['message'];
            } elseif ($result['status'] === 'created') {
                $messages[] = $labels[$which] . ': folderul a fost creat pe server (' . $result['message'] . ').';
            }
        }
        set_transient('setaredrive_msgs_' . get_current_user_id(), $messages, 300);
        $key = isset($_POST['api_key']) ? trim(sanitize_text_field(wp_unslash($_POST['api_key']))) : '';
        if ($key !== '') {
            update_option('setaredrive_api_key', $key, false);
        }
        if (!empty($_POST['clear_key'])) {
            update_option('setaredrive_api_key', '', false);
        }
        SetareDrive_API::flush_cache();
        self::back($invalid ? 'invalid' : 'saved');
    }

    public static function handle_flush() {
        if (!current_user_can('manage_options')) {
            wp_die('Nu aveți permisiunea necesară.', 403);
        }
        check_admin_referer('setaredrive_flush');
        SetareDrive_API::flush_cache();
        self::back('flushed');
    }

    public static function ajax_test() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Nu aveți permisiunea necesară.'), 403);
        }
        check_ajax_referer('setaredrive_test', 'nonce');
        $kind  = isset($_POST['kind']) ? sanitize_key(wp_unslash($_POST['kind'])) : 'drive';
        $value = isset($_POST['id']) ? sanitize_text_field(wp_unslash($_POST['id'])) : '';
        if ($kind === 'local') {
            $result = SetareDrive_Local::test(str_replace('\\', '/', $value));
            if (is_wp_error($result)) {
                $hint = $result->get_error_code() === 'setaredrive_local_missing' ? ' La salvare, un folder lipsă dintr-o locație permisă se creează automat.' : '';
                wp_send_json_error(array('message' => $result->get_error_message() . $hint));
            }
            wp_send_json_success(array('message' => 'Folder găsit: ' . $result['path'] . ' – ' . $result['folders'] . ' subfoldere, ' . $result['files'] . ($result['files'] === 1 ? ' document' : ' documente') . ' în rădăcină.'));
        }
        $id = SetareDrive_API::clean_id($value);
        if ($id === '') {
            wp_send_json_error(array('message' => 'Introduceți un ID sau un link de folder valid.'));
        }
        SetareDrive_API::flush_cache();
        $result = SetareDrive_API::test($id);
        if (is_wp_error($result)) {
            wp_send_json_error(array('message' => $result->get_error_message()));
        }
        wp_send_json_success(array('message' => 'Folder găsit: „' . $result['name'] . '” – ' . $result['folders'] . ' subfoldere.'));
    }

    private static function source_block($which, $label, $hint) {
        $drive    = SetareDrive_API::folder_option($which);
        $local    = SetareDrive_Local::option($which);
        $resolved = SetareDrive_Local::root($which);
        if (!is_wp_error($resolved)) {
            $active = 'folder pe server (' . $resolved . ')';
        } elseif ($drive !== '') {
            $active = 'Google Drive';
        } else {
            $active = 'nesetată';
        }
        echo '<h3>' . esc_html($label) . '</h3>';
        echo '<p class="description">' . esc_html($hint) . '</p>';
        echo '<table class="form-table" role="presentation">';
        echo '<tr><th scope="row"><label for="sdrv-local-' . esc_attr($which) . '">Folder pe server <span style="font-weight:400">(opțional)</span></label></th><td>';
        echo '<input id="sdrv-local-' . esc_attr($which) . '" name="local_' . esc_attr($which) . '" type="text" class="regular-text code" value="' . esc_attr($local) . '" placeholder="wp-content/uploads/documente/' . esc_attr($which === 'foto' ? 'fotografii' : ($which === 'mol' ? 'monitorul-oficial-local' : 'formulare')) . '" data-sdrv-folder data-kind="local">';
        echo ' <button type="button" class="button" data-sdrv-test>Testează</button> <span class="sdrv-test-result" role="status"></span>';
        if ($local !== '' && is_wp_error($resolved)) {
            echo '<p class="description" style="color:#b32d2e">' . esc_html($resolved->get_error_message()) . '</p>';
        }
        echo '</td></tr>';
        echo '<tr><th scope="row"><label for="sdrv-' . esc_attr($which) . '">Google Drive <span style="font-weight:400">(opțional)</span></label></th><td>';
        echo '<input id="sdrv-' . esc_attr($which) . '" name="folder_' . esc_attr($which) . '" type="text" class="regular-text code" value="' . esc_attr($drive) . '" placeholder="ID sau link de folder" data-sdrv-folder data-kind="drive">';
        echo ' <button type="button" class="button" data-sdrv-test>Testează</button> <span class="sdrv-test-result" role="status"></span>';
        echo '</td></tr>';
        echo '<tr><th scope="row">Sursa folosită acum</th><td><strong>' . esc_html($active) . '</strong></td></tr>';
        echo '</table>';
    }

    public static function render() {
        if (!current_user_can('manage_options')) {
            return;
        }
        $code = isset($_GET['sd']) ? sanitize_key(wp_unslash($_GET['sd'])) : '';
        $has_key = SetareDrive_API::key() !== '';
        ?>
        <div class="wrap">
            <h1>SetareDrive – foldere Google Drive</h1>

            <?php if ($code === 'saved') : ?>
                <div class="notice notice-success is-dismissible"><p>Setările au fost salvate.</p></div>
            <?php elseif ($code === 'invalid') : ?>
                <div class="notice notice-warning is-dismissible"><p>Setările au fost salvate, dar cel puțin un ID nu a fost recunoscut și a rămas gol. Copiați ID-ul sau linkul complet al folderului.</p></div>
            <?php elseif ($code === 'flushed') : ?>
                <div class="notice notice-success is-dismissible"><p>Memoria cache a fost golită.</p></div>
            <?php endif; ?>

            <?php
            $messages = get_transient('setaredrive_msgs_' . get_current_user_id());
            delete_transient('setaredrive_msgs_' . get_current_user_id());
            if (is_array($messages) && $messages) : ?>
                <div class="notice notice-info is-dismissible"><ul style="margin:.5em 0 .5em 1.2em;list-style:disc"><?php foreach ($messages as $message) : ?><li><?php echo esc_html($message); ?></li><?php endforeach; ?></ul></div>
            <?php endif; ?>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="setaredrive_save">
                <?php wp_nonce_field('setaredrive_save', 'setaredrive_nonce'); ?>

                <h2>Locația documentelor</h2>
                <p>Pentru fiecare secțiune puteți seta un folder aflat pe serverul site-ului, un folder Google Drive sau ambele; ambele câmpuri sunt opționale. Dacă sunt completate amândouă, se folosește folderul de pe server, iar Google Drive rămâne rezervă dacă folderul de pe server nu poate fi citit. Dacă niciunul nu e setat, secțiunea afișează un mesaj (Media nu afișează nimic).</p>
                <?php
                self::source_block('formulare', 'Formulare', 'Subfolderele devin butoane; la apăsare se afișează documentele folderului.');
                self::source_block('foto', 'Fotografii', 'Pagina Media afișează imaginile ca un carusel cu bară de miniaturi (din subfoldere, până la 2 niveluri).');
                self::source_block('mol', 'Monitorul Oficial Local', 'Folderele și subfolderele apar ca arbore; documentele se afișează în caseta din dreapta.');
                ?>

                <h2>Cheie API Google Drive</h2>
                <table class="form-table" role="presentation"><tr>
                    <th scope="row"><label for="sdrv-key">Cheie API</label></th>
                    <td>
                        <?php if (defined('SETAREDRIVE_API_KEY') && SETAREDRIVE_API_KEY) : ?>
                            <p class="description">Cheia este definită în wp-config.php (SETAREDRIVE_API_KEY).</p>
                        <?php else : ?>
                            <input id="sdrv-key" name="api_key" type="password" class="regular-text" autocomplete="new-password" value="" placeholder="<?php echo $has_key ? '•••••••• (salvată; lăsați gol pentru a o păstra)' : 'AIza…'; ?>">
                            <?php if ($has_key) : ?><label style="margin-left:12px"><input type="checkbox" name="clear_key" value="1"> Șterge cheia salvată</label><?php endif; ?>
                        <?php endif; ?>
                        <p class="description">Necesară doar pentru folderele Google Drive: lista de foldere și căutarea. Fără cheie, conținutul unui folder cunoscut se vede în continuare, dar nu apar butoanele de subfoldere, arborele și căutarea. Cheia se folosește numai pe server și nu este trimisă în browser.</p>
                    </td>
                </tr></table>

                <?php submit_button('Salvează setările'); ?>
            </form>

            <h2>Foldere pe serverul site-ului</h2>
            <ol>
                <li>Introduceți calea folderului, relativă la rădăcina instalării WordPress (de exemplu <code>wp-content/uploads/documente/formulare</code>) sau o cale absolută aflată în interiorul ei. La salvare, folderul lipsă se creează automat.</li>
                <li>Încărcați fișierele și subfolderele prin FTP/SFTP, prin managerul de fișiere al hostingului sau prin volumul montat al containerului. Subfolderele devin butoane (Formulare) sau noduri (Monitorul Oficial Local).</li>
                <li>Se afișează numai tipurile PDF, DOC/DOCX, XLS/XLSX, PPT/PPTX, ODT/ODS/ODP, RTF, TXT, CSV, XML, ZIP și imaginile JPG/PNG/GIF/WebP. Fișierele ascunse (cu punct la început) și celelalte tipuri sunt ignorate.</li>
                <li>Documentele se deschid prin linkuri semnate generate de site; nu se expun căile de pe server. Folderele de cod WordPress (wp-admin, wp-includes, plugins, themes) nu pot fi folosite. Pentru un folder din afara instalării WordPress, definiți în <code>wp-config.php</code>: <code>define('SETAREDRIVE_BASE_DIR', '/cale/catre/documente');</code></li>
                <li>Pentru Fotografii, imaginile sunt redimensionate automat (miniaturi și variantă mare) și păstrate în <code>uploads/setaredrive-cache</code>; originalele nu sunt modificate.</li>
            </ol>

            <h2>Cum obțineți ID-ul unui folder Google Drive</h2>
            <ol>
                <li><strong>Dacă folderul există deja în Google Drive:</strong> deschideți-l în browser. Adresa are forma <code>https://drive.google.com/drive/folders/<strong>ID_FOLDER</strong></code>. Copiați partea de după <code>/folders/</code> sau lipiți direct linkul complet în câmpul de mai sus.</li>
                <li><strong>Dacă folderul nu există:</strong> cereți persoanei care administrează Google Drive-ul instituției să creeze folderele „Formulare”, „Fotografii” și „Monitorul Oficial Local” și să vă trimită linkul fiecăruia. Subfolderele se creează direct în ele și devin automat butoane sau noduri în site.</li>
                <li><strong>Partajare obligatorie:</strong> pentru fiecare folder principal, clic dreapta → Partajează → Acces general → „Oricine are linkul”, rol <em>Vizualizator</em>. Subfolderele moștenesc setarea.</li>
                <li>Apăsați <em>Testează</em> lângă fiecare câmp pentru a verifica ID-ul înainte de salvare.</li>
            </ol>

            <h2>Cum obțineți cheia API</h2>
            <ol>
                <li>În <a href="https://console.cloud.google.com/" target="_blank" rel="noopener noreferrer">Google Cloud Console</a> creați un proiect (sau folosiți unul existent).</li>
                <li>APIs &amp; Services → Library → căutați <em>Google Drive API</em> → Enable.</li>
                <li>APIs &amp; Services → Credentials → Create credentials → <em>API key</em>.</li>
                <li>Restricționați cheia: la <em>API restrictions</em> alegeți doar <em>Google Drive API</em>. Cererile pleacă de pe serverul site-ului, deci nu folosiți restricția „HTTP referrers”; dacă serverul are IP fix, puteți restricționa cheia la acel IP.</li>
                <li>Lipiți cheia în câmpul de mai sus sau definiți-o în <code>wp-config.php</code>: <code>define('SETAREDRIVE_API_KEY', '…');</code></li>
            </ol>

            <h2>Memorie cache</h2>
            <p>Listele de foldere Google Drive se păstrează 15 minute pentru viteză (folderele de pe server se citesc direct, fără cache). Un folder sau o fotografie nouă apare după acest interval sau după golirea memoriei cache.</p>
            <p><a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=setaredrive_flush'), 'setaredrive_flush')); ?>">Golește memoria cache</a></p>
        </div>
        <?php
    }
}
