<?php
/**
 * Setări SetareDate: schemă, sanitizare, valori derivate.
 *
 * Există două copii: „ciorna” (se modifică la Salvează) și „aplicatul”
 * (se actualizează doar la Aplică modificările; tema citește doar această copie).
 */

if (!defined('ABSPATH')) {
    exit;
}

final class SetareDate_Settings {
    const OPT_DRAFT   = 'setaredate_settings';
    const OPT_APPLIED = 'setaredate_applied';
    const OPT_PAGES   = 'setaredate_pages';
    const OPT_AI      = 'setaredate_ai';

    /** Gazde de pe care Aplică poate importa imagini din textele predefinite (export al site-ului de test). */
    const IMPORT_HOSTS = array('pbv.dev.mediarr.site');

    public static function types() {
        return array(
            'comuna'     => array('label' => 'Comună',    'nom' => 'Comuna',     'gen' => 'Comunei',      'lc' => 'comună',     'lcgen' => 'comunei',      'despre' => 'Despre comună'),
            'orasul'     => array('label' => 'Oraș',      'nom' => 'Orașul',     'gen' => 'Orașului',     'lc' => 'oraș',       'lcgen' => 'orașului',     'despre' => 'Despre oraș'),
            'municipiul' => array('label' => 'Municipiu', 'nom' => 'Municipiul', 'gen' => 'Municipiului', 'lc' => 'municipiu', 'lcgen' => 'municipiului', 'despre' => 'Despre municipiu'),
        );
    }

    public static function defaults() {
        return array(
            'tip'            => 'comuna',
            'localitate'     => '',
            'judet'          => '',
            'sate'           => '',
            'slogan'         => '',
            'stema_id'       => 0,
            'monument_id'    => 0,
            'adresa'         => '',
            'telefon'        => '',
            'email'          => '',
            'facebook'       => '',
            'program'        => '',
            'audiente'       => '',
            'primar'         => '',
            'viceprimar'     => '',
            'secretar'       => '',
            'servicii'       => array(),
            'administratie'  => array(),
            'linkuri'        => '',
            'articole'       => array(),
            'txt_istoric'    => '',
            'txt_prezentare' => '',
            'intro_1'        => '',
            'intro_2'        => '',
            'stats'          => array(
                array('valoare' => '', 'eticheta' => ''),
                array('valoare' => '', 'eticheta' => ''),
                array('valoare' => '', 'eticheta' => ''),
                array('valoare' => '', 'eticheta' => ''),
            ),
            'ai_for'         => '',
        );
    }

    public static function get_draft() {
        $saved = get_option(self::OPT_DRAFT, array());
        return array_merge(self::defaults(), is_array($saved) ? $saved : array());
    }

    public static function get_applied() {
        $applied = get_option(self::OPT_APPLIED, array());
        return is_array($applied) ? $applied : array();
    }

    public static function ai_options() {
        $saved = get_option(self::OPT_AI, array());
        $saved = is_array($saved) ? $saved : array();
        return array_merge(array('key' => '', 'model' => 'claude-sonnet-5-5', 'search' => 1), $saved);
    }

    /** Semnătura localității: semnalează texte AI scrise pentru altă localitate. */
    public static function signature($s) {
        return md5(strtolower($s['tip'] . '|' . $s['localitate'] . '|' . $s['judet'] . '|' . $s['sate']));
    }

    private static function uid($value, array &$used) {
        $uid = preg_replace('/[^a-z0-9]/', '', strtolower((string) $value));
        if ($uid === '' || isset($used[$uid])) {
            do {
                $uid = strtolower(wp_generate_password(8, false, false));
            } while (isset($used[$uid]));
        }
        $used[$uid] = true;
        return $uid;
    }

    private static function limit($text, $length) {
        return function_exists('mb_substr') ? mb_substr($text, 0, $length) : substr($text, 0, $length);
    }

    /** Curăță datele primite din formular. */
    public static function sanitize($in) {
        $in    = is_array($in) ? $in : array();
        $d     = self::defaults();
        $types = self::types();
        $text  = function ($key, $max = 200) use ($in) {
            return isset($in[$key]) ? self::limit(sanitize_text_field((string) $in[$key]), $max) : '';
        };
        $area  = function ($key, $max = 2000) use ($in) {
            return isset($in[$key]) ? self::limit(sanitize_textarea_field((string) $in[$key]), $max) : '';
        };

        $d['tip']        = (isset($in['tip']) && isset($types[$in['tip']])) ? $in['tip'] : 'comuna';
        $d['localitate'] = $text('localitate', 120);
        $d['judet']      = $text('judet', 80);
        $d['sate']       = $text('sate', 300);
        $d['slogan']     = $text('slogan', 160);
        $d['stema_id']    = isset($in['stema_id']) ? absint($in['stema_id']) : 0;
        $d['monument_id'] = isset($in['monument_id']) ? absint($in['monument_id']) : 0;
        $d['adresa']     = $text('adresa', 250);
        $d['telefon']    = $text('telefon', 60);
        $d['email']      = isset($in['email']) ? sanitize_email((string) $in['email']) : '';
        $d['facebook']   = isset($in['facebook']) ? esc_url_raw((string) $in['facebook']) : '';
        $d['program']    = $area('program', 600);
        $d['audiente']   = $area('audiente', 600);
        $d['primar']     = $text('primar', 120);
        $d['viceprimar'] = $text('viceprimar', 120);
        $d['secretar']   = $text('secretar', 120);
        $d['linkuri']    = $area('linkuri', 1500);
        $d['txt_istoric']    = isset($in['txt_istoric']) ? wp_kses_post((string) $in['txt_istoric']) : '';
        $d['txt_prezentare'] = isset($in['txt_prezentare']) ? wp_kses_post((string) $in['txt_prezentare']) : '';
        $d['intro_1']    = $area('intro_1', 700);
        $d['intro_2']    = $area('intro_2', 700);
        $d['ai_for']     = $text('ai_for', 40);

        $used = array();
        foreach (array('servicii', 'administratie') as $group) {
            $rows   = array();
            $source = (isset($in[$group]) && is_array($in[$group])) ? array_values($in[$group]) : array();
            foreach ($source as $row) {
                if (!is_array($row)) {
                    continue;
                }
                $name = isset($row['nume']) ? self::limit(sanitize_text_field((string) $row['nume']), 100) : '';
                if ($name === '') {
                    continue;
                }
                $item = array(
                    'uid'  => self::uid(isset($row['uid']) ? $row['uid'] : '', $used),
                    'nume' => $name,
                );
                if ($group === 'servicii') {
                    $item['descriere'] = isset($row['descriere']) ? self::limit(sanitize_textarea_field((string) $row['descriere']), 300) : '';
                }
                $item['continut'] = isset($row['continut']) ? self::limit(wp_kses_post((string) $row['continut']), 80000) : '';
                $rows[] = $item;
                if (count($rows) >= 40) {
                    break;
                }
            }
            $d[$group] = $rows;
        }

        $articles = array();
        $source   = (isset($in['articole']) && is_array($in['articole'])) ? array_values($in['articole']) : array();
        foreach ($source as $row) {
            if (!is_array($row)) {
                continue;
            }
            $title = isset($row['titlu']) ? self::limit(sanitize_text_field((string) $row['titlu']), 160) : '';
            if ($title === '') {
                continue;
            }
            $date = isset($row['data']) ? sanitize_text_field((string) $row['data']) : '';
            $articles[] = array(
                'uid'      => self::uid(isset($row['uid']) ? $row['uid'] : '', $used),
                'titlu'    => $title,
                'data'     => preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) ? $date : '',
                'sticky'   => !empty($row['sticky']),
                'activ'    => !empty($row['activ']),
                'continut' => isset($row['continut']) ? self::limit(wp_kses_post((string) $row['continut']), 80000) : '',
            );
            if (count($articles) >= 10) {
                break;
            }
        }
        $d['articole'] = $articles;

        $stats  = array();
        $source = (isset($in['stats']) && is_array($in['stats'])) ? array_values($in['stats']) : array();
        for ($i = 0; $i < 4; $i++) {
            $row     = (isset($source[$i]) && is_array($source[$i])) ? $source[$i] : array();
            $stats[] = array(
                'valoare'  => isset($row['valoare']) ? self::limit(sanitize_text_field((string) $row['valoare']), 24) : '',
                'eticheta' => isset($row['eticheta']) ? self::limit(sanitize_text_field((string) $row['eticheta']), 48) : '',
            );
        }
        $d['stats'] = $stats;
        return $d;
    }

    /** Valori calculate din date: denumiri, liste. */
    public static function derived($s) {
        $types    = self::types();
        $t        = $types[isset($types[$s['tip']]) ? $s['tip'] : 'comuna'];
        $villages = array_values(array_filter(array_map('trim', explode(',', (string) $s['sate']))));
        return array(
            'nume_primarie' => trim('Primăria ' . $t['gen'] . ' ' . $s['localitate']),
            'nume_scurt'    => trim($t['nom'] . ' ' . $s['localitate']),
            'tip_nom'       => $t['nom'],
            'tip_gen'       => $t['gen'],
            'tip_lc'        => $t['lc'],
            'tip_lcgen'     => $t['lcgen'],
            'despre_label'  => $t['despre'],
            'sate_list'     => $villages,
        );
    }

    /** Transformă liniile „Text | URL” în listă de legături. */
    public static function parse_links($text) {
        $links = array();
        foreach (preg_split('/\R/u', (string) $text) as $line) {
            $line = trim($line);
            if ($line === '') {
                continue;
            }
            $parts = array_map('trim', explode('|', $line, 2));
            if (count($parts) !== 2 || $parts[0] === '') {
                continue;
            }
            $url = esc_url_raw($parts[1]);
            if ($url !== '') {
                $links[] = array('text' => $parts[0], 'url' => $url);
            }
        }
        return $links;
    }

    public static function hash($draft) {
        return md5(wp_json_encode($draft));
    }

    public static function is_dirty() {
        $applied = self::get_applied();
        if (empty($applied['configured'])) {
            return true;
        }
        return !isset($applied['draft_hash']) || $applied['draft_hash'] !== self::hash(self::get_draft());
    }

    /** Text predefinit din data/beba-veche/. */
    private static function preset_file($name) {
        $path = SETAREDATE_DIR . 'data/beba-veche/' . basename($name);
        return is_readable($path) ? trim((string) file_get_contents($path)) : '';
    }

    /** Date-exemplu pentru Beba Veche, preluate din tema anterioară. Conducerea nu se completează. */
    public static function preset_beba_veche() {
        $d = self::defaults();
        $d['tip']        = 'comuna';
        $d['localitate'] = 'Beba Veche';
        $d['judet']      = 'Timiș';
        $d['sate']       = 'Beba Veche, Cherestur, Pordeanu';
        $d['slogan']     = 'Cel mai vestic punct al României • Triplex Confinium';
        $d['adresa']     = 'Comuna Beba Veche, Nr. 292, Județul Timiș, Cod poștal 307035';
        $d['telefon']    = '0256 385 501';
        $d['email']      = 'secretariat@primariabebaveche.ro';
        $d['facebook']   = 'https://www.facebook.com/p/Primaria-Beba-Veche-61558195855065/';
        $d['program']    = "Luni – Joi: 08:00 – 16:00\nVineri: 08:00 – 12:00\nCasierie / Relații cu publicul: Luni – Joi 08:30 – 15:30, Vineri 08:00 – 12:00";
        $d['servicii'] = array(
            array('uid' => 'urbanism', 'nume' => 'Urbanism & Amenajare', 'descriere' => 'Certificate de urbanism, autorizații de construire, avize de oportunitate, prelungiri și recepții lucrări.', 'continut' => self::preset_file('srv-urbanism.html')),
            array('uid' => 'taxe', 'nume' => 'Taxe și Impozite', 'descriere' => 'Stabilirea și încasarea impozitelor pe clădiri, terenuri și autovehicule.', 'continut' => self::preset_file('srv-taxe.html')),
            array('uid' => 'agricol', 'nume' => 'Registrul Agricol', 'descriere' => 'Evidența gospodăriilor agricole, adeverințe APIA, atestate de producător și tranzacții cu terenuri.', 'continut' => self::preset_file('srv-agricol.html')),
            array('uid' => 'civila', 'nume' => 'Stare Civilă', 'descriere' => 'Înregistrarea nașterilor, căsătoriilor și deceselor, transcrieri de acte și divorțuri administrative.', 'continut' => self::preset_file('srv-civila.html')),
            array('uid' => 'social', 'nume' => 'Asistență Socială', 'descriere' => 'Ajutoare de încălzire, alocații, indemnizații și sprijin pentru familiile vulnerabile.', 'continut' => self::preset_file('srv-social.html')),
            array('uid' => 'registratura', 'nume' => 'Registratură & Relații cu publicul', 'descriere' => 'Preluarea cererilor, petițiilor și solicitărilor pe Legea nr. 544/2001.', 'continut' => self::preset_file('srv-registratura.html')),
        );
        $d['administratie'] = array(
            array('uid' => 'conducere', 'nume' => 'Organigrama Primăriei', 'continut' => self::preset_file('adm-organigrama.html')),
            array('uid' => 'consiliu', 'nume' => 'Consiliul Local', 'continut' => self::preset_file('adm-consiliu.html')),
            array('uid' => 'transparenta', 'nume' => 'Transparență Decizională', 'continut' => ''),
        );
        $d['txt_istoric']    = self::preset_file('istoric.html');
        $d['txt_prezentare'] = self::preset_file('prezentare.html');
        $d['articole'] = array(
            array('uid' => 'portideschise', 'titlu' => 'Porți deschise la frontieră', 'data' => '2026-11-09', 'sticky' => true, 'activ' => true, 'continut' => self::preset_file('article-porti-deschise.html')),
        );
        $d['stats'] = array(
            array('valoare' => '20°15\'44" E', 'eticheta' => 'Longitudine (punct vestic)'),
            array('valoare' => '3', 'eticheta' => 'Sate componente'),
            array('valoare' => '1920', 'eticheta' => 'Triplex Confinium'),
            array('valoare' => '307035', 'eticheta' => 'Cod poștal oficial'),
        );
        return $d;
    }
}
