<?php
/**
 * Ecranul de administrare SetareDate.
 */

if (!defined('ABSPATH')) {
    exit;
}

final class SetareDate_Admin {
    const SLUG = 'setaredate';

    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'menu'));
        add_action('admin_init', array(__CLASS__, 'maybe_redirect'));
        add_action('admin_post_setaredate_save', array(__CLASS__, 'handle_save'));
        add_action('admin_post_setaredate_preset', array(__CLASS__, 'handle_preset'));
        add_action('admin_enqueue_scripts', array(__CLASS__, 'assets'));
    }

    public static function on_activate() {
        if (!SetareDate_Settings::get_applied()) {
            set_transient('setaredate_redirect', 1, 120);
        }
    }

    /** La prima lansare (activarea temei sau a pluginului) deschide direct ecranul de configurare. */
    public static function maybe_redirect() {
        if (!get_transient('setaredate_redirect') || wp_doing_ajax() || isset($_GET['activate-multi'])) {
            return;
        }
        if (!current_user_can('manage_options')) {
            return;
        }
        delete_transient('setaredate_redirect');
        if (!SetareDate_Settings::get_applied()) {
            wp_safe_redirect(admin_url('admin.php?page=' . self::SLUG));
            exit;
        }
    }

    public static function menu() {
        add_menu_page('SetareDate', 'SetareDate', 'manage_options', self::SLUG, array(__CLASS__, 'render'), 'dashicons-location-alt', 3);
    }

    public static function assets($hook) {
        if ($hook !== 'toplevel_page_' . self::SLUG) {
            return;
        }
        wp_enqueue_media();
        wp_enqueue_style('setaredate-admin', SETAREDATE_URL . 'assets/admin.css', array(), SETAREDATE_VERSION);
        wp_enqueue_script('setaredate-admin', SETAREDATE_URL . 'assets/admin.js', array('jquery'), SETAREDATE_VERSION, true);
        wp_localize_script('setaredate-admin', 'SetareDateAdmin', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('setaredate_ai'),
            'strings' => array(
                'pickImage'   => 'Alegeți imaginea',
                'useImage'    => 'Folosește imaginea',
                'needPlace'   => 'Completați numele localității și județul înainte de generare.',
                'running'     => 'Se generează…',
                'done'        => 'gata',
                'failed'      => 'nu a reușit',
                'istoric'     => 'Pagina Istoric',
                'prezentare'  => 'Pagina Prezentare generală',
                'intro'       => 'Caseta de prezentare și cifrele din prima pagină',
                'confirmPreset' => 'Datele din formular vor fi înlocuite cu cele ale comunei Beba Veche. Continuați?',
                'confirmGenerate' => 'Textele existente din această secțiune vor fi înlocuite. Continuați?',
            ),
        ));
    }

    /* ---------------------------------------------------------------- handlers */

    private static function back($code) {
        wp_safe_redirect(add_query_arg(array('page' => self::SLUG, 'sd' => $code), admin_url('admin.php')));
        exit;
    }

    public static function handle_save() {
        if (!current_user_can('manage_options')) {
            wp_die('Nu aveți permisiunea de a modifica aceste setări.', 403);
        }
        check_admin_referer('setaredate_save', 'setaredate_nonce');

        $raw   = isset($_POST['setaredate']) ? wp_unslash($_POST['setaredate']) : array();
        $draft = SetareDate_Settings::sanitize($raw);
        update_option(SetareDate_Settings::OPT_DRAFT, $draft, false);

        $ai_in = isset($_POST['setaredate_ai']) && is_array($_POST['setaredate_ai']) ? wp_unslash($_POST['setaredate_ai']) : array();
        $ai    = SetareDate_Settings::ai_options();
        if (!empty($ai_in['key'])) {
            $ai['key'] = sanitize_text_field((string) $ai_in['key']);
        }
        if (!empty($ai_in['clear_key'])) {
            $ai['key'] = '';
        }
        $model       = isset($ai_in['model']) ? sanitize_text_field((string) $ai_in['model']) : '';
        $ai['model'] = $model !== '' ? $model : 'claude-sonnet-5-5';
        $ai['search'] = !empty($ai_in['search']) ? 1 : 0;
        update_option(SetareDate_Settings::OPT_AI, $ai, false);

        $action = isset($_POST['setaredate_action']) ? sanitize_key(wp_unslash($_POST['setaredate_action'])) : 'save';
        if ($action !== 'apply') {
            self::back('saved');
        }

        $report = SetareDate_Apply::run(!empty($_POST['setaredate_overwrite']));
        if (is_wp_error($report)) {
            set_transient('setaredate_report_' . get_current_user_id(), array($report->get_error_message()), 300);
            self::back('error');
        }
        set_transient('setaredate_report_' . get_current_user_id(), $report, 300);
        self::back('applied');
    }

    public static function handle_preset() {
        if (!current_user_can('manage_options')) {
            wp_die('Nu aveți permisiunea de a modifica aceste setări.', 403);
        }
        check_admin_referer('setaredate_preset');
        $current = SetareDate_Settings::get_draft();
        $preset  = SetareDate_Settings::preset_beba_veche();
        $preset['stema_id']    = $current['stema_id'] ? $current['stema_id'] : self::find_or_import_stema();
        $preset['monument_id'] = $current['monument_id'];
        update_option(SetareDate_Settings::OPT_DRAFT, $preset, false);
        self::back('preset');
    }

    private static function find_or_import_stema() {
        $found = get_posts(array(
            'post_type' => 'attachment', 'post_status' => 'inherit', 'posts_per_page' => 1, 'fields' => 'ids',
            'meta_key' => '_wp_attached_file', 'meta_value' => 'stema-color.jpg',
        ));
        if ($found) {
            return (int) $found[0];
        }
        $source = get_template_directory() . '/assets/images/stema-color.jpg';
        if (!is_readable($source)) {
            return 0;
        }
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        $tmp = wp_tempnam('stema-color.jpg');
        if (!$tmp || !copy($source, $tmp)) {
            return 0;
        }
        $id = media_handle_sideload(array('name' => 'stema-color.jpg', 'tmp_name' => $tmp), 0, 'Stemă');
        return is_wp_error($id) ? 0 : (int) $id;
    }

    /* ------------------------------------------------------------------ render */

    private static function field($name, $label, $value, $args = array()) {
        $args = array_merge(array('type' => 'text', 'hint' => '', 'placeholder' => '', 'required' => false, 'class' => 'regular-text'), $args);
        $id   = 'sd-' . sanitize_key(str_replace(array('[', ']'), '-', $name));
        echo '<div class="sd-field"><label for="' . esc_attr($id) . '">' . esc_html($label) . ($args['required'] ? ' <span class="sd-req" aria-hidden="true">*</span>' : '') . '</label>';
        printf(
            '<input id="%s" type="%s" name="setaredate[%s]" value="%s" class="%s" placeholder="%s"%s>',
            esc_attr($id), esc_attr($args['type']), esc_attr($name), esc_attr($value), esc_attr($args['class']), esc_attr($args['placeholder']), $args['required'] ? ' required' : ''
        );
        if ($args['hint'] !== '') {
            echo '<p class="description">' . esc_html($args['hint']) . '</p>';
        }
        echo '</div>';
    }

    private static function area($name, $label, $value, $args = array()) {
        $args = array_merge(array('hint' => '', 'rows' => 3, 'placeholder' => ''), $args);
        $id   = 'sd-' . sanitize_key(str_replace(array('[', ']'), '-', $name));
        echo '<div class="sd-field"><label for="' . esc_attr($id) . '">' . esc_html($label) . '</label>';
        printf(
            '<textarea id="%s" name="setaredate[%s]" rows="%d" class="large-text" placeholder="%s">%s</textarea>',
            esc_attr($id), esc_attr($name), (int) $args['rows'], esc_attr($args['placeholder']), esc_textarea($value)
        );
        if ($args['hint'] !== '') {
            echo '<p class="description">' . esc_html($args['hint']) . '</p>';
        }
        echo '</div>';
    }

    private static function media($name, $label, $attachment_id, $hint) {
        $attachment_id = (int) $attachment_id;
        echo '<div class="sd-field sd-media" data-title="' . esc_attr($label) . '"><span class="sd-label">' . esc_html($label) . '</span>';
        echo '<input type="hidden" name="setaredate[' . esc_attr($name) . ']" value="' . esc_attr($attachment_id) . '">';
        echo '<div class="sd-media-preview">';
        if ($attachment_id && wp_attachment_is_image($attachment_id)) {
            echo wp_get_attachment_image($attachment_id, 'medium');
        }
        echo '</div>';
        echo '<button type="button" class="button sd-media-pick">Alege imaginea</button> ';
        echo '<button type="button" class="button-link sd-media-clear"' . ($attachment_id ? '' : ' hidden') . '>Elimină</button>';
        echo '<p class="description">' . esc_html($hint) . '</p></div>';
    }

    private static function row_service($index, $item) {
        $item = array_merge(array('uid' => '', 'nume' => '', 'descriere' => '', 'continut' => ''), $item);
        $base = 'setaredate[servicii][' . $index . ']';
        echo '<div class="sd-row" data-row>';
        echo '<input type="hidden" name="' . esc_attr($base) . '[uid]" value="' . esc_attr($item['uid']) . '">';
        echo '<input type="text" name="' . esc_attr($base) . '[nume]" value="' . esc_attr($item['nume']) . '" class="regular-text" placeholder="Denumirea compartimentului" aria-label="Denumirea compartimentului">';
        echo '<input type="text" name="' . esc_attr($base) . '[descriere]" value="' . esc_attr($item['descriere']) . '" class="large-text" placeholder="Descriere scurtă pentru caseta din prima pagină (opțional)" aria-label="Descriere scurtă">';
        echo '<button type="button" class="button-link sd-remove" aria-label="Elimină compartimentul">Elimină</button>';
        self::content_box($base, $item['continut']);
        echo '</div>';
    }

    /** Text inițial al paginii (HTML), pliat; folosit doar la crearea paginii sau când pagina nu a fost editată. */
    private static function content_box($base, $value) {
        echo '<details class="sd-more"><summary>Text pagină' . ($value !== '' ? ' (completat)' : ' (opțional)') . '</summary>';
        echo '<textarea name="' . esc_attr($base) . '[continut]" rows="8" class="large-text code" aria-label="Textul paginii (HTML)">' . esc_textarea($value) . '</textarea>';
        echo '<p class="description">Se scrie în pagină la prima aplicare. După ce editați pagina în WordPress, textul de aici nu o mai suprascrie.</p></details>';
    }

    private static function row_admin($index, $item) {
        $item = array_merge(array('uid' => '', 'nume' => '', 'continut' => ''), $item);
        $base = 'setaredate[administratie][' . $index . ']';
        echo '<div class="sd-row" data-row>';
        echo '<input type="hidden" name="' . esc_attr($base) . '[uid]" value="' . esc_attr($item['uid']) . '">';
        echo '<input type="text" name="' . esc_attr($base) . '[nume]" value="' . esc_attr($item['nume']) . '" class="regular-text" placeholder="Denumirea paginii" aria-label="Denumirea paginii">';
        echo '<button type="button" class="button-link sd-remove" aria-label="Elimină pagina">Elimină</button>';
        self::content_box($base, $item['continut']);
        echo '</div>';
    }

    private static function row_article($index, $item) {
        $item = array_merge(array('uid' => '', 'titlu' => '', 'data' => '', 'sticky' => true, 'activ' => true, 'continut' => ''), $item);
        $base = 'setaredate[articole][' . $index . ']';
        echo '<div class="sd-row sd-row-article" data-row>';
        echo '<input type="hidden" name="' . esc_attr($base) . '[uid]" value="' . esc_attr($item['uid']) . '">';
        echo '<input type="text" name="' . esc_attr($base) . '[titlu]" value="' . esc_attr($item['titlu']) . '" class="regular-text" placeholder="Titlul articolului" aria-label="Titlul articolului">';
        echo '<input type="date" name="' . esc_attr($base) . '[data]" value="' . esc_attr($item['data']) . '" aria-label="Data articolului">';
        echo '<label class="sd-inline"><input type="checkbox" name="' . esc_attr($base) . '[activ]" value="1" ' . checked(!empty($item['activ']), true, false) . '> Publică</label>';
        echo '<label class="sd-inline"><input type="checkbox" name="' . esc_attr($base) . '[sticky]" value="1" ' . checked(!empty($item['sticky']), true, false) . '> Sticky</label>';
        echo '<button type="button" class="button-link sd-remove" aria-label="Elimină articolul">Elimină</button>';
        self::content_box($base, $item['continut']);
        echo '</div>';
    }

    private static function repeater($group, $items, $callback, $add_label) {
        echo '<div class="sd-repeater" data-group="' . esc_attr($group) . '" data-next="' . esc_attr(max(1, count($items))) . '">';
        echo '<div class="sd-rows">';
        if (!$items) {
            $items = array(array());
        }
        foreach (array_values($items) as $i => $item) {
            call_user_func($callback, $i, $item);
        }
        echo '</div>';
        echo '<template class="sd-template">';
        call_user_func($callback, '__INDEX__', array());
        echo '</template>';
        echo '<button type="button" class="button sd-add">' . esc_html($add_label) . '</button></div>';
    }

    public static function render() {
        if (!current_user_can('manage_options')) {
            return;
        }
        $s       = SetareDate_Settings::get_draft();
        $applied = SetareDate_Settings::get_applied();
        $ai      = SetareDate_Settings::ai_options();
        $types   = SetareDate_Settings::types();
        $despre  = $types[isset($types[$s['tip']]) ? $s['tip'] : 'comuna']['lc'];
        $dirty   = SetareDate_Settings::is_dirty();
        $code    = isset($_GET['sd']) ? sanitize_key(wp_unslash($_GET['sd'])) : '';
        $report  = array();
        if ($code === 'applied' || $code === 'error') {
            $key    = 'setaredate_report_' . get_current_user_id();
            $report = get_transient($key);
            delete_transient($key);
            $report = is_array($report) ? $report : array();
        }
        $stale_ai = $s['ai_for'] !== '' && $s['ai_for'] !== SetareDate_Settings::signature($s);
        ?>
        <div class="wrap setaredate">
            <h1>SetareDate</h1>
            <p class="sd-lead">Completați datele localității. <strong>Salvează</strong> păstrează modificările ca ciornă; <strong>Aplică modificările</strong> actualizează efectiv site-ul (pagini, meniu, prima pagină, subsol).</p>

            <?php if ($code === 'saved') : ?>
                <div class="notice notice-success is-dismissible"><p>Datele au fost salvate. Site-ul nu s-a schimbat încă: apăsați „Aplică modificările”.</p></div>
            <?php elseif ($code === 'preset') : ?>
                <div class="notice notice-success is-dismissible"><p>Formularul a fost completat cu datele Beba Veche. Alegeți imaginea monumentului, apoi salvați sau aplicați.</p></div>
            <?php elseif ($code === 'applied') : ?>
                <div class="notice notice-success is-dismissible"><p><strong>Modificările au fost aplicate.</strong> <a href="<?php echo esc_url(home_url('/')); ?>" target="_blank" rel="noopener">Vezi site-ul</a></p>
                <?php if ($report) : ?><ul class="sd-report"><?php foreach ($report as $line) : ?><li><?php echo esc_html($line); ?></li><?php endforeach; ?></ul><?php endif; ?></div>
            <?php elseif ($code === 'error') : ?>
                <div class="notice notice-error is-dismissible"><p><?php echo esc_html($report ? implode(' ', $report) : 'Modificările nu au putut fi aplicate.'); ?></p></div>
            <?php endif; ?>

            <?php if (empty($applied['configured'])) : ?>
                <div class="notice notice-info inline"><p>Site-ul nu este configurat încă: vizitatorii văd o pagină goală până la prima aplicare.</p></div>
            <?php elseif ($dirty) : ?>
                <div class="notice notice-warning inline"><p>Există modificări salvate sau netrimise care nu sunt aplicate pe site.</p></div>
            <?php else : ?>
                <div class="notice notice-success inline"><p>Site-ul folosește ultimele date salvate (aplicat la <?php echo esc_html(wp_date('d.m.Y H:i', (int) $applied['applied_at'])); ?>).</p></div>
            <?php endif; ?>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" id="setaredate-form">
                <input type="hidden" name="action" value="setaredate_save">
                <?php wp_nonce_field('setaredate_save', 'setaredate_nonce'); ?>
                <input type="hidden" name="setaredate[ai_for]" id="sd-ai-for" value="<?php echo esc_attr($s['ai_for']); ?>">

                <section class="sd-card">
                    <h2>Localitatea</h2>
                    <div class="sd-field">
                        <label for="sd-tip">Tipul unității administrativ-teritoriale</label>
                        <select id="sd-tip" name="setaredate[tip]">
                            <?php foreach ($types as $key => $t) : ?>
                                <option value="<?php echo esc_attr($key); ?>" <?php selected($s['tip'], $key); ?>><?php echo esc_html($t['label']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <?php
                    self::field('localitate', 'Numele localității', $s['localitate'], array('required' => true, 'placeholder' => 'Ex.: Beba Veche'));
                    self::field('judet', 'Județul', $s['judet'], array('required' => true, 'placeholder' => 'Ex.: Timiș'));
                    self::field('sate', 'Sate / localități componente', $s['sate'], array('hint' => 'Opțional, separate prin virgulă. Se folosesc în textul din prima pagină și în textele generate cu AI.', 'class' => 'large-text'));
                    self::field('slogan', 'Slogan', $s['slogan'], array('hint' => 'Apare în antet, în prima pagină și ca descriere a site-ului.', 'class' => 'large-text'));
                    ?>
                </section>

                <section class="sd-card">
                    <h2>Imagini</h2>
                    <div class="sd-grid">
                        <?php
                        self::media('stema_id', 'Stema', $s['stema_id'], 'Se afișează în antet și devine pictograma site-ului (favicon).');
                        self::media('monument_id', 'Imagine specifică localității', $s['monument_id'], 'Opțional. De exemplu monumentul sau un reper al localității; apare în prima pagină, monocrom și estompat, pe fundalul albastru (se potrivește o imagine luminoasă sau cu fundal transparent). Dacă nu alegeți nicio imagine, prima pagină folosește imaginea implicită a temei, cu monumentul Triplex Confinium.');
                        ?>
                    </div>
                </section>

                <section class="sd-card">
                    <h2>Contact și program</h2>
                    <div class="sd-grid">
                        <?php
                        self::field('adresa', 'Adresa sediului', $s['adresa'], array('class' => 'large-text'));
                        self::field('telefon', 'Telefon', $s['telefon']);
                        self::field('email', 'E-mail', $s['email'], array('type' => 'email'));
                        self::field('facebook', 'Pagina de Facebook (opțional)', $s['facebook'], array('type' => 'url', 'placeholder' => 'https://www.facebook.com/…'));
                        self::area('program', 'Program cu publicul', $s['program'], array('hint' => 'Un interval pe rând.'));
                        self::area('audiente', 'Audiențe', $s['audiente'], array('hint' => 'De exemplu: Primar – marți, 10:00–12:00.'));
                        ?>
                    </div>
                </section>

                <section class="sd-card">
                    <h2>Conducere</h2>
                    <div class="sd-grid">
                        <?php
                        self::field('primar', 'Primar', $s['primar']);
                        self::field('viceprimar', 'Viceprimar', $s['viceprimar']);
                        self::field('secretar', 'Secretar general', $s['secretar']);
                        ?>
                    </div>
                </section>

                <section class="sd-card">
                    <h2>Servicii cetățeni</h2>
                    <p class="description">Fiecare compartiment primește o pagină proprie, apare în meniul principal la „Servicii cetățeni”, are o casetă în prima pagină și un link în subsol.</p>
                    <?php self::repeater('servicii', $s['servicii'], array(__CLASS__, 'row_service'), 'Adaugă compartiment'); ?>
                </section>

                <section class="sd-card">
                    <h2>Administrație</h2>
                    <p class="description">Fiecare denumire devine o pagină și apare în meniul principal la „Administrație”.</p>
                    <?php self::repeater('administratie', $s['administratie'], array(__CLASS__, 'row_admin'), 'Adaugă pagină'); ?>
                </section>

                <section class="sd-card">
                    <h2>Articole inițiale</h2>
                    <p class="description">Se publică o singură dată, la „Aplică modificările”. Articolele sticky apar pe prima pagină. După publicare, articolul se editează din Articole, iar modificările de aici nu îl mai schimbă.</p>
                    <?php self::repeater('articole', $s['articole'], array(__CLASS__, 'row_article'), 'Adaugă articol'); ?>
                </section>

                <section class="sd-card" id="sd-despre">
                    <h2>Despre <?php echo esc_html($despre); ?>: texte și cifre</h2>
                    <p class="description">Meniul „Despre <?php echo esc_html($despre); ?>” conține paginile Istoric și Prezentare generală. Textele pot fi generate cu AI pentru localitatea indicată, apoi editate. Verificați faptele înainte de a aplica.</p>

                    <?php if ($stale_ai) : ?>
                        <div class="notice notice-warning inline"><p>Textele de mai jos au fost generate pentru altă localitate sau pentru alte date. Generați-le din nou sau corectați-le.</p></div>
                    <?php endif; ?>

                    <div class="sd-ai">
                        <button type="button" class="button button-secondary" id="sd-ai-run">Generează texte cu AI</button>
                        <ul id="sd-ai-status" aria-live="polite"></ul>
                    </div>

                    <details class="sd-ai-settings"<?php echo (SetareDate_AI::api_key() === '') ? ' open' : ''; ?>>
                        <summary>Setări generare AI (API Anthropic)</summary>
                        <div class="sd-field">
                            <label for="sd-ai-key">Cheie API Anthropic</label>
                            <?php if (defined('SETAREDATE_ANTHROPIC_KEY') && SETAREDATE_ANTHROPIC_KEY) : ?>
                                <p class="description">Cheia este definită în wp-config.php (SETAREDATE_ANTHROPIC_KEY).</p>
                            <?php else : ?>
                                <input id="sd-ai-key" type="password" name="setaredate_ai[key]" value="" class="regular-text" autocomplete="new-password" placeholder="<?php echo $ai['key'] !== '' ? '•••••••• (salvată; lăsați gol pentru a o păstra)' : 'sk-ant-…'; ?>">
                                <?php if ($ai['key'] !== '') : ?><label class="sd-inline"><input type="checkbox" name="setaredate_ai[clear_key]" value="1"> Șterge cheia salvată</label><?php endif; ?>
                                <p class="description">Se creează în Anthropic Console. Preferabil o cheie dedicată acestui site; pentru siguranță o puteți defini în wp-config.php în loc de baza de date.</p>
                            <?php endif; ?>
                        </div>
                        <div class="sd-field">
                            <label for="sd-ai-model">Model</label>
                            <input id="sd-ai-model" type="text" name="setaredate_ai[model]" value="<?php echo esc_attr($ai['model']); ?>" class="regular-text">
                        </div>
                        <div class="sd-field">
                            <label class="sd-inline"><input type="checkbox" name="setaredate_ai[search]" value="1" <?php checked(!empty($ai['search'])); ?>> Folosește căutarea web pentru a verifica faptele (recomandat; trebuie activată în Anthropic Console)</label>
                        </div>
                    </details>

                    <div class="sd-field">
                        <span class="sd-label">Pagina „Istoric”</span>
                        <?php wp_editor($s['txt_istoric'], 'sd_txt_istoric', array('textarea_name' => 'setaredate[txt_istoric]', 'textarea_rows' => 12, 'media_buttons' => false, 'teeny' => true)); ?>
                    </div>
                    <div class="sd-field">
                        <span class="sd-label">Pagina „Prezentare generală”</span>
                        <?php wp_editor($s['txt_prezentare'], 'sd_txt_prezentare', array('textarea_name' => 'setaredate[txt_prezentare]', 'textarea_rows' => 12, 'media_buttons' => false, 'teeny' => true)); ?>
                    </div>

                    <h3>Caseta de prezentare din prima pagină</h3>
                    <?php
                    self::area('intro_1', 'Primul paragraf', $s['intro_1'], array('rows' => 3));
                    self::area('intro_2', 'Al doilea paragraf', $s['intro_2'], array('rows' => 3));
                    ?>
                    <div class="sd-stats">
                        <?php for ($i = 0; $i < 4; $i++) : ?>
                            <div class="sd-stat">
                                <input type="text" name="setaredate[stats][<?php echo (int) $i; ?>][valoare]" value="<?php echo esc_attr($s['stats'][$i]['valoare']); ?>" placeholder="Cifră" aria-label="Cifra <?php echo (int) ($i + 1); ?>" class="sd-stat-val">
                                <input type="text" name="setaredate[stats][<?php echo (int) $i; ?>][eticheta]" value="<?php echo esc_attr($s['stats'][$i]['eticheta']); ?>" placeholder="Ce reprezintă" aria-label="Eticheta cifrei <?php echo (int) ($i + 1); ?>">
                            </div>
                        <?php endfor; ?>
                    </div>
                    <p class="description">Lăsați gol câmpul „Cifră” pentru a ascunde o casetă. Verificați cifrele în surse oficiale.</p>
                </section>

                <section class="sd-card">
                    <h2>Legături utile din subsol</h2>
                    <?php self::area('linkuri', 'Legături', $s['linkuri'], array('rows' => 5, 'placeholder' => "Ghișeul.ro – plăți online | https://www.ghiseul.ro\nANAF | https://www.anaf.ro", 'hint' => 'Una pe rând, în forma: Denumire | Adresă. Dacă rămâne gol, subsolul arată legături naționale implicite.')); ?>
                </section>

                <div class="sd-actions">
                    <button type="submit" name="setaredate_action" value="save" class="button button-large">Salvează</button>
                    <button type="submit" name="setaredate_action" value="apply" class="button button-primary button-large">Aplică modificările</button>
                    <label class="sd-inline"><input type="checkbox" name="setaredate_overwrite" value="1"> Înlocuiește și paginile editate manual</label>
                </div>
            </form>

            <p class="sd-preset">
                <a class="button-link" id="sd-preset" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=setaredate_preset'), 'setaredate_preset')); ?>">Completează cu datele comunei Beba Veche (exemplu)</a>
            </p>
        </div>
        <?php
    }
}
