<?php
/**
 * Shortcode-uri folosite de paginile create de SetareDate.
 */

if (!defined('ABSPATH')) {
    exit;
}

final class SetareDate_Shortcodes {
    public static function init() {
        add_shortcode('setaredate_contact', array(__CLASS__, 'contact'));
        add_shortcode('setaredate_conducere', array(__CLASS__, 'conducere'));
        add_shortcode('setaredate_subpagini', array(__CLASS__, 'subpagini'));
        add_action('init', array(__CLASS__, 'drive_fallbacks'), 99);
    }

    /** Datele afișate vin din configurația aplicată, nu din ciornă. */
    private static function applied() {
        return SetareDate_Settings::get_applied();
    }

    private static function lines($text) {
        return nl2br(esc_html((string) $text));
    }

    public static function contact() {
        $a = self::applied();
        $rows = array();
        if (!empty($a['adresa'])) {
            $rows['Adresă'] = esc_html($a['adresa']);
        }
        if (!empty($a['telefon'])) {
            $tel = preg_replace('/[^0-9+]/', '', $a['telefon']);
            $rows['Telefon'] = '<a href="tel:' . esc_attr($tel) . '">' . esc_html($a['telefon']) . '</a>';
        }
        if (!empty($a['email'])) {
            $rows['E-mail'] = '<a href="mailto:' . esc_attr($a['email']) . '">' . esc_html($a['email']) . '</a>';
        }
        if (!empty($a['program'])) {
            $rows['Program cu publicul'] = self::lines($a['program']);
        }
        if (!empty($a['audiente'])) {
            $rows['Audiențe'] = self::lines($a['audiente']);
        }
        if (!$rows) {
            return '';
        }
        $html = '<dl class="pbv-info-list">';
        foreach ($rows as $label => $value) {
            $html .= '<div class="pbv-info-row"><dt>' . esc_html($label) . '</dt><dd>' . $value . '</dd></div>';
        }
        return $html . '</dl>';
    }

    public static function conducere() {
        $a = self::applied();
        $rows = array();
        foreach (array('primar' => 'Primar', 'viceprimar' => 'Viceprimar', 'secretar' => 'Secretar general') as $key => $label) {
            if (!empty($a[$key])) {
                $rows[$label] = esc_html($a[$key]);
            }
        }
        if (!empty($a['audiente'])) {
            $rows['Audiențe'] = self::lines($a['audiente']);
        }
        if (!$rows) {
            return '';
        }
        $html = '<dl class="pbv-info-list">';
        foreach ($rows as $label => $value) {
            $html .= '<div class="pbv-info-row"><dt>' . esc_html($label) . '</dt><dd>' . $value . '</dd></div>';
        }
        return $html . '</dl>';
    }

    public static function subpagini() {
        $parent = get_the_ID();
        if (!$parent) {
            return '';
        }
        $children = get_pages(array(
            'child_of'    => $parent,
            'parent'      => $parent,
            'sort_column' => 'menu_order,post_title',
            'post_status' => 'publish',
        ));
        if (!$children) {
            return '';
        }
        $html = '<ul class="pbv-subpages">';
        foreach ($children as $page) {
            $html .= '<li><a href="' . esc_url(get_permalink($page)) . '">' . esc_html($page->post_title) . '</a></li>';
        }
        return $html . '</ul>';
    }

    /** Dacă SetareDrive nu e activ, paginile Media/Formulare/Monitorul Oficial nu afișează cod brut. */
    public static function drive_fallbacks() {
        foreach (array('setaredrive_formulare', 'setaredrive_media', 'setaredrive_mol') as $tag) {
            if (!shortcode_exists($tag)) {
                add_shortcode($tag, function () {
                    return current_user_can('manage_options')
                        ? '<p class="pbv-announcements-empty">Activați pluginul SetareDrive pentru a afișa acest conținut.</p>'
                        : '';
                });
            }
        }
    }
}
