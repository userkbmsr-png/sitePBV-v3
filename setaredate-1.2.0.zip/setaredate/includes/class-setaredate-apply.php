<?php
/**
 * „Aplică modificările”: actualizează efectiv site-ul (identitate, pagini, meniu, configurația citită de temă).
 */

if (!defined('ABSPATH')) {
    exit;
}

final class SetareDate_Apply {
    const MENU_NAME = 'Meniu principal – SetareDate';

    private $s;
    private $d;
    private $pages = array();
    private $report = array();
    private $overwrite = false;

    private function __construct($settings, $overwrite) {
        $this->s         = $settings;
        $this->d         = SetareDate_Settings::derived($settings);
        $this->overwrite = (bool) $overwrite;
        $map             = get_option(SetareDate_Settings::OPT_PAGES, array());
        $this->pages     = is_array($map) ? $map : array();
    }

    /** @return array|WP_Error Raportul acțiunilor efectuate. */
    public static function run($overwrite_manual = false) {
        $settings = SetareDate_Settings::get_draft();
        if ($settings['localitate'] === '' || $settings['judet'] === '') {
            return new WP_Error('setaredate_missing', 'Completați cel puțin numele localității și județul înainte de a aplica modificările.');
        }
        $job = new self($settings, $overwrite_manual);
        return $job->execute();
    }

    private function say($line) {
        $this->report[] = $line;
    }

    private function execute() {
        @set_time_limit(120);
        $this->apply_identity();
        $this->apply_pages();
        $this->apply_articles();
        $this->apply_menu();
        $this->save_applied();
        do_action('setaredate_applied', SetareDate_Settings::get_applied(), $this->pages);
        return $this->report;
    }

    /* ---------------------------------------------------------------- identitate */

    private function apply_identity() {
        $title = $this->d['nume_primarie'];
        if (get_option('blogname') !== $title) {
            update_option('blogname', $title);
            $this->say('Titlul site-ului: ' . $title);
        }
        if ($this->s['slogan'] !== '' && get_option('blogdescription') !== $this->s['slogan']) {
            update_option('blogdescription', $this->s['slogan']);
            $this->say('Sloganul a fost actualizat.');
        }
        $stema = (int) $this->s['stema_id'];
        if ($stema && get_post($stema) && (int) get_option('site_icon') !== $stema) {
            update_option('site_icon', $stema);
            $this->say('Stema a fost setată și ca pictogramă a site-ului.');
        }
    }

    /* -------------------------------------------------------------------- pagini */

    private function apply_pages() {
        $d = $this->d;
        $s = $this->s;

        $fixed = array(
            array('despre',        $d['despre_label'],       sanitize_title($d['despre_label']), '',        '[setaredate_subpagini]'),
            array('istoric',       'Istoric',                'istoric',                           'despre',  $this->text_istoric()),
            array('prezentare',    'Prezentare generală',    'prezentare-generala',               'despre',  $this->text_prezentare()),
            array('administratie', 'Administrație',          'administratie',                     '',        "[setaredate_conducere]\n\n[setaredate_subpagini]"),
            array('servicii',      'Servicii cetățeni',      'servicii-cetateni',                 '',        '[setaredate_subpagini]'),
            array('contact',       'Contact',                'contact',                           '',        '[setaredate_contact]'),
            array('mol',           'Monitorul Oficial Local', 'monitorul-oficial-local',          '',        null),
            array('formulare',     'Formulare',              'formulare',                         '',        null),
            array('media',         'Media',                  'media',                             '',        null),
            array('anunturi',      'Toate Anunțurile',       'anunturi',                          '',        null),
        );
        foreach ($fixed as $row) {
            $this->ensure_page($row[0], $row[1], $row[2], $row[3], $row[4], 0);
        }

        $wanted = array();
        foreach ($s['servicii'] as $i => $item) {
            $key = 'srv:' . $item['uid'];
            $wanted[$key] = true;
            $forms = '<p>Formularele și cererile tipizate sunt disponibile în secțiunea <a href="' . esc_url($this->page_url('formulare', '/formulare/')) . '">Formulare</a>.</p>';
            if (!empty($item['continut'])) {
                $content = $forms . "\n" . $item['continut'];
            } else {
                $content = ($item['descriere'] !== '' ? '<p>' . esc_html($item['descriere']) . '</p>' : '') . $forms;
            }
            $this->ensure_page($key, $item['nume'], sanitize_title($item['nume']), 'servicii', $content, $i + 1);
        }
        foreach ($s['administratie'] as $i => $item) {
            $key = 'adm:' . $item['uid'];
            $wanted[$key] = true;
            $this->ensure_page($key, $item['nume'], sanitize_title($item['nume']), 'administratie', !empty($item['continut']) ? $item['continut'] : '', $i + 1);
        }

        foreach (array_keys($this->pages) as $key) {
            if ((strpos($key, 'srv:') === 0 || strpos($key, 'adm:') === 0) && !isset($wanted[$key])) {
                $post = get_post((int) $this->pages[$key]);
                if ($post && $post->post_status === 'publish') {
                    wp_update_post(array('ID' => $post->ID, 'post_status' => 'draft'));
                    $this->say('Pagina „' . $post->post_title . '” nu mai este în listă și a fost trecută în ciornă (nu a fost ștearsă).');
                }
                unset($this->pages[$key]);
            }
        }
        update_option(SetareDate_Settings::OPT_PAGES, $this->pages, false);
    }

    private function page_url($key, $fallback) {
        if (!empty($this->pages[$key]) && get_post_status((int) $this->pages[$key])) {
            return get_permalink((int) $this->pages[$key]);
        }
        return home_url($fallback);
    }

    private function text_istoric() {
        if (trim(wp_strip_all_tags($this->s['txt_istoric'])) !== '') {
            return $this->s['txt_istoric'];
        }
        return '<h2>Istoric</h2><p>Această pagină prezintă istoricul ' . esc_html($this->d['tip_gen'] . ' ' . $this->s['localitate']) . ', județul ' . esc_html($this->s['judet']) . '. Textul se completează cu informații verificate din surse oficiale și din arhivele locale.</p>';
    }

    private function text_prezentare() {
        if (trim(wp_strip_all_tags($this->s['txt_prezentare'])) !== '') {
            return $this->s['txt_prezentare'];
        }
        return '<h2>Prezentare generală</h2><p>' . esc_html($this->d['tip_nom'] . ' ' . $this->s['localitate']) . ' este situat' . ($this->s['tip'] === 'comuna' ? 'ă' : '') . ' în județul ' . esc_html($this->s['judet']) . '. Descrierea completă a localității se adaugă pe această pagină.</p>';
    }

    /**
     * Creează sau actualizează o pagină gestionată.
     *
     * @param string      $key     Cheie stabilă (ex. despre, srv:abc123).
     * @param string|null $content Conținut inițial; null = nu se atinge conținutul.
     */
    private function ensure_page($key, $title, $slug, $parent_key, $content, $order) {
        $parent_id = 0;
        $parent_path = '';
        if ($parent_key !== '' && !empty($this->pages[$parent_key])) {
            $parent_id = (int) $this->pages[$parent_key];
            $parent_post = get_post($parent_id);
            $parent_path = $parent_post ? get_page_uri($parent_post) . '/' : '';
        }

        $post = null;
        if (!empty($this->pages[$key])) {
            $post = get_post((int) $this->pages[$key]);
            if ($post && ($post->post_type !== 'page' || $post->post_status === 'trash')) {
                $post = null;
            }
        }
        if (!$post) {
            $found = get_page_by_path($parent_path . $slug, OBJECT, 'page');
            if ($found && $found->post_status !== 'trash') {
                $post = $found;
                $this->say('Pagina existentă „' . $post->post_title . '” a fost preluată în structură.');
            }
        }

        if (!$post) {
            $args = array(
                'post_type'      => 'page',
                'post_status'    => 'publish',
                'post_title'     => $title,
                'post_name'      => $slug,
                'post_parent'    => $parent_id,
                'menu_order'     => (int) $order,
                'post_content'   => $content === null ? '' : $content,
                'comment_status' => 'closed',
                'ping_status'    => 'closed',
            );
            $args['post_content'] = $this->import_images($args['post_content']);
            $id = wp_insert_post($args, true);
            if (is_wp_error($id) || !$id) {
                $this->say('Eroare la crearea paginii „' . $title . '”.');
                return;
            }
            $this->pages[$key] = (int) $id;
            update_post_meta($id, '_setaredate_title', $title);
            if ($content !== null) {
                $fresh = get_post($id);
                update_post_meta($id, '_setaredate_hash', md5((string) $fresh->post_content));
            }
            $this->say('Pagina „' . $title . '” a fost creată.');
            return;
        }

        $this->pages[$key] = (int) $post->ID;
        $update  = array('ID' => $post->ID);
        $changed = false;

        $previous_title   = (string) get_post_meta($post->ID, '_setaredate_title', true);
        $title_in_settings_changed = ($previous_title !== '' && $previous_title !== $title);
        if ($post->post_title !== $title && ($previous_title === '' || $title_in_settings_changed || $this->overwrite)) {
            $update['post_title'] = $title;
            $changed = true;
            if ($title_in_settings_changed) {
                $update['post_name'] = $slug;
            }
        }
        if ($parent_key !== '' && $parent_id && (int) $post->post_parent !== $parent_id) {
            $update['post_parent'] = $parent_id;
            $changed = true;
        }
        if ((int) $post->menu_order !== (int) $order && $order > 0) {
            $update['menu_order'] = (int) $order;
            $changed = true;
        }
        if ($post->post_status !== 'publish') {
            $update['post_status'] = 'publish';
            $changed = true;
            $this->say('Pagina „' . $title . '” a fost publicată din nou.');
        }

        $content_state = '';
        if ($content !== null) {
            $content = $this->import_images($content);
            $current = (string) $post->post_content;
            $last    = (string) get_post_meta($post->ID, '_setaredate_hash', true);
            $pristine = trim($current) === '' || ($last !== '' && hash_equals($last, md5($current)));
            if ($pristine || $this->overwrite) {
                if ($current !== $content) {
                    $update['post_content'] = $content;
                    $changed = true;
                    $content_state = 'written';
                }
            } elseif ($current !== $content) {
                $content_state = 'skipped';
            }
        }

        if ($changed) {
            $result = wp_update_post($update, true);
            if (is_wp_error($result)) {
                $this->say('Eroare la actualizarea paginii „' . $title . '”.');
                return;
            }
            $this->say('Pagina „' . $title . '” a fost actualizată.');
        }
        update_post_meta($post->ID, '_setaredate_title', $title);
        if ($content_state === 'written') {
            $fresh = get_post($post->ID);
            update_post_meta($post->ID, '_setaredate_hash', md5((string) $fresh->post_content));
        } elseif ($content_state === 'skipped') {
            $this->say('Conținutul paginii „' . $title . '” a fost editat manual și nu a fost înlocuit (bifați „Înlocuiește și paginile editate manual” pentru a-l suprascrie).');
        }
    }

    /* -------------------------------------------------------- imagini, articole */

    /** Descarcă în biblioteca media imaginile de pe gazdele permise (textele predefinite) și înlocuiește adresele. */
    private function import_images($html) {
        if (!is_string($html) || $html === '' || stripos($html, '<img') === false) {
            return $html;
        }
        if (!preg_match_all('/<img[^>]+src="([^"]+)"/i', $html, $matches)) {
            return $html;
        }
        $map = get_option('setaredate_imported', array());
        $map = is_array($map) ? $map : array();
        foreach (array_unique($matches[1]) as $url) {
            $host = wp_parse_url($url, PHP_URL_HOST);
            if (!$host || !in_array(strtolower($host), SetareDate_Settings::IMPORT_HOSTS, true)) {
                continue;
            }
            $id = isset($map[$url]) ? (int) $map[$url] : 0;
            if (!$id || !get_post($id)) {
                $id = $this->sideload($url);
                if (!$id) {
                    $this->say('Imaginea nu a putut fi descărcată și rămâne legătura originală: ' . $url);
                    continue;
                }
                $map[$url] = $id;
                $this->say('Imagine importată în biblioteca media: ' . basename((string) wp_parse_url($url, PHP_URL_PATH)));
            }
            $local = wp_get_attachment_url($id);
            if ($local) {
                $html = str_replace($url, $local, $html);
            }
        }
        update_option('setaredate_imported', $map, false);
        return $html;
    }

    private function sideload($url) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        $tmp = download_url($url, 25);
        if (is_wp_error($tmp)) {
            return 0;
        }
        $name = sanitize_file_name(basename((string) wp_parse_url($url, PHP_URL_PATH)));
        $id   = media_handle_sideload(array('name' => $name, 'tmp_name' => $tmp), 0);
        if (is_wp_error($id)) {
            @unlink($tmp);
            return 0;
        }
        return (int) $id;
    }

    /** Articolele inițiale se creează o singură dată; după creare aparțin utilizatorului. */
    private function apply_articles() {
        $map = get_option('setaredate_posts', array());
        $map = is_array($map) ? $map : array();
        foreach ($this->s['articole'] as $article) {
            if (empty($article['activ'])) {
                continue;
            }
            $uid = $article['uid'];
            if (!empty($map[$uid]) && get_post_status((int) $map[$uid])) {
                continue;
            }
            $existing = get_posts(array('name' => sanitize_title($article['titlu']), 'post_type' => 'post', 'post_status' => 'any', 'numberposts' => 1));
            if ($existing) {
                $map[$uid] = (int) $existing[0]->ID;
                $this->say('Articolul „' . $article['titlu'] . '” există deja și nu a fost modificat.');
                continue;
            }
            $date = $article['data'] !== '' ? $article['data'] . ' 12:00:00' : current_time('mysql');
            if (strtotime($date) > current_time('timestamp')) {
                $date = current_time('mysql');
            }
            $id = wp_insert_post(array(
                'post_type'      => 'post',
                'post_status'    => 'publish',
                'post_title'     => $article['titlu'],
                'post_content'   => $this->import_images($article['continut']),
                'post_date'      => $date,
                'post_author'    => get_current_user_id() ? get_current_user_id() : 1,
                'comment_status' => 'closed',
            ), true);
            if (is_wp_error($id) || !$id) {
                $this->say('Eroare la crearea articolului „' . $article['titlu'] . '”.');
                continue;
            }
            if (!empty($article['sticky'])) {
                stick_post($id);
            }
            $map[$uid] = (int) $id;
            $this->say('Articolul „' . $article['titlu'] . '” a fost publicat' . (!empty($article['sticky']) ? ' (sticky).' : '.'));
        }
        update_option('setaredate_posts', $map, false);
    }

    /* --------------------------------------------------------------------- meniu */

    private $menu_position = 0;

    private function menu_item($menu_id, $page_key, $parent_item = 0) {
        if (empty($this->pages[$page_key])) {
            return 0;
        }
        $page = get_post((int) $this->pages[$page_key]);
        if (!$page || $page->post_status !== 'publish') {
            return 0;
        }
        $id = wp_update_nav_menu_item($menu_id, 0, array(
            'menu-item-title'     => $page->post_title,
            'menu-item-object'    => 'page',
            'menu-item-object-id' => $page->ID,
            'menu-item-type'      => 'post_type',
            'menu-item-status'    => 'publish',
            'menu-item-parent-id' => $parent_item,
            'menu-item-position'  => ++$this->menu_position,
        ));
        return is_wp_error($id) ? 0 : (int) $id;
    }

    private function apply_menu() {
        $menu = wp_get_nav_menu_object(self::MENU_NAME);
        if ($menu) {
            $menu_id = (int) $menu->term_id;
            foreach ((array) wp_get_nav_menu_items($menu_id, array('post_status' => 'any')) as $item) {
                wp_delete_post($item->ID, true);
            }
        } else {
            $menu_id = wp_create_nav_menu(self::MENU_NAME);
            if (is_wp_error($menu_id)) {
                $this->say('Meniul principal nu a putut fi creat.');
                return;
            }
        }

        $this->menu_position = 0;
        wp_update_nav_menu_item($menu_id, 0, array(
            'menu-item-title'    => 'Acasă',
            'menu-item-url'      => home_url('/'),
            'menu-item-type'     => 'custom',
            'menu-item-status'   => 'publish',
            'menu-item-position' => ++$this->menu_position,
        ));

        $groups = array(
            array('despre',        array('istoric', 'prezentare')),
            array('administratie', $this->child_keys('adm:')),
            array('servicii',      $this->child_keys('srv:')),
        );
        foreach ($groups as $group) {
            $parent_item = $this->menu_item($menu_id, $group[0], 0);
            if (!$parent_item) {
                continue;
            }
            foreach ($group[1] as $child_key) {
                $this->menu_item($menu_id, $child_key, $parent_item);
            }
        }
        foreach (array('mol', 'formulare', 'media', 'contact') as $key) {
            $this->menu_item($menu_id, $key, 0);
        }

        $locations = get_theme_mod('nav_menu_locations', array());
        $locations = is_array($locations) ? $locations : array();
        $locations['primary-menu'] = $menu_id;
        set_theme_mod('nav_menu_locations', $locations);
        $this->say('Meniul principal a fost reconstruit.');
    }

    private function child_keys($prefix) {
        $keys = array();
        $list = $prefix === 'srv:' ? $this->s['servicii'] : $this->s['administratie'];
        foreach ($list as $item) {
            $keys[] = $prefix . $item['uid'];
        }
        return $keys;
    }

    /* ------------------------------------------------------- configurația activă */

    private function save_applied() {
        $s = $this->s;
        $applied = $s + $this->d;

        $applied['stema_url']    = $s['stema_id'] ? (string) wp_get_attachment_url((int) $s['stema_id']) : '';
        $applied['monument_url'] = $s['monument_id'] ? (string) wp_get_attachment_url((int) $s['monument_id']) : '';
        $applied['linkuri_list'] = SetareDate_Settings::parse_links($s['linkuri']);
        $applied['pages']        = $this->pages;

        foreach (array('servicii' => 'srv:', 'administratie' => 'adm:') as $group => $prefix) {
            foreach ($applied[$group] as $i => $item) {
                $applied[$group][$i]['page_id'] = isset($this->pages[$prefix . $item['uid']]) ? (int) $this->pages[$prefix . $item['uid']] : 0;
            }
        }
        unset($applied['txt_istoric'], $applied['txt_prezentare'], $applied['ai_for'], $applied['articole']);
        foreach (array('servicii', 'administratie') as $group) {
            foreach ($applied[$group] as $i => $item) {
                unset($applied[$group][$i]['continut']);
            }
        }

        $applied['configured'] = true;
        $applied['applied_at'] = time();
        $applied['draft_hash'] = SetareDate_Settings::hash($s);
        update_option(SetareDate_Settings::OPT_APPLIED, $applied, true);
        $this->say('Configurația site-ului a fost actualizată.');
    }
}
