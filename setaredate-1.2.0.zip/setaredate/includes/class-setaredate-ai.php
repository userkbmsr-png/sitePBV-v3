<?php
/**
 * Generare text „Despre comună” prin API-ul Anthropic (Messages API).
 *
 * Cheia API se ia din constanta SETAREDATE_ANTHROPIC_KEY (wp-config.php) sau din setările pluginului.
 * Textele generate ajung doar în formular; nu se publică până la „Aplică modificările”.
 */

if (!defined('ABSPATH')) {
    exit;
}

final class SetareDate_AI {
    const ENDPOINT = 'https://api.anthropic.com/v1/messages';
    const API_VERSION = '2023-06-01';

    public static function init() {
        add_action('wp_ajax_setaredate_ai', array(__CLASS__, 'ajax_generate'));
    }

    public static function api_key() {
        if (defined('SETAREDATE_ANTHROPIC_KEY') && SETAREDATE_ANTHROPIC_KEY) {
            return (string) SETAREDATE_ANTHROPIC_KEY;
        }
        $options = SetareDate_Settings::ai_options();
        return (string) $options['key'];
    }

    public static function ajax_generate() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Nu aveți permisiunea necesară.'), 403);
        }
        check_ajax_referer('setaredate_ai', 'nonce');

        if (self::api_key() === '') {
            wp_send_json_error(array('message' => 'Introduceți cheia API Anthropic în secțiunea „Generare text cu AI”, apoi apăsați Salvează.'));
        }

        $types = SetareDate_Settings::types();
        $tip   = isset($_POST['tip']) ? sanitize_key(wp_unslash($_POST['tip'])) : 'comuna';
        $tip   = isset($types[$tip]) ? $tip : 'comuna';
        $ctx   = array(
            'tip'        => $tip,
            'localitate' => isset($_POST['localitate']) ? sanitize_text_field(wp_unslash($_POST['localitate'])) : '',
            'judet'      => isset($_POST['judet']) ? sanitize_text_field(wp_unslash($_POST['judet'])) : '',
            'sate'       => isset($_POST['sate']) ? sanitize_text_field(wp_unslash($_POST['sate'])) : '',
            'slogan'     => isset($_POST['slogan']) ? sanitize_text_field(wp_unslash($_POST['slogan'])) : '',
        );
        if ($ctx['localitate'] === '' || $ctx['judet'] === '') {
            wp_send_json_error(array('message' => 'Completați numele localității și județul.'));
        }
        $part = isset($_POST['part']) ? sanitize_key(wp_unslash($_POST['part'])) : '';
        if (!in_array($part, array('istoric', 'prezentare', 'intro'), true)) {
            wp_send_json_error(array('message' => 'Cerere necunoscută.'));
        }

        @set_time_limit(150);
        $options = SetareDate_Settings::ai_options();
        $prompt  = self::prompt($part, $ctx);
        $result  = self::request($prompt['system'], $prompt['user'], !empty($options['search']), $prompt['max_tokens']);
        if (is_wp_error($result)) {
            wp_send_json_error(array('message' => $result->get_error_message()));
        }

        $signature = SetareDate_Settings::signature(array(
            'tip' => $ctx['tip'], 'localitate' => $ctx['localitate'], 'judet' => $ctx['judet'], 'sate' => $ctx['sate'],
        ));

        if ($part === 'intro') {
            $data = self::parse_intro($result);
            if (!$data) {
                wp_send_json_error(array('message' => 'Răspunsul AI nu a putut fi interpretat. Încercați din nou.'));
            }
            $data['sig'] = $signature;
            wp_send_json_success($data);
        }

        $html = self::clean_html($result);
        if ($html === '') {
            wp_send_json_error(array('message' => 'AI nu a returnat text. Încercați din nou.'));
        }
        wp_send_json_success(array('html' => $html, 'sig' => $signature));
    }

    /* ----------------------------------------------------------------- prompturi */

    private static function prompt($part, $ctx) {
        $types = SetareDate_Settings::types();
        $t     = $types[$ctx['tip']];
        $where = $t['nom'] . ' ' . $ctx['localitate'] . ', județul ' . $ctx['judet'];
        $sate  = $ctx['sate'] !== '' ? 'Localitățile componente indicate de administrație: ' . $ctx['sate'] . '.' : 'Nu au fost indicate localități componente.';

        $system = 'Ești redactor pentru site-ul oficial al unei primării din România. Scrii în limba română, cu diacritice corecte, în ton instituțional, neutru și informativ. '
            . 'Folosești numai informații verificabile despre localitatea indicată. Dacă nu ești sigur de un fapt (an, cifră, nume, eveniment) sau nu îl găsești în surse, nu îl include și formulează general. '
            . 'Nu inventa personalități, date, cifre sau obiective turistice. Nu folosi limbaj promoțional sau superlative. Nu menționa că ești o inteligență artificială. Nu include adrese URL, surse sau note de subsol. '
            . 'Dacă ai la dispoziție căutarea web, folosește-o pentru a verifica istoricul și datele localității, de preferință din surse oficiale (primărie, INS, recensământ, consiliul județean).';

        if ($part === 'istoric') {
            $user = 'Scrie textul paginii „Istoric” pentru ' . $where . '. ' . $sate . "\n"
                . 'Lungime: 300–450 de cuvinte, în 2–3 secțiuni cu titluri scurte. Include prima atestare documentară doar dacă o poți confirma. '
                . 'Răspunde exclusiv cu fragmentul HTML, folosind doar etichetele h2, p, ul, li și strong, fără blocuri de cod și fără comentarii.';
            return array('system' => $system, 'user' => $user, 'max_tokens' => 2500);
        }
        if ($part === 'prezentare') {
            $user = 'Scrie textul paginii „Prezentare generală” pentru ' . $where . '. ' . $sate . "\n"
                . 'Acoperă, în măsura în care le poți confirma: poziția geografică și vecinătățile, relieful și apele, localitățile componente, activitățile economice, comunitatea și tradițiile, repere și obiective de vizitat. '
                . 'Lungime: 300–450 de cuvinte, în 3–4 secțiuni cu titluri scurte. '
                . 'Răspunde exclusiv cu fragmentul HTML, folosind doar etichetele h2, p, ul, li și strong, fără blocuri de cod și fără comentarii.';
            return array('system' => $system, 'user' => $user, 'max_tokens' => 2500);
        }

        $count = count(array_filter(array_map('trim', explode(',', $ctx['sate']))));
        $user = 'Pentru ' . $where . '. ' . $sate . ($ctx['slogan'] !== '' ? ' Sloganul localității: „' . $ctx['slogan'] . '”.' : '') . "\n"
            . 'Pregătește textul casetei de prezentare de pe prima pagină. Returnează exclusiv un obiect JSON valid, fără blocuri de cod, cu cheile: '
            . '"intro_1" (un paragraf de 35–55 de cuvinte despre așezarea și specificul localității), '
            . '"intro_2" (un paragraf de 35–55 de cuvinte despre comunitate și direcțiile de dezvoltare, fără promisiuni concrete) și '
            . '"stats" (listă de exact 4 obiecte cu cheile "valoare" și "eticheta"). '
            . 'Cifrele din "stats" trebuie să fie semnificative și verificabile (de exemplu populația la ultimul recensământ, suprafața în km², numărul de localități componente, codul poștal, anul primei atestări). '
            . ($count > 0 ? 'Numărul de localități componente indicat este ' . $count . '. ' : '')
            . 'Valoarea să fie scurtă (maximum 14 caractere). Dacă nu poți confirma o cifră, lasă "valoare" ca text gol, nu aproxima.';
        return array('system' => $system, 'user' => $user, 'max_tokens' => 1500);
    }

    /* ------------------------------------------------------------------- cerere */

    /** @return string|WP_Error */
    private static function request($system, $user, $use_search, $max_tokens) {
        $options = SetareDate_Settings::ai_options();
        $model   = $options['model'] !== '' ? $options['model'] : 'claude-sonnet-5-5';
        $body    = array(
            'model'      => $model,
            'max_tokens' => (int) $max_tokens,
            'system'     => $system,
            'messages'   => array(array('role' => 'user', 'content' => $user)),
        );
        if ($use_search) {
            $body['tools'] = array(array('type' => 'web_search_20250305', 'name' => 'web_search', 'max_uses' => 3));
        }

        $data = null;
        for ($turn = 0; $turn < 4; $turn++) {
            $response = wp_remote_post(self::ENDPOINT, array(
                'timeout' => 110,
                'headers' => array(
                    'x-api-key'         => self::api_key(),
                    'anthropic-version' => self::API_VERSION,
                    'content-type'      => 'application/json',
                ),
                'body'    => wp_json_encode($body),
            ));
            if (is_wp_error($response)) {
                return new WP_Error('setaredate_http', 'Conexiunea la API-ul Anthropic a eșuat: ' . $response->get_error_message());
            }
            $code = (int) wp_remote_retrieve_response_code($response);
            $data = json_decode(wp_remote_retrieve_body($response), true);

            if ($code >= 400) {
                $message = isset($data['error']['message']) ? (string) $data['error']['message'] : 'Eroare HTTP ' . $code;
                if (isset($body['tools']) && ($code === 400 || $code === 403) && stripos($message, 'search') !== false) {
                    unset($body['tools']);
                    $turn = -1;
                    continue;
                }
                return new WP_Error('setaredate_api', 'API Anthropic: ' . $message);
            }
            if (!is_array($data) || empty($data['content'])) {
                return new WP_Error('setaredate_api', 'Răspuns gol de la API-ul Anthropic.');
            }
            if (isset($data['stop_reason']) && $data['stop_reason'] === 'pause_turn') {
                $body['messages'][] = array('role' => 'assistant', 'content' => $data['content']);
                continue;
            }
            break;
        }
        return self::final_text($data);
    }

    /** Textul final: blocurile text de după ultimul rezultat de căutare web. */
    private static function final_text($data) {
        $blocks = isset($data['content']) && is_array($data['content']) ? $data['content'] : array();
        $start  = 0;
        foreach ($blocks as $i => $block) {
            if (isset($block['type']) && $block['type'] === 'web_search_tool_result') {
                $start = $i + 1;
            }
        }
        $text = '';
        foreach (array_slice($blocks, $start) as $block) {
            if (isset($block['type'], $block['text']) && $block['type'] === 'text') {
                $text .= $block['text'];
            }
        }
        return trim($text);
    }

    /* ---------------------------------------------------------------- rezultate */

    private static function clean_html($text) {
        $text = preg_replace('/^```[a-z]*\s*|\s*```$/i', '', trim((string) $text));
        $text = wp_kses($text, array(
            'h2' => array(), 'h3' => array(), 'p' => array(), 'ul' => array(), 'ol' => array(),
            'li' => array(), 'strong' => array(), 'em' => array(),
        ));
        return trim($text);
    }

    private static function parse_intro($text) {
        $start = strpos($text, '{');
        $end   = strrpos($text, '}');
        if ($start === false || $end === false || $end <= $start) {
            return null;
        }
        $json = json_decode(substr($text, $start, $end - $start + 1), true);
        if (!is_array($json)) {
            return null;
        }
        $stats = array();
        foreach ((isset($json['stats']) && is_array($json['stats']) ? $json['stats'] : array()) as $row) {
            if (count($stats) >= 4) {
                break;
            }
            $stats[] = array(
                'valoare'  => isset($row['valoare']) ? sanitize_text_field((string) $row['valoare']) : '',
                'eticheta' => isset($row['eticheta']) ? sanitize_text_field((string) $row['eticheta']) : '',
            );
        }
        while (count($stats) < 4) {
            $stats[] = array('valoare' => '', 'eticheta' => '');
        }
        return array(
            'intro_1' => isset($json['intro_1']) ? sanitize_textarea_field((string) $json['intro_1']) : '',
            'intro_2' => isset($json['intro_2']) ? sanitize_textarea_field((string) $json['intro_2']) : '',
            'stats'   => $stats,
        );
    }
}
