<?php
/**
 * Plugin Name: SetareDate
 * Description: Configurează site-ul primăriei: localitate, contact, conducere, stemă, structura paginilor, meniu și texte „Despre comună”. Butoane: Salvează și Aplică modificările.
 * Version: 1.2.0
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Text Domain: setaredate
 */

if (!defined('ABSPATH')) {
    exit;
}

define('SETAREDATE_VERSION', '1.2.0');
define('SETAREDATE_FILE', __FILE__);
define('SETAREDATE_DIR', plugin_dir_path(__FILE__));
define('SETAREDATE_URL', plugin_dir_url(__FILE__));

require_once SETAREDATE_DIR . 'includes/class-setaredate-settings.php';
require_once SETAREDATE_DIR . 'includes/class-setaredate-apply.php';
require_once SETAREDATE_DIR . 'includes/class-setaredate-ai.php';
require_once SETAREDATE_DIR . 'includes/class-setaredate-shortcodes.php';
require_once SETAREDATE_DIR . 'includes/class-setaredate-admin.php';

SetareDate_Admin::init();
SetareDate_AI::init();
SetareDate_Shortcodes::init();

register_activation_hook(__FILE__, array('SetareDate_Admin', 'on_activate'));
