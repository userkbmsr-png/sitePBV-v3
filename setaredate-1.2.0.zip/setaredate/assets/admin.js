(function ($) {
  'use strict';

  var cfg = window.SetareDateAdmin || { strings: {} };
  var t = cfg.strings || {};
  var $form = $('#setaredate-form');

  /* ---- Rânduri adăugate dinamic (compartimente, pagini de administrație) ---- */
  $form.on('click', '.sd-add', function () {
    var $box = $(this).closest('.sd-repeater');
    var next = parseInt($box.attr('data-next'), 10) || 0;
    var html = $box.find('template.sd-template').html().replace(/__INDEX__/g, String(next));
    $box.attr('data-next', next + 1);
    var $row = $(html).appendTo($box.find('.sd-rows'));
    $row.find('input[type="text"]').first().trigger('focus');
  });

  $form.on('click', '.sd-remove', function () {
    var $rows = $(this).closest('.sd-rows');
    $(this).closest('[data-row]').remove();
    if (!$rows.children().length) {
      $rows.closest('.sd-repeater').find('.sd-add').trigger('click');
    }
  });

  /* ---- Alegere imagini din biblioteca media ---- */
  $form.on('click', '.sd-media-pick', function (event) {
    event.preventDefault();
    var $box = $(this).closest('.sd-media');
    var frame = wp.media({
      title: t.pickImage || 'Alegeți imaginea',
      button: { text: t.useImage || 'Folosește imaginea' },
      library: { type: 'image' },
      multiple: false
    });
    frame.on('select', function () {
      var item = frame.state().get('selection').first().toJSON();
      var size = item.sizes && item.sizes.medium ? item.sizes.medium.url : item.url;
      $box.find('input[type="hidden"]').val(item.id);
      $box.find('.sd-media-preview').empty().append($('<img>', { src: size, alt: '' }));
      $box.find('.sd-media-clear').prop('hidden', false);
    });
    frame.open();
  });

  $form.on('click', '.sd-media-clear', function () {
    var $box = $(this).closest('.sd-media');
    $box.find('input[type="hidden"]').val('0');
    $box.find('.sd-media-preview').empty();
    $(this).prop('hidden', true);
  });

  /* ---- Generare texte cu AI: trei cereri succesive, fiecare cu rezultat propriu ---- */
  function setEditor(id, html) {
    var editor = window.tinymce && window.tinymce.get(id);
    if (editor && !editor.isHidden()) {
      editor.setContent(html);
    }
    $('#' + id).val(html);
  }

  function context() {
    return {
      tip: $('#sd-tip').val(),
      localitate: $.trim($('#sd-localitate').val()),
      judet: $.trim($('#sd-judet').val()),
      sate: $.trim($('#sd-sate').val()),
      slogan: $.trim($('#sd-slogan').val())
    };
  }

  function ask(part, ctx) {
    return $.post(cfg.ajaxUrl, $.extend({ action: 'setaredate_ai', nonce: cfg.nonce, part: part }, ctx));
  }

  $('#sd-ai-run').on('click', function () {
    var $button = $(this);
    var ctx = context();
    var $status = $('#sd-ai-status').empty();
    if (!ctx.localitate || !ctx.judet) {
      $status.append($('<li class="sd-error">').text(t.needPlace));
      return;
    }
    var hasText = $.trim($('#sd_txt_istoric').val()) || $.trim($('#sd_txt_prezentare').val()) || $.trim($('#sd-intro_1').val());
    if (hasText && !window.confirm(t.confirmGenerate)) {
      return;
    }

    var steps = [
      { part: 'istoric', apply: function (d) { setEditor('sd_txt_istoric', d.html); } },
      { part: 'prezentare', apply: function (d) { setEditor('sd_txt_prezentare', d.html); } },
      {
        part: 'intro',
        apply: function (d) {
          $('#sd-intro_1').val(d.intro_1);
          $('#sd-intro_2').val(d.intro_2);
          $.each(d.stats || [], function (i, row) {
            $('input[name="setaredate[stats][' + i + '][valoare]"]').val(row.valoare);
            $('input[name="setaredate[stats][' + i + '][eticheta]"]').val(row.eticheta);
          });
        }
      }
    ];

    $button.prop('disabled', true);
    var chain = $.Deferred().resolve();
    var failed = 0;

    $.each(steps, function (index, step) {
      chain = chain.then(function () {
        var $line = $('<li>').text((t[step.part] || step.part) + ': ' + (t.running || '…')).appendTo($status);
        return ask(step.part, ctx).then(function (response) {
          if (response && response.success) {
            step.apply(response.data);
            $('#sd-ai-for').val(response.data.sig || '');
            $line.text((t[step.part] || step.part) + ': ' + (t.done || 'gata'));
          } else {
            failed += 1;
            var message = response && response.data && response.data.message ? response.data.message : '';
            $line.addClass('sd-error').text((t[step.part] || step.part) + ': ' + (t.failed || 'nu a reușit') + (message ? ' – ' + message : ''));
          }
        }, function () {
          failed += 1;
          $line.addClass('sd-error').text((t[step.part] || step.part) + ': ' + (t.failed || 'nu a reușit') + ' – conexiune întreruptă sau timp depășit.');
        });
      });
    });

    chain.always(function () {
      $button.prop('disabled', false);
    });
  });

  /* ---- Date-exemplu ---- */
  $('#sd-preset').on('click', function (event) {
    if (!window.confirm(t.confirmPreset)) {
      event.preventDefault();
    }
  });
}(jQuery));
