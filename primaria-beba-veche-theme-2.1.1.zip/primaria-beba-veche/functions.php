<?php
/**
 * Funcții și configurare pentru tema Primăria (configurabilă prin pluginul SetareDate)
 *
 * @package Primaria_Beba_Veche
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

if (!function_exists('pbv_setup')) :
    /**
     * Sets up theme defaults and registers support for various WordPress features.
     */
    function pbv_setup() {
        // Make theme available for translation.
        load_theme_textdomain('primaria-beba-veche', get_template_directory() . '/languages');

        // Add default posts and comments RSS feed links to head.
        add_theme_support('automatic-feed-links');

        // Let WordPress manage the document title.
        add_theme_support('title-tag');

        // Enable support for Post Thumbnails on posts and pages.
        add_theme_support('post-thumbnails');

        // Register Menus
        register_nav_menus(array(
            'primary-menu' => esc_html__('Meniu Principal Header', 'primaria-beba-veche'),
            'footer-menu'  => esc_html__('Meniu Subsol', 'primaria-beba-veche'),
            'top-utility'  => esc_html__('Meniu Utilitar Bară Sus', 'primaria-beba-veche'),
        ));

        // Switch default core markup for search form, comment form, and comments to output valid HTML5.
        add_theme_support('html5', array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
            'style',
            'script',
        ));

        // Set up the WordPress core custom background feature.
        add_theme_support('custom-background', apply_filters('pbv_custom_background_args', array(
            'default-color' => 'f8fafc',
            'default-image' => '',
        )));

        // Add theme support for selective refresh for widgets.
        add_theme_support('customize-selective-refresh-widgets');

        // Add support for core custom logo.
        add_theme_support('custom-logo', array(
            'height'      => 120,
            'width'       => 120,
            'flex-width'  => true,
            'flex-height' => true,
        ));
    }
endif;
add_action('after_setup_theme', 'pbv_setup');

/**
 * Enqueue scripts and styles.
 */
function pbv_scripts() {
    wp_enqueue_style('pbv-style', get_stylesheet_uri(), array(), '2.1.1');
    wp_enqueue_script('pbv-main', get_template_directory_uri() . '/assets/js/main.js', array(), '2.1.1', true);
}
add_action('wp_enqueue_scripts', 'pbv_scripts');


/**
 * Legacy single-folder embed kept for backward compatibility.
 * Pagina Monitorul Oficial Local folosește shortcode-ul [setaredrive_mol] din pluginul SetareDrive.
 * Usage: [google_drive_mol folder_id="..."]
 */
function pbv_google_drive_mol_shortcode($atts) {
    $atts = shortcode_atts(array(
        'folder_id' => get_theme_mod('pbv_mol_drive_id', ''),
        'height'    => '720px',
    ), $atts, 'google_drive_mol');

    $folder_id = trim($atts['folder_id']);

    if (empty($folder_id)) {
        return '<div class="pbv-drive-placeholder">
            <div class="pbv-drive-placeholder-icon">📁</div>
            <h3>Widget Google Drive - Monitorul Oficial Local</h3>
            <p>Acest shortcode vechi afișează un singur folder. Pentru arhiva pe foldere și subfoldere, folosiți pagina Monitorul Oficial Local și pluginul SetareDrive.</p>
        </div>';
    }

    // Sanitize folder ID if full URL was provided
    if (preg_match('/folders\/([a-zA-Z0-9_-]+)/', $folder_id, $matches)) {
        $folder_id = $matches[1];
    }

    $iframe_url = 'https://drive.google.com/embeddedfolderview?id=' . esc_attr($folder_id) . '#list';

    return '<div class="pbv-drive-frame-wrapper" style="height:' . esc_attr($atts['height']) . ';">
        <iframe src="' . esc_url($iframe_url) . '" class="pbv-drive-frame" title="Monitorul Oficial Local - Google Drive" allowfullscreen></iframe>
    </div>';
}
add_shortcode('google_drive_mol', 'pbv_google_drive_mol_shortcode');

/**
 * Breadcrumb Helper Function
 */
function pbv_breadcrumbs() {
    if (is_front_page()) {
        return;
    }
    echo '<nav class="pbv-breadcrumbs" aria-label="Navigare pe site" style="font-size:13px; color:#64748b; margin-bottom:20px; display:flex; align-items:center; gap:8px;">';
    echo '<a href="' . esc_url(home_url('/')) . '" style="color:#19487e; font-weight:600;">Acasă</a>';
    echo '<span>/</span>';

    if (is_page()) {
        the_title('<span>', '</span>');
    } elseif (is_single()) {
        $cats = get_the_category();
        if ($cats) {
            echo '<a href="' . esc_url(get_category_link($cats[0]->term_id)) . '">' . esc_html($cats[0]->name) . '</a> <span>/</span> ';
        }
        the_title('<span>', '</span>');
    } elseif (is_category() || is_archive()) {
        echo '<span>' . single_cat_title('', false) . '</span>';
    } elseif (is_search()) {
        echo '<span>Rezultate căutare pentru: "' . esc_html(get_search_query()) . '"</span>';
    } elseif (is_404()) {
        echo '<span>Pagina nu a fost găsită (404)</span>';
    }
    echo '</nav>';
}

/**
 * Fallback pentru meniul principal, până când SetareDate construiește meniul.
 */
function pbv_default_menu() {
    echo '<ul class="pbv-main-menu">';
    echo '<li><a href="' . esc_url(home_url('/')) . '">Acasă</a></li>';
    echo '<li><a href="' . esc_url(pbv_page_url('mol', '/monitorul-oficial-local/')) . '">Monitorul Oficial Local</a></li>';
    echo '<li><a href="' . esc_url(pbv_page_url('formulare', '/formulare/')) . '">Formulare</a></li>';
    echo '<li><a href="' . esc_url(pbv_page_url('media', '/media/')) . '">Media</a></li>';
    echo '</ul>';
}

/* ------------------------------------------------------------------------
 * Configurația aplicată din pluginul SetareDate
 * --------------------------------------------------------------------- */

/**
 * Valoare din configurația aplicată (opțiunea setaredate_applied).
 * Fără argument returnează întreaga configurație.
 */
function pbv_cfg($key = null, $default = '') {
    static $cfg = null;
    if ($cfg === null) {
        $cfg = get_option('setaredate_applied', array());
        $cfg = is_array($cfg) ? $cfg : array();
    }
    if ($key === null) {
        return $cfg;
    }
    return (isset($cfg[$key]) && $cfg[$key] !== '' && $cfg[$key] !== array()) ? $cfg[$key] : $default;
}

function pbv_is_configured() {
    return (bool) pbv_cfg('configured', false);
}

/** Adresa unei pagini gestionate de SetareDate (cheia din configurație) sau adresa implicită. */
function pbv_page_url($key, $fallback_path) {
    $pages = pbv_cfg('pages', array());
    if (is_array($pages) && !empty($pages[$key]) && get_post_status((int) $pages[$key]) === 'publish') {
        return get_permalink((int) $pages[$key]);
    }
    return home_url($fallback_path);
}

/** Pictogramă pentru un compartiment, după cuvinte din denumire. */
function pbv_service_icon($name) {
    $name = function_exists('mb_strtolower') ? mb_strtolower($name, 'UTF-8') : strtolower($name);
    $map = array(
        'urbanism' => '🏗️', 'cadastr' => '🏗️', 'construc' => '🏗️',
        'taxe' => '💳', 'impozit' => '💳', 'financiar' => '💳', 'contabil' => '💳',
        'agricol' => '🌾', 'agricultur' => '🌾',
        'civil' => '👥', 'populați' => '👥', 'evidența' => '👥',
        'social' => '🤝', 'asisten' => '🤝',
        'registrat' => '📬', 'relații' => '📬', 'secretar' => '📬',
        'juridic' => '⚖️', 'achiziți' => '📑', 'cultur' => '🎭', 'educa' => '🎓', 'mediu' => '🌿', 'sănătate' => '🩺',
    );
    foreach ($map as $needle => $icon) {
        if (strpos($name, $needle) !== false) {
            return $icon;
        }
    }
    return '📄';
}

/** Satele componente fără localitatea principală, ex.: „<strong>A</strong>, <strong>B</strong> și <strong>C</strong>”. */
function pbv_villages_html() {
    $main = function_exists('mb_strtolower') ? mb_strtolower((string) pbv_cfg('localitate'), 'UTF-8') : strtolower((string) pbv_cfg('localitate'));
    $names = array();
    foreach ((array) pbv_cfg('sate_list', array()) as $village) {
        $lower = function_exists('mb_strtolower') ? mb_strtolower($village, 'UTF-8') : strtolower($village);
        if ($lower !== $main) {
            $names[] = '<strong>' . esc_html($village) . '</strong>';
        }
    }
    if (!$names) {
        return '';
    }
    if (count($names) === 1) {
        return $names[0];
    }
    $last = array_pop($names);
    return implode(', ', $names) . ' și ' . $last;
}

/** Pagina goală afișată vizitatorilor până la prima aplicare a configurației. */
function pbv_render_blank_page() {
    ?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex">
    <title><?php echo esc_html(get_bloginfo('name')); ?></title>
    <?php wp_head(); ?>
</head>
<body <?php body_class('pbv-blank'); ?>>
<?php wp_body_open(); ?>
<?php if (current_user_can('manage_options')) : ?>
    <p class="pbv-blank-note"><a href="<?php echo esc_url(admin_url('admin.php?page=setaredate')); ?>">Configurați site-ul în SetareDate</a></p>
<?php endif; ?>
<?php wp_footer(); ?>
</body>
</html>
<?php
}

/** La activarea temei: pornește pluginul SetareDate și deschide ecranul de configurare. */
function pbv_on_theme_activation() {
    if (pbv_is_configured()) {
        return;
    }
    if (!function_exists('activate_plugin')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }
    $plugin = 'setaredate/setaredate.php';
    if (file_exists(WP_PLUGIN_DIR . '/' . $plugin) && !is_plugin_active($plugin)) {
        activate_plugin($plugin);
    }
    set_transient('setaredate_redirect', 1, 120);
}
add_action('after_switch_theme', 'pbv_on_theme_activation');

function pbv_setup_notice() {
    if (pbv_is_configured() || !current_user_can('manage_options')) {
        return;
    }
    if (class_exists('SetareDate_Settings')) {
        echo '<div class="notice notice-info"><p>Site-ul nu este configurat. <a href="' . esc_url(admin_url('admin.php?page=setaredate')) . '">Deschideți SetareDate</a> și apăsați „Aplică modificările”.</p></div>';
    } else {
        echo '<div class="notice notice-warning"><p>Tema este configurată prin pluginul <strong>SetareDate</strong>. Instalați și activați pluginul pentru a continua.</p></div>';
    }
}
add_action('admin_notices', 'pbv_setup_notice');
