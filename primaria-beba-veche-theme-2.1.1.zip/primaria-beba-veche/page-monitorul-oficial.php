<?php
/**
 * Template Name: Monitorul Oficial Local (Google Drive)
 * @package Primaria_Beba_Veche
 */
get_header();
?>
<main id="primary" class="site-main">
    <div class="pbv-page-heading">
        <div class="pbv-container">
            <?php pbv_breadcrumbs(); ?>
            <h1 class="pbv-page-title"><?php the_title(); ?></h1>
            <p class="pbv-page-intro">Registrul documentelor oficiale ale <?php echo esc_html(pbv_cfg('tip_lcgen') . ' ' . pbv_cfg('localitate', get_bloginfo('name'))); ?>, organizat pe foldere și subfoldere.</p>
        </div>
    </div>
    <div class="pbv-container pbv-page-content-wrap">
        <?php if (shortcode_exists('setaredrive_mol')) : ?>
            <?php echo do_shortcode('[setaredrive_mol]'); ?>
        <?php else : ?>
            <p class="pbv-announcements-empty">Activați pluginul SetareDrive pentru a afișa arhiva.</p>
        <?php endif; ?>
    </div>
</main>
<?php get_footer(); ?>
