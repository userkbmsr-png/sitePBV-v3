<?php
/** Match the /monitorul-oficial-local/ page slug to the MOL template. */
require get_template_directory() . '/page-monitorul-oficial.php';
