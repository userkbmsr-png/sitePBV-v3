<?php
/**
 * The template for displaying all pages without a sidebar.
 * @package Primaria_Beba_Veche
 */
get_header();
?>
<main id="primary" class="site-main">
    <div class="pbv-page-heading">
        <div class="pbv-container">
            <?php pbv_breadcrumbs(); ?>
            <h1 class="pbv-page-title"><?php the_title(); ?></h1>
        </div>
    </div>
    <div class="pbv-container pbv-page-content-wrap">
        <?php while (have_posts()) : the_post(); ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class('pbv-page-content'); ?>><?php the_content(); ?></article>
        <?php endwhile; ?>
    </div>
</main>
<?php get_footer(); ?>
