<?php
/**
 * Template Name: Formulare (Google Drive)
 * @package Primaria_Beba_Veche
 */
get_header();
?>
<main id="primary" class="site-main">
    <div class="pbv-page-heading">
        <div class="pbv-container">
            <?php pbv_breadcrumbs(); ?>
            <h1 class="pbv-page-title"><?php the_title(); ?></h1>
            <p class="pbv-page-intro">Descărcați formularele necesare pentru solicitările adresate <?php echo esc_html(pbv_cfg('localitate') ? 'Primăriei ' . pbv_cfg('tip_gen') . ' ' . pbv_cfg('localitate') : get_bloginfo('name')); ?>. Alegeți o categorie pentru a vedea documentele.</p>
        </div>
    </div>
    <div class="pbv-container pbv-page-content-wrap">
        <?php if (shortcode_exists('setaredrive_formulare')) : ?>
            <?php echo do_shortcode('[setaredrive_formulare]'); ?>
        <?php else : ?>
            <p class="pbv-announcements-empty">Activați pluginul SetareDrive pentru a afișa formularele.</p>
        <?php endif; ?>
    </div>
</main>
<?php get_footer(); ?>
