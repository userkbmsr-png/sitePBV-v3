<?php
/**
 * Subsolul temei Primăria (datele vin din pluginul SetareDate)
 *
 * @package Primaria_Beba_Veche
 */

$pbv_name     = pbv_cfg('nume_primarie', get_bloginfo('name'));
$pbv_services = (array) pbv_cfg('servicii', array());
$pbv_links    = (array) pbv_cfg('linkuri_list', array());
if (!$pbv_links) {
    $pbv_links = array(
        array('text' => 'Ghișeul.ro – plăți online', 'url' => 'https://www.ghiseul.ro'),
        array('text' => 'ANAF', 'url' => 'https://www.anaf.ro'),
        array('text' => 'ANPC', 'url' => 'https://anpc.ro'),
    );
}
$pbv_privacy  = function_exists('get_privacy_policy_url') ? get_privacy_policy_url() : '';
?>
    </div><!-- #content -->

    <footer class="pbv-footer" role="contentinfo">
        <div class="pbv-container">
            <div class="pbv-footer-grid">
                <!-- Col 1: despre instituție -->
                <div class="pbv-footer-col">
                    <h3><?php echo esc_html($pbv_name); ?></h3>
                    <?php if (pbv_cfg('localitate')) : ?>
                        <p>Instituție publică în slujba cetățenilor <?php echo esc_html(pbv_cfg('tip_lcgen') . ' ' . pbv_cfg('localitate')); ?><?php
                            $pbv_others = pbv_villages_html();
                            echo $pbv_others ? ' și a satelor aparținătoare ' . wp_kses($pbv_others, array('strong' => array())) : '';
                        ?>.</p>
                    <?php endif; ?>
                    <?php if (pbv_cfg('adresa')) : ?>
                    <div class="pbv-footer-contact-item"><span>📍</span><span><?php echo esc_html(pbv_cfg('adresa')); ?></span></div>
                    <?php endif; ?>
                    <?php if (pbv_cfg('telefon')) : ?>
                    <div class="pbv-footer-contact-item"><span>📞</span><span>Telefon: <a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/', '', pbv_cfg('telefon'))); ?>"><?php echo esc_html(pbv_cfg('telefon')); ?></a></span></div>
                    <?php endif; ?>
                    <?php if (pbv_cfg('email')) : ?>
                    <div class="pbv-footer-contact-item"><span>✉️</span><span>E-mail: <a href="mailto:<?php echo esc_attr(pbv_cfg('email')); ?>"><?php echo esc_html(pbv_cfg('email')); ?></a></span></div>
                    <?php endif; ?>
                </div>

                <!-- Col 2: servicii și informații -->
                <div class="pbv-footer-col">
                    <h3>Servicii & Informații</h3>
                    <ul>
                        <li><a href="<?php echo esc_url(pbv_page_url('mol', '/monitorul-oficial-local/')); ?>">📜 Monitorul Oficial Local</a></li>
                        <li><a href="<?php echo esc_url(pbv_page_url('formulare', '/formulare/')); ?>">📋 Formulare</a></li>
                        <?php foreach ($pbv_services as $pbv_service) :
                            if (empty($pbv_service['page_id']) || get_post_status((int) $pbv_service['page_id']) !== 'publish') {
                                continue;
                            } ?>
                            <li><a href="<?php echo esc_url(get_permalink((int) $pbv_service['page_id'])); ?>"><?php echo esc_html(pbv_service_icon($pbv_service['nume']) . ' ' . $pbv_service['nume']); ?></a></li>
                        <?php endforeach; ?>
                        <li><a href="<?php echo esc_url(pbv_page_url('contact', '/contact/')); ?>">📍 Contact și program cu publicul</a></li>
                    </ul>
                </div>

                <!-- Col 3: legături utile -->
                <div class="pbv-footer-col">
                    <h3>Legături Utile</h3>
                    <ul>
                        <?php foreach ($pbv_links as $pbv_link) : ?>
                            <li><a href="<?php echo esc_url($pbv_link['url']); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($pbv_link['text']); ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                </div>

                <!-- Col 4: program -->
                <div class="pbv-footer-col">
                    <h3>Program</h3>
                    <?php if (pbv_cfg('program')) : ?>
                        <p><?php echo nl2br(esc_html(pbv_cfg('program'))); ?></p>
                    <?php endif; ?>
                    <?php if (pbv_cfg('audiente')) : ?>
                        <p style="margin-top:12px;"><strong>Audiențe:</strong><br><?php echo nl2br(esc_html(pbv_cfg('audiente'))); ?></p>
                    <?php endif; ?>
                    <div style="margin-top:18px;">
                        <a href="https://www.ghiseul.ro" target="_blank" rel="noopener noreferrer" style="display:inline-block; background:#ffffff; padding:6px 12px; border-radius:6px;">
                            <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/logo-ghiseul.svg'); ?>" alt="Ghișeul.ro" class="pbv-ghiseul-logo" width="104" height="26">
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Bottom Copyright -->
        <div class="pbv-footer-bottom">
            <div class="pbv-container">
                <div>
                    &copy; <?php echo esc_html(wp_date('Y')); ?> <strong><?php echo esc_html($pbv_name); ?></strong>. Toate drepturile rezervate.
                </div>
                <?php if ($pbv_privacy) : ?>
                <div style="display:flex; gap:16px;">
                    <a href="<?php echo esc_url($pbv_privacy); ?>">Politica de Confidențialitate (GDPR)</a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </footer>
</div><!-- #page -->

<?php wp_footer(); ?>
</body>
</html>
