/**
 * Tema Primăria - scripturi publice
 */

document.addEventListener('DOMContentLoaded', function () {
  // 1. Mobile Menu Toggle
  const mobileToggle = document.querySelector('.pbv-mobile-toggle');
  const mainMenu = document.querySelector('.pbv-main-menu');

  if (mobileToggle && mainMenu) {
    mobileToggle.addEventListener('click', function () {
      const isExpanded = mobileToggle.getAttribute('aria-expanded') === 'true';
      mobileToggle.setAttribute('aria-expanded', !isExpanded);
      mainMenu.classList.toggle('active');
    });
  }

  // 2. Accessibility Controls (Font Resize & High Contrast)
  const a11yContrast = document.getElementById('a11y-contrast');
  const a11yFontPlus = document.getElementById('a11y-font-plus');
  const a11yFontMinus = document.getElementById('a11y-font-minus');
  const a11yFontReset = document.getElementById('a11y-font-reset');

  // Load saved preferences
  if (localStorage.getItem('pbv_contrast') === 'high') {
    document.body.classList.add('high-contrast');
  }
  const savedFontSize = localStorage.getItem('pbv_font_size');
  if (savedFontSize) {
    document.body.classList.add(savedFontSize);
  }

  if (a11yContrast) {
    a11yContrast.addEventListener('click', function () {
      document.body.classList.toggle('high-contrast');
      const isHigh = document.body.classList.contains('high-contrast');
      localStorage.setItem('pbv_contrast', isHigh ? 'high' : 'normal');
    });
  }

  if (a11yFontPlus) {
    a11yFontPlus.addEventListener('click', function () {
      if (document.body.classList.contains('font-large')) {
        document.body.classList.remove('font-large');
        document.body.classList.add('font-xlarge');
        localStorage.setItem('pbv_font_size', 'font-xlarge');
      } else {
        document.body.classList.add('font-large');
        localStorage.setItem('pbv_font_size', 'font-large');
      }
    });
  }

  if (a11yFontMinus) {
    a11yFontMinus.addEventListener('click', function () {
      if (document.body.classList.contains('font-xlarge')) {
        document.body.classList.remove('font-xlarge');
        document.body.classList.add('font-large');
        localStorage.setItem('pbv_font_size', 'font-large');
      } else {
        document.body.classList.remove('font-large');
        document.body.classList.remove('font-xlarge');
        localStorage.removeItem('pbv_font_size');
      }
    });
  }

  if (a11yFontReset) {
    a11yFontReset.addEventListener('click', function () {
      document.body.classList.remove('font-large', 'font-xlarge', 'high-contrast');
      localStorage.removeItem('pbv_font_size');
      localStorage.removeItem('pbv_contrast');
    });
  }

  // 3. Formulare Dynamic Search & Category Filtering
  const formSearchInput = document.getElementById('pbv-form-search');
  const filterTabs = document.querySelectorAll('.pbv-tab-btn');
  const formRows = document.querySelectorAll('.pbv-form-row');
  const formCountEl = document.getElementById('pbv-visible-count');

  let currentCategory = 'all';

  function filterForms() {
    const searchTerm = formSearchInput ? formSearchInput.value.toLowerCase().trim() : '';
    let visibleCount = 0;

    formRows.forEach(function (row) {
      const rowCategory = row.getAttribute('data-category') || '';
      const rowTitle = (row.querySelector('.pbv-doc-title') ? row.querySelector('.pbv-doc-title').textContent : '').toLowerCase();
      const rowDesc = (row.querySelector('.pbv-doc-desc') ? row.querySelector('.pbv-doc-desc').textContent : '').toLowerCase();

      const matchesCat = (currentCategory === 'all' || rowCategory === currentCategory);
      const matchesSearch = (!searchTerm || rowTitle.includes(searchTerm) || rowDesc.includes(searchTerm));

      if (matchesCat && matchesSearch) {
        row.style.display = '';
        visibleCount++;
      } else {
        row.style.display = 'none';
      }
    });

    if (formCountEl) {
      formCountEl.textContent = visibleCount;
    }

    const noResultsRow = document.getElementById('pbv-no-results');
    if (noResultsRow) {
      noResultsRow.style.display = visibleCount === 0 ? '' : 'none';
    }
  }

  if (formSearchInput) {
    formSearchInput.addEventListener('input', filterForms);
  }

  filterTabs.forEach(function (btn) {
    btn.addEventListener('click', function () {
      filterTabs.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentCategory = btn.getAttribute('data-target') || 'all';
      filterForms();
    });
  });

  // 4. Google Drive Widget Helper for Monitorul Oficial Local
  const driveSaveBtn = document.getElementById('pbv-save-drive-id');
  const driveInput = document.getElementById('pbv-drive-folder-input');
  const driveFrame = document.getElementById('pbv-google-drive-iframe');
  const drivePlaceholder = document.getElementById('pbv-drive-placeholder');

  if (driveSaveBtn && driveInput) {
    driveSaveBtn.addEventListener('click', function () {
      let val = driveInput.value.trim();
      if (!val) return;

      // Extract folder ID if full Google Drive URL was pasted
      // e.g. https://drive.google.com/drive/folders/1a2B3c...
      const match = val.match(/folders\/([a-zA-Z0-9_-]+)/);
      const folderId = match ? match[1] : val;

      const embedUrl = `https://drive.google.com/embeddedfolderview?id=${folderId}#list`;
      if (driveFrame) {
        driveFrame.src = embedUrl;
        driveFrame.style.display = 'block';
      }
      if (drivePlaceholder) {
        drivePlaceholder.style.display = 'none';
      }

      localStorage.setItem('pbv_mol_drive_id', folderId);
      alert('Configurația Google Drive a fost salvată în browser! Pentru salvare permanentă în WordPress, setați opțiunea în Panoul de Administrare -> Aspect -> Personalizare -> Monitorul Oficial.');
    });

    // Check if an ID was saved locally
    const savedDriveId = localStorage.getItem('pbv_mol_drive_id');
    if (savedDriveId && driveFrame && (!driveFrame.getAttribute('src') || driveFrame.getAttribute('src') === 'about:blank')) {
      driveFrame.src = `https://drive.google.com/embeddedfolderview?id=${savedDriveId}#list`;
      driveFrame.style.display = 'block';
      if (drivePlaceholder) drivePlaceholder.style.display = 'none';
      if (driveInput) driveInput.value = savedDriveId;
    }
  }
});
