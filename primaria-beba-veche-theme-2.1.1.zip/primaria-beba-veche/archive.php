<?php
/**
 * The template for displaying archive pages
 *
 * @package Primaria_Beba_Veche
 */

get_header();
?>

<main id="primary" class="site-main">
    <div style="background-color: var(--pbv-blue-subtle); border-bottom: 1px solid var(--pbv-border); padding: 25px 0;">
        <div class="pbv-container">
            <?php pbv_breadcrumbs(); ?>
            <h1 style="font-family: var(--pbv-font-heading); font-size: 30px; font-weight: 800; color: var(--pbv-blue-dark); margin-bottom: 6px;">
                <?php the_archive_title(); ?>
            </h1>
            <div style="font-size:14px; color:var(--pbv-text-muted);">
                <?php the_archive_description(); ?>
            </div>
        </div>
    </div>

    <div class="pbv-container" style="padding-top: 35px; padding-bottom: 60px;">
        <div class="pbv-news-grid">
            <?php
            if (have_posts()) :
                while (have_posts()) : the_post();
                    $cats = get_the_category();
                    $cat_name = !empty($cats) ? $cats[0]->name : 'Anunț';
            ?>
                <article class="pbv-news-card">
                    <div class="pbv-news-body">
                        <div class="pbv-news-meta">
                            <span class="pbv-news-cat"><?php echo esc_html($cat_name); ?></span>
                            <time datetime="<?php echo get_the_date('c'); ?>"><?php echo get_the_date('j F Y'); ?></time>
                        </div>
                        <h2 class="pbv-news-title">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </h2>
                        <div class="pbv-news-excerpt">
                            <?php echo wp_trim_words(get_the_excerpt(), 24, '...'); ?>
                        </div>
                        <a href="<?php the_permalink(); ?>" class="pbv-quick-link">Citește tot &rarr;</a>
                    </div>
                </article>
            <?php
                endwhile;
                the_posts_pagination(array(
                    'mid_size'  => 2,
                    'prev_text' => __('&laquo; Înapoi', 'primaria-beba-veche'),
                    'next_text' => __('Înainte &raquo;', 'primaria-beba-veche'),
                ));
            else :
                echo '<p>Nu au fost găsite articole.</p>';
            endif;
            ?>
        </div>
    </div>
</main>

<?php
get_footer();
