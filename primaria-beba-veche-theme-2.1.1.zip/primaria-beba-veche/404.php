<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package Primaria_Beba_Veche
 */

get_header();
?>

<main id="primary" class="site-main">
    <div class="pbv-container" style="padding: 80px 20px; text-align: center;">
        <div style="font-size: 72px; font-weight: 900; color: var(--pbv-blue-primary); margin-bottom: 10px;">404</div>
        <h1 style="font-size: 26px; font-weight: 800; color: var(--pbv-blue-dark); margin-bottom: 16px;">
            Pagina căutată nu a fost găsită
        </h1>
        <p style="font-size: 16px; color: var(--pbv-text-muted); max-width: 550px; margin: 0 auto 30px auto;">
            Este posibil ca adresa să fi fost modificată sau pagina să nu mai fie disponibilă. Vă rugăm să utilizați meniul de navigare sau link-urile de mai jos.
        </p>
        <div style="display:flex; justify-content:center; gap:14px; flex-wrap:wrap;">
            <a href="<?php echo esc_url(home_url('/')); ?>" class="pbv-btn pbv-btn-primary">
                🏠 Pagina Principală
            </a>
            <a href="<?php echo esc_url(home_url('/monitorul-oficial-local/')); ?>" class="pbv-btn pbv-btn-accent">
                📜 Monitorul Oficial Local
            </a>
            <a href="<?php echo esc_url(home_url('/formulare/')); ?>" class="pbv-btn pbv-btn-outline">
                📋 Formulare Tipizate
            </a>
        </div>
    </div>
</main>

<?php
get_footer();
