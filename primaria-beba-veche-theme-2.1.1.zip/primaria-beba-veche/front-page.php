<?php
/**
 * Prima pagină. Conținutul vine din configurația aplicată în SetareDate;
 * până la prima aplicare vizitatorii văd o pagină goală.
 *
 * @package Primaria_Beba_Veche
 */

if (!pbv_is_configured()) {
    pbv_render_blank_page();
    return;
}

$pbv_name     = pbv_cfg('nume_primarie', get_bloginfo('name'));
$pbv_short    = pbv_cfg('nume_scurt', get_bloginfo('name'));
$pbv_services = (array) pbv_cfg('servicii', array());
$pbv_stats    = array();
foreach ((array) pbv_cfg('stats', array()) as $pbv_stat) {
    if (!empty($pbv_stat['valoare'])) {
        $pbv_stats[] = $pbv_stat;
    }
}
$pbv_villages = pbv_villages_html();
$pbv_intro_1  = pbv_cfg('intro_1');
$pbv_intro_2  = pbv_cfg('intro_2');
$pbv_url_mol  = pbv_page_url('mol', '/monitorul-oficial-local/');
$pbv_url_form = pbv_page_url('formulare', '/formulare/');

get_header();
?>

<main id="primary" class="site-main">
    <!-- Hero -->
    <section class="pbv-hero<?php echo pbv_cfg('monument_url') ? ' pbv-hero--custom' : ''; ?>" aria-label="Prezentare <?php echo esc_attr($pbv_short); ?>">
        <?php if (pbv_cfg('monument_url')) : ?>
            <div class="pbv-hero-art" style="background-image:url('<?php echo esc_url(pbv_cfg('monument_url')); ?>');" aria-hidden="true"></div>
        <?php endif; ?>
        <div class="pbv-container">
            <div class="pbv-hero-content">
                <?php if (pbv_cfg('slogan')) : ?>
                <div class="pbv-hero-badge">
                    <span>🇷🇴</span> <?php echo esc_html(pbv_cfg('slogan')); ?>
                </div>
                <?php endif; ?>
                <h1 class="pbv-hero-title">
                    Bun venit pe portalul oficial al <?php echo esc_html(pbv_cfg('tip_gen') . ' ' . pbv_cfg('localitate')); ?>
                </h1>
                <p class="pbv-hero-desc">
                    Misiunea administrației locale este de a stimula și sprijini prosperitatea <?php echo esc_html(pbv_cfg('tip_lcgen') . ' ' . pbv_cfg('localitate')); ?><?php echo $pbv_villages ? ' și a satelor aparținătoare ' . wp_kses($pbv_villages, array('strong' => array())) : ''; ?>, oferind cetățenilor servicii publice moderne, transparente și accesibile.
                </p>
                <div class="pbv-hero-cta">
                    <a href="<?php echo esc_url($pbv_url_mol); ?>" class="pbv-btn pbv-btn-accent">
                        <span>📜</span> Monitorul Oficial Local
                    </a>
                    <a href="<?php echo esc_url($pbv_url_form); ?>" class="pbv-btn pbv-btn-primary" style="background:#ffffff; color:var(--pbv-blue-dark);">
                        <span>📋</span> Formulare
                    </a>
                    <a href="https://www.ghiseul.ro" target="_blank" rel="noopener noreferrer" class="pbv-btn pbv-btn-outline" style="border-color:rgba(255,255,255,0.4); color:#ffffff;">
                        <span>💳</span> Plăți Ghișeul.ro
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Acces rapid -->
    <div class="pbv-container">
        <div class="pbv-quick-grid">
            <a href="<?php echo esc_url($pbv_url_mol); ?>" class="pbv-quick-card">
                <div class="pbv-quick-icon">📜</div>
                <h3 class="pbv-quick-title">Monitorul Oficial Local</h3>
                <p class="pbv-quick-text">Registrul actelor administrative, hotărârile consiliului local și dispozițiile primarului, organizate pe foldere.</p>
                <span class="pbv-quick-link">Accesează Registrul &rarr;</span>
            </a>

            <a href="<?php echo esc_url($pbv_url_form); ?>" class="pbv-quick-card">
                <div class="pbv-quick-icon">📋</div>
                <h3 class="pbv-quick-title">Formulare & Cereri Tipizate</h3>
                <p class="pbv-quick-text">Modele de cereri și declarații, pe categorii, gata de descărcat.</p>
                <span class="pbv-quick-link">Vezi Formularele &rarr;</span>
            </a>

            <a href="https://www.ghiseul.ro" target="_blank" rel="noopener noreferrer" class="pbv-quick-card">
                <div class="pbv-quick-icon">💳</div>
                <h3 class="pbv-quick-title">Plăți Online Ghișeul.ro</h3>
                <p class="pbv-quick-text">Achitați impozitele și taxele locale simplu și rapid, fără deplasare.</p>
                <span class="pbv-quick-link">Plătește pe Ghișeul.ro &rarr;</span>
            </a>

            <a href="<?php echo esc_url(pbv_page_url('administratie', '/administratie/')); ?>" class="pbv-quick-card">
                <div class="pbv-quick-icon">🏛️</div>
                <h3 class="pbv-quick-title">Administrație</h3>
                <p class="pbv-quick-text">Informații despre conducerea primăriei, consiliul local și transparența decizională.</p>
                <span class="pbv-quick-link">Află Detalii &rarr;</span>
            </a>
        </div>
    </div>

    <!-- Announcements & News Section -->
    <section class="pbv-section">
        <div class="pbv-container">
            <div class="pbv-section-head pbv-section-head--subtitle">
                <div>
                    <h2 class="pbv-section-title">Anunțuri Recente & Noutăți</h2>
                    <p class="pbv-section-subtitle">Comunicate oficiale, dezbateri publice și evenimente din <?php echo esc_html(pbv_cfg('nume_scurt', get_bloginfo('name'))); ?></p>
                </div>
                <a href="<?php echo esc_url(pbv_page_url('anunturi', '/anunturi/')); ?>" class="pbv-btn pbv-btn-outline" style="font-size:13px;">
                    Toate Anunțurile &rarr;
                </a>
            </div>

            <div class="pbv-news-grid">
                <?php
                $sticky_ids = array_map('absint', (array) get_option('sticky_posts', array()));
                $recent_posts = new WP_Query(array(
                    'post_type'           => 'post',
                    'post_status'         => 'publish',
                    'posts_per_page'      => 3,
                    'post__in'            => $sticky_ids ? $sticky_ids : array(0),
                    'orderby'             => 'date',
                    'order'               => 'DESC',
                    'ignore_sticky_posts' => 1,
                ));

                if ($recent_posts->have_posts()) :
                    while ($recent_posts->have_posts()) : $recent_posts->the_post();
                        $cats = get_the_category();
                        $cat_name = !empty($cats) ? $cats[0]->name : 'Anunț Oficial';
                ?>
                    <article class="pbv-news-card">
                        <div class="pbv-news-body">
                            <div class="pbv-news-meta">
                                <span class="pbv-news-cat"><?php echo esc_html($cat_name); ?></span>
                                <time datetime="<?php echo esc_attr(get_the_date('c')); ?>"><?php echo esc_html(get_the_date('j F Y')); ?></time>
                            </div>
                            <h3 class="pbv-news-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                            <div class="pbv-news-excerpt"><?php echo esc_html(wp_trim_words(get_the_excerpt(), 22, '…')); ?></div>
                            <a href="<?php the_permalink(); ?>" class="pbv-quick-link">Citește anunțul &rarr;</a>
                        </div>
                    </article>
                <?php
                    endwhile;
                    wp_reset_postdata();
                else :
                ?>
                    <p class="pbv-announcements-empty">Nu există momentan anunțuri de afișat.</p>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Servicii pentru cetățeni (din SetareDate) -->
    <?php if ($pbv_services) : ?>
    <section class="pbv-section" style="background-color: #ffffff; border-top: 1px solid var(--pbv-border); border-bottom: 1px solid var(--pbv-border);">
        <div class="pbv-container">
            <div class="pbv-section-head pbv-section-head--subtitle">
                <div>
                    <h2 class="pbv-section-title">Servicii pentru Cetățeni</h2>
                    <p class="pbv-section-subtitle">Ghidul compartimentelor din <?php echo esc_html($pbv_name); ?></p>
                </div>
            </div>

            <div class="pbv-services-grid">
                <?php foreach ($pbv_services as $pbv_service) :
                    $pbv_page = !empty($pbv_service['page_id']) ? (int) $pbv_service['page_id'] : 0;
                    $pbv_link = ($pbv_page && get_post_status($pbv_page) === 'publish') ? get_permalink($pbv_page) : '';
                    ?>
                    <div class="pbv-service-card">
                        <h3><span><?php echo esc_html(pbv_service_icon($pbv_service['nume'])); ?></span> <?php echo esc_html($pbv_service['nume']); ?></h3>
                        <?php if (!empty($pbv_service['descriere'])) : ?><p><?php echo esc_html($pbv_service['descriere']); ?></p><?php endif; ?>
                        <ul>
                            <?php if ($pbv_link) : ?><li><a href="<?php echo esc_url($pbv_link); ?>">Informații și proceduri &rarr;</a></li><?php endif; ?>
                            <li><a href="<?php echo esc_url($pbv_url_form); ?>">Formulare &rarr;</a></li>
                        </ul>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- Caseta de prezentare și cifre semnificative -->
    <div class="pbv-container">
        <div class="pbv-highlight-box<?php echo $pbv_stats ? '' : ' pbv-highlight-box--plain'; ?>">
            <div>
                <h2><?php echo esc_html(pbv_cfg('slogan') ? pbv_cfg('localitate') . ' – ' . pbv_cfg('slogan') : $pbv_short); ?></h2>
                <?php if ($pbv_intro_1 || $pbv_intro_2) : ?>
                    <?php if ($pbv_intro_1) : ?><p><?php echo esc_html($pbv_intro_1); ?></p><?php endif; ?>
                    <?php if ($pbv_intro_2) : ?><p><?php echo esc_html($pbv_intro_2); ?></p><?php endif; ?>
                <?php else : ?>
                    <p><?php echo esc_html($pbv_short); ?> se află în județul <?php echo esc_html(pbv_cfg('judet')); ?>. Pagina de prezentare conține informații despre localitate, istoric și obiective.</p>
                <?php endif; ?>
                <a href="<?php echo esc_url(pbv_page_url('despre', '/despre-comuna/')); ?>" class="pbv-btn pbv-btn-accent" style="display:inline-block;">
                    Descoperă istoria și obiectivele <?php echo esc_html(pbv_cfg('tip_lcgen')); ?> &rarr;
                </a>
            </div>
            <?php if ($pbv_stats) : ?>
            <div class="pbv-highlight-stats">
                <?php foreach ($pbv_stats as $pbv_stat) : ?>
                    <div class="pbv-stat-card">
                        <div class="pbv-stat-val"><?php echo esc_html($pbv_stat['valoare']); ?></div>
                        <div class="pbv-stat-label"><?php echo esc_html($pbv_stat['eticheta']); ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</main>

<?php
get_footer();
